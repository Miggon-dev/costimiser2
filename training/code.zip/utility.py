import pandas as pd
import logging
from datetime import datetime
from sklearn.base import BaseEstimator, RegressorMixin, TransformerMixin, clone

logger = logging.getLogger("app")

control_vars = [
    "Current_basis_weight", # Scanner
    #"Fibre__g/m2_",
    "Speed", # Scanner
    "Current_reel_moisture_average(reel)", # Scanner

    "Sizing_Agent__g/T_", # Size Press
    "Starch_uptake__g/m2_", # Size Press
    "Draw_PD5-SS",  # Size Press
    "Defoamer_mass_flow__g/T_", # Size Press
    "Dry_Strength_Agent_mass_flow__kg/T_", # Size Press
    "SpeedSizer_Linepressure_DS", # Size Press
    "SpeedSizer_Linepressure_FS", # Size Press
    "Consistency_starch_main_line", # Size Press
    
    "Draw_PS-PD1", #Pre-dryer
    "Draw_PD2-PD3", #Pre-dryer
    "Draw_PD4-PD5", #Pre-dryer 
    "Draw_PD3-PD4", #Pre-dryer 
    "Draw_PD1-PD2", #Pre-dryer
    "Moisture_out_of_PreDryer", #Pre-dryer

    "Draw_WS-PS", # Press Section
    "PickUp_Tension", # Press Section
    "Vacuum_presszone_of_suction-press_roll", # Press Section
    "Vacuum_uhle-box_Pick-Up", # Press Section
    "Vacuum_uhle-box_bottom_felt", # Press Section
    "Linepressure_1st_press_FS__bar_", # Press Section
    "Linepressure_2nd_press_FS__bar_", # Press Section
    "Linepressure_1st_press_DS__bar_", # Press Section
    "Linepressure_2nd_press_DS__bar_", # Press Section 
    "Linepressure_shoe_press__bar_", # Press Section 

    #"Dewatering_top_wire_suction_box_zone_1", # Forming Wire (BAD)
    #"Dewatering_Jet_channel", # Forming Wire (BAD)
    "Dewatering_top_wire_suction_box_zone_2", # Forming Wire
    "Vacuum_suction_box_9", "Vacuum_wet_suction_box", # Forming Wire
    "Vacuum_sheet_seperator_box", # Forming Wire
    "Vacuum_suction_box_10", # Forming Wire
    "Vacuum_suction_box_11", # Forming Wire
    "Vacuum_wire_suction_box_1", # Forming Wire
    "Vacuum_wire_suction_box_2", # Forming Wire
    "Consistency_white_water", # Forming Wire
    "White_water_temperature", # Forming Wire
    "Conductivity_white_water_B46", # Forming Wire
    "Top_wire_tenstion", # Forming Wire
    "pH_measurement_white_water_B41", # Forming Wire

    "Jet/wire_ratio", # Headbox
    "Lip_settings", # Headbox

    "Rod_Pressure_Bottom_Roll",
    "Rod_pressure_Top_Roll",

    "Retention_Aid_mass_flow__g/T_", # Approach Flow
    "Bentonite_1_mass_flow__g/T_", # Approach Flow
    "Bentonite_2_mass_flow__g/T_", # Approach Flow
    "Thick_Stock_Consistency__%_", # Approach Flow
    "delta_moisture",

    "Vacuum_holding/pre_positions_of_suction-press_roll",
    "Rod_clamping_pressure_Top_Roll",
    "Rod_clamping_pressure_Bottom_Roll",
    "Dewatering_Pick-Up",

    "Headbox_consistency",

    "pH-Messung_Verdünnungswasser__2..12_pH_",
    "fibre_short/long",
    "Dissolved_gas_after_stock_deculator_measurement_1",
    "Dissolved_gas_before_dilution_water_deculator",
    "Defoamer_mass_flow__g/T_",
    "Web_tension_AD6",
    "Top_Felt_Tension",
    "Bottom_wire_tension",
    "Bottom_Felt_Tension",
    "AD7_fabric_tension_bottom",
    "PD4_fabric_tension",
    "Web_tension_AD6",
    "AD6_fabric_tension",
    "PD1_Fabric_tension",
    "PD2_Fabric_tension",
    "PD5_fabric_tension_top",
    "PD5_fabric_tension_bottom",

    "Vacuum_Zone_1_PickUp",
    "Linepressure_1st_press_FS__bar_",
    "Linepressure_1st_press_DS__bar_",
    "Linepressure_2nd_press_DS__bar_",
    "Linepressure_2nd_press_FS__bar_",
    "Act_Deaerator_mass_flow__g/T_",
    
    "Natriumhydroxide_mass_flow__g/T_",

    "Air_pressure_of_rod_clamping_hose_Top_Roll",
    "Free_gas_before_dilution_water_deculator_measurement_2",
    "Free_gas_before_dilution_water_deculator_measurement_1~^0",
    "Free_gas_after_stock_deculator~^0",
    "Storage_tank_temperature",

    "Vacuum_top_wire_suction_box_zone_2",
    "Vacuum_formning_roll",
    "Vacuum_top_wire_suction_box_zone_1",
    "Airturn_pillow_pressure",
    "Dewatering_Suction_Press_Roll",
    "Dewatering_First_Press_Roll",

    "Current_reel_width",
    "Steam_temperature_for_PM",
    "Steam_pressure_for_PM",

    'Dewatering_Shoe_press',
    'Dewatering_Pick-Up',
    'Total_Dewatering_Press',
    'Dewatering_top_wire_suction_box_zone_2',
    'Uhle_box_1_flow___l/min_',
    
    "Stock_deculator_temperature",
    'Stock_deculator_pressure',

    'Multifractor_1_Long_fibre_fraction',
    'Multifractor_2_long_fibre_fraction', 
    'Multifractor_3_long_fibre_fraction',

    'Fixative_2_mass_flow__g/T_',
    'Act_Deaerator_mass_flow__g/T_',
    
    'DG4_Temperature_Inlet_Air',
    'DG5_Temperature_Inlet_Air',
    'DG1_temperature_Inlet_Air',
    'DG2_temperature_Inlet_Air',
    'DG3_temperature_Inlet_Air',

    'DG4_Moisture_content_Outlet_Air',
    'DG5_Moisture_content_Outlet_Air',
    'DG1_Moisture_content_Outlet_Air',
    'DG2_Moisture_content_Outlet_Air',
    'DG3_Moisture_content_Outlet_Air',

    '3200', 
    '3300', 
    '6010', 
    'concentration_starch_working_tank_1', 
    'concentration_starch_working_tank_2',

    'ambient_temp_C'

]

setpoints={
  "3200115": {
    "MBS_SCT_CD": {
      "target": 2.15,
      "min": 1.95
    },
    "MBS_SCT_MD": {
      "target": 3.6,
      #"min": 3.25
    },
    "MBS_Burst": {
      "target": 270.0,
      "min": 240.0
    }
  },
  "3300085": {
    "MBS_SCT_CD": {
      "target": 1.35,
      "min": 1.3
    },
    "MBS_SCT_MD": {
      "target": 2.30
    },
    "MBS_Burst": {
      "target": 180.0,
      "min": 170.0
    }
  },
  "3300090": {
    "MBS_SCT_CD": {
      "target": 1.55,
      "min": 1.4
    },
    "MBS_SCT_MD": {
      "target": 2.45,     
    },
    "MBS_Burst": {
      "target": 195.0,
      "min": 180.0
    }
  },
  "3300095": {
    "MBS_SCT_CD": {
      "target": 1.6,
      "min": 1.45
    },
    "MBS_SCT_MD": {
      "target": 2.7
    },
    "MBS_Burst": {
      "target": 210.0,
      "min": 190.0
    }
  },
  "3300100": {
    "MBS_SCT_CD": {
      "target": 1.7,
      "min": 1.55
    },
    "MBS_SCT_MD": {
      "target": 2.9,
      #"min": 2.7
    },
    "MBS_Burst": {
      "target": 220.0,
      "min": 200.0
    }
  },
  "3300105": {
    "MBS_SCT_CD": {
      "target": 1.7,
      "min": 1.6
    },
    "MBS_SCT_MD": {
      "target": 2.96,
      #"min": 2.76
    },
    "MBS_Burst": {
      "target": 230.0,
      "min": 210.0
    }
  },
  "3300110": {
    "MBS_SCT_CD": {
      "target": 1.9,
      "min": 1.7
    },
    "MBS_SCT_MD": {
      "target": 3.05,
      #"min": 2.95
    },
    "MBS_Burst": {
      "target": 240.0,
      "min": 220.0
    }
  },
  "3300115": {
    "MBS_SCT_CD": {
      "target": 2.0,
      "min": 1.75
    },
    "MBS_SCT_MD": {
      "target": 3.15,
      #"min": 3.05
    },
    "MBS_Burst": {
      "target": 265.0,
      "min": 230.0
    }
  },
  "3300120": {
    "MBS_SCT_CD": {
      "target": 2.1,
      "min": 1.85
    },
    "MBS_SCT_MD": {
      "target": 3.3,
      #"min": 3.15
    },
    "MBS_Burst": {
      "target": 285.0,
      "min": 240.0
    }
  },
  "3300125": {
    "MBS_SCT_CD": {
      "target": 2.15,
      "min": 1.9
    },
    "MBS_SCT_MD": {
      "target": 3.4,
      #"min": 3.3
    },
    "MBS_Burst": {
      "target": 290.0,
      "min": 270.0
    }
  },
  "3300130": {
    "MBS_SCT_CD": {
      "target": 2.25,
      "min": 2.0
    },
    "MBS_SCT_MD": {
      "target": 3.6,
      #"min": 3.4
    },
    "MBS_Burst": {
      "target": 310.0,
      "min": 260.0
    }
  },
  "3300135": {
    "MBS_SCT_CD": {
      "target": 2.3,
      "min": 2.05
    },
    "MBS_SCT_MD": {
      "target": 3.65,
      #"min": 3.6
    },
    "MBS_Burst": {
      "target": 315.0,
      "min": 290.0
    }
  },
  "6010085": {
    "MBS_SCT_CD": {
      "target": 1.6,
      "min": 1.45
    },
    "MBS_SCT_MD": {
      "target": 2.8,
      #"min": 2.65
    },
    "MBS_Burst": {
      "target": 205.0,
      #"min": 195.0
    }
  },
  "6010090": {
    "MBS_SCT_CD": {
      "target": 1.65,
      "min": 1.5
    },
    "MBS_SCT_MD": {
      "target": 3.0,
      #"min": 2.8
    },
    "MBS_Burst": {
      "target": 215.0,
      #"min": 205.0
    }
  },
  "601095": {
    "MBS_SCT_CD": {
      "target": 1.75,
      "min": 1.6
    },
    "MBS_SCT_MD": {
      "target": 3.1,
      #"min": 3.0
    },
    "MBS_Burst": {
      "target": 225.0,
      #"min": 215.0
    }
  },
  "6010100": {
    "MBS_SCT_CD": {
      "target": 1.85,
      "min": 1.7
    },
    "MBS_SCT_MD": {
      "target": 3.2,
      #"min": 3.1
    },
    "MBS_Burst": {
      "target": 250.0,
      #"min": 225.0
    },
    "MBS_CMT30": {
      "target": 160.0,
      "min": 150.0
    }
  },
  "6010110": {
    "MBS_SCT_CD": {
      "target": 2.05,
      "min": 1.9
    },
    "MBS_SCT_MD": {
      "target": 3.5,
      #"min": 3.4
    },
    "MBS_Burst": {
      "target": 275.0,
      #"min": 250.0
    },
    "MBS_CMT30": {
      "target": 185.0,
      "min": 165.0
    }
  },
  "6010120": {
    "MBS_SCT_CD": {
      "target": 2.2,
      "min": 2.05
    },
    "MBS_SCT_MD": {
      "target": 3.8,
      #"min": 3.7
    },
    "MBS_Burst": {
      "target": 300.0,
      #"min": 275.0
    },
    "MBS_CMT30": {
      "target": 195.0,
      "min": 185.0
    }
  },
  "6035105": {
    "MBS_SCT_CD": {
      "target": 2.15,
      "min": 1.95
    },
    "MBS_SCT_MD": {
      "target": 3.55,
      #"min": 3.2
    },
    "MBS_Burst": {
      "target": 285.0,
      #"min": 275.0
    },
    "MBS_CMT30": {
      "target": 205.0,
      "min": 185.0
    }
  },
  "6035110": {
    "MBS_SCT_CD": {
      "target": 2.25,
      "min": 2.05
    },
    "MBS_SCT_MD": {
      "target": 3.75,
      #"min": 3.55
    },
    "MBS_Burst": {
      "target": 295.0,
      #"min": 285.0
    },
    "MBS_CMT30": {
      "target": 215.0,
      "min": 190.0
    }
  },
  "6035115": {
    "MBS_SCT_CD": {
      "target": 2.35,
      "min": 2.15
    },
    "MBS_SCT_MD": {
      "target": 3.9,
      #"min": 3.75
    },
    "MBS_Burst": {
      "target": 310.0,
      #"min": 295.0
    },
    "MBS_CMT30": {
      "target": 225.0,
      "min": 210.0
    }
  },
  "6035120": {
    "MBS_SCT_CD": {
      "target": 2.5,
      "min": 2.25
    },
    "MBS_CMT30": {
      "target": 235.0,
      "min": 220.0
    }
  },
  "360085": {
    "MBS_SCT_CD": {
      "target": 1.6,
      "min": 1.45
    },
    "MBS_SCT_MD": {
      "target": 2.7,
      #"min": 2.4
    },
    "MBS_Burst": {
      "target": 215.0,
      "min": 180.0
    }
  },
  "3600100": {
    "MBS_SCT_CD": {
      "target": 1.85,
      "min": 1.7
    },
    "MBS_SCT_MD": {
      "target": 3.1,
      #"min": 2.8
    },
    "MBS_Burst": {
      "target": 250.0,
      "min": 210.0
    },
    "MBS_CMT30": {
      "target": 170.0,
      "min": 140.0
    }
  },
  "3600110": {
    "MBS_SCT_CD": {
      "target": 2.05,
      "min": 1.9
    },
    "MBS_SCT_MD": {
      "target": 3.4,
      #"min": 3.1
    },
    "MBS_Burst": {
      "target": 275.0,
      "min": 230.0
    },
    "MBS_CMT30": {
      "target": 185.0,
      "min": 155.0
    }
  },
  "3600125": {
    "MBS_SCT_CD": {
      "target": 2.3,
      "min": 2.15
    },
    "MBS_SCT_MD": {
      "target": 3.8,
      #"min": 3.5
    },
    "MBS_Burst": {
      "target": 310.0,
      "min": 260.0
    },
    "MBS_CMT30": {
      "target": 215.0,
      "min": 180.0
    }
  },
  
}

records = []

for item_id, sensors in setpoints.items():
    for sensor_name, svalues in sensors.items():
        for limit_name, lvalue in svalues.items():            
            records.append({
                "AB_Grade_ID": item_id,
                "property": sensor_name,
                "variable": limit_name,
                "value": lvalue,                
            })
setpoint_df = pd.DataFrame(records)


def gmm_with_min_size(df_scores, min_size=10, k_min=2, k_max=None, random_state=1):
    import numpy as np
    from sklearn.mixture import GaussianMixture
    from sklearn.metrics import silhouette_score

    X = df_scores  # assuming this is an arraylike (n_samples, n_features)
    n = len(X)
    if k_max is None:
        k_max = max(k_min+1, min(n // min_size, n-1))  # reasonable ceiling

    best = {
        "score": -np.inf,
        "k": None,
        "model": None,
        "labels": None,
        "sizes": None
    }

    for k in range(k_min, k_max + 1):
        # Skip impossible k given the min_size constraint
        if k * min_size > n:
            continue

        gm = GaussianMixture(n_components=k, covariance_type='full', random_state=random_state)
        gm.fit(X)
        labels = gm.predict(X)
        sizes = np.bincount(labels, minlength=k)

        # Enforce the minimum size
        if sizes.min() < min_size:
            continue

        sc = silhouette_score(X, labels) if k > 1 else -np.inf

        if sc > best["score"]:
            best = {"score": sc, "k": k, "model": gm, "labels": labels, "sizes": sizes}

    if best["model"] is None:
        raise ValueError(
            f"No viable GMM found that satisfies min_size={min_size}. "
            f"Try reducing min_size, lowering k_max, or using a different algorithm."
        )

    return best["model"], best["labels"], best["k"], best["sizes"]

def weighted_average(df, value_name, n_name):
    return (df[value_name] * df[n_name]).sum() / df[n_name].sum()

def decompose_avg_cost_change(df_prev, df_curr, y_variable_cost):
    import pandas as pd
    import numpy as np

    """
    Decompose change in average cost per unit between two months
    into:
      - mix effect
      - efficiency (cost) effect

    Both df_prev and df_curr must have columns: ['AB_Grade_ID', 'Combined_cost__€/T_', 'n_samples'].

    Assumptions for products not present in one of the months:
      - New products (only in current): previous cost = current cost, previous n = 0
      - Discontinued products (only in previous): current cost = previous cost, current n = 0

    This forces all 'new vs discontinued' impact into the mix effect.
    """

    # Rename columns to mark periods
    prev = df_prev.rename(columns={y_variable_cost: "cost_0", "n_samples": "n_0"})
    curr = df_curr.rename(columns={y_variable_cost: "cost_1", "n_samples": "n_1"})

    # Outer join on product to include new & discontinued products
    df = pd.merge(prev, curr, on="AB_Grade_ID", how="outer")

    # Fill missing quantities with 0 (no production in that month)
    df["n_0"] = df["n_0"].fillna(0)
    df["n_1"] = df["n_1"].fillna(0)

    # For missing costs:
    # - if cost_0 is missing but cost_1 exists (new product), set cost_0 = cost_1
    # - if cost_1 is missing but cost_0 exists (discontinued), set cost_1 = cost_0
    df["cost_0"] = np.where(df["cost_0"].isna(), df["cost_1"], df["cost_0"])
    df["cost_1"] = np.where(df["cost_1"].isna(), df["cost_0"], df["cost_1"])

    # --- Average costs ---

    # Previous month average cost
    Q0 = df["n_0"].sum()
    V0 = (df["cost_0"] * df["n_0"]).sum()
    AC0 = V0 / Q0 if Q0 != 0 else float("nan")

    # Current month average cost
    Q1 = df["n_1"].sum()
    V1 = (df["cost_1"] * df["n_1"]).sum()
    AC1 = V1 / Q1 if Q1 != 0 else float("nan")

    # --- Mix-only average cost (old costs, new quantities) ---
    V_mix = (df["cost_0"] * df["n_1"]).sum()
    AC_mix = V_mix / Q1 if Q1 != 0 else float("nan")

    # --- Effects ---
    mix_effect = AC_mix - AC0            # due to change in mix (incl. new/discontinued)
    efficiency_effect = AC1 - AC_mix     # due to change in unit costs

    total_change = AC1 - AC0
    recon_sum = mix_effect + efficiency_effect

    return {
        "AC0": AC0,
        "AC1": AC1,
        "total_change": total_change,
        "mix_effect": mix_effect,
        "cost_effect": efficiency_effect,
        "reconciliation_sum": recon_sum,
        "detail": df  # optional, to inspect intermediate data
    }

def get_process_grouped(process_data, y_variable_summary, x_variable_summary, color_variable_summary, agg_cost_label, costs_to_consider, overprocessing_vars, y_variable_summary_secondary=None, grades = None):
    import plotly.express as px
    import numpy as np

    df = process_data.sort_values(["grammage","paper_type"])
    if grades is not None:
        df = df[df["AB_Grade_ID"].isin(grades)]

    df["Wedge_Date"] = df["Wedge_Time"].dt.date
    df["Wedge_Week"] = df["Wedge_Time"].dt.isocalendar().week
    df["Wedge_Month"] = df["Wedge_Time"].dt.month
    df["Wedge_Year"] = df["Wedge_Time"].dt.year

    x_var="Wedge_Date"
    if x_variable_summary=="grade":
        x_var="AB_Grade_ID"
        grouped_vars=[x_var]
    elif x_variable_summary=="day":
        x_var="Wedge_Date"
        grouped_vars=[x_var]
    elif x_variable_summary=="week":
        x_var="Wedge_Week"
        grouped_vars=["Wedge_Year", x_var]
    elif x_variable_summary=="month":
        x_var="Wedge_Month"
        grouped_vars=["Wedge_Year", x_var]
    elif x_variable_summary=="year":
        x_var="Wedge_Year"
        grouped_vars=[x_var]
    elif x_variable_summary=="target":
        x_var="target"
        grouped_vars=[x_var]

    

    if color_variable_summary=="grade":
        color_var="AB_Grade_ID"
        grouped_vars=grouped_vars+[color_var] 
        unique_vals = df[color_var].unique()  
        n_colors = len(unique_vals)
        colors = px.colors.sample_colorscale("Turbo", np.linspace(0, 1, n_colors))
        c = dict(zip(unique_vals, colors))   
    elif color_variable_summary=="target":
        color_var="target"
        grouped_vars=grouped_vars+[color_var]
        c = dict(zip(["historic","best","current"], ["blue","green","red"]))        
    elif color_variable_summary=="target_grade":
        color_var="target"
        grouped_vars=grouped_vars+[color_var,"AB_Grade_ID"]
        unique_vals = df[color_var].unique()  
        n_colors = len(unique_vals)
        colors = px.colors.sample_colorscale("Turbo", np.linspace(0, 1, n_colors))
        c = dict(zip(unique_vals, colors))
    elif  color_variable_summary=="cost":
        vv_group = ['MBS_Current_reel_ID', x_var,"grammage","paper_type"]
        vv_summary = [v for v in [y_variable_summary, y_variable_summary_secondary] if v is not None]
        df = df[costs_to_consider + vv_group + vv_summary]        
        df = pd.melt(df, id_vars= [v for v in  vv_group + [y_variable_summary_secondary] if v is not None], value_vars=costs_to_consider , var_name="cost").reset_index()
        df[agg_cost_label]=df["value"]
        color_var="cost"      
        grouped_vars=grouped_vars+[color_var]
        c = dict(zip(df[color_var].unique(), px.colors.qualitative.Plotly))              
    elif  color_variable_summary=="cost_grade":
        df = df[costs_to_consider + ['MBS_Current_reel_ID',"AB_Grade_ID",y_variable_summary,x_var,"grammage","paper_type"]]        
        df = pd.melt(df, id_vars= ['MBS_Current_reel_ID',"AB_Grade_ID",x_var,"grammage","paper_type"], value_vars=costs_to_consider, var_name="cost").reset_index()
        df[agg_cost_label]=df["value"]
        color_var=["cost","AB_Grade_ID"]
        grouped_vars=grouped_vars+color_var    
        c = dict(zip(df["cost"].unique(), px.colors.qualitative.Plotly)) 
    elif  color_variable_summary=="overprocessing":
        vv_group = ['MBS_Current_reel_ID', x_var,"grammage","paper_type"]
        vv_summary = [v for v in [y_variable_summary_secondary] if v is not None]
        df = df[overprocessing_vars + vv_group + vv_summary]           
        df = pd.melt(df, id_vars= [v for v in  vv_group + [y_variable_summary_secondary] if v is not None], value_vars=overprocessing_vars , var_name="cost", value_name="Overprocessing_percentage").reset_index()  
        df["cost"]=df["cost"].str.replace("Overprocessing_","")       
        color_var="cost"
        grouped_vars=grouped_vars+[color_var]
        y_variable_summary = "Overprocessing_percentage"
        c = dict(zip(df["cost"], px.colors.qualitative.Plotly))       
    elif  color_variable_summary=="overprocessing_grade":
        vv_group = ['MBS_Current_reel_ID', "AB_Grade_ID", x_var,"grammage","paper_type"]
        vv_summary = [v for v in [y_variable_summary_secondary] if v is not None]
        df = df[overprocessing_vars + vv_group + vv_summary]             
        df = pd.melt(df, id_vars= [v for v in  vv_group + [y_variable_summary_secondary] if v is not None], value_vars=overprocessing_vars , var_name="cost", value_name="Overprocessing_percentage").reset_index()  
        df["cost"]=df["cost"].str.replace("Overprocessing_","")       
        color_var=["cost","AB_Grade_ID"]
        grouped_vars=grouped_vars + color_var
        y_variable_summary = "Overprocessing_percentage"
        c = dict(zip(df["cost"], px.colors.qualitative.Plotly))
    else:
        color_var=None
        c = None

    if x_variable_summary=="grade":
        if color_variable_summary=="target":
                dfg=df.groupby(grouped_vars+["grammage","paper_type"]).agg({y_variable_summary:"mean", "MBS_Current_reel_ID":"count"}).rename(columns={"MBS_Current_reel_ID":"n"}).reset_index().sort_values(["target","grammage","paper_type"],ascending=[False, True, True])
        else:
                dfg=df.groupby(grouped_vars+["grammage","paper_type"]).agg({y_variable_summary:"mean", "MBS_Current_reel_ID":"count"}).rename(columns={"MBS_Current_reel_ID":"n"}).reset_index().sort_values(["grammage","paper_type"])            
    else:        
        dfg=df.groupby(grouped_vars).agg({y_variable_summary:"mean", "MBS_Current_reel_ID":"count"}).rename(columns={"MBS_Current_reel_ID":"n"}).reset_index()

    if y_variable_summary=="Overprocessing_percentage":
          df[y_variable_summary] = df[y_variable_summary]*100
          dfg[y_variable_summary] = dfg[y_variable_summary]*100

    return df, dfg, c, x_var, color_var

def plot_cost_breakdown(
    object_drilldown,
    df: pd.DataFrame,
    free_y: bool = False,
    units: str = "€/T",
    title: str = None,
):
    import numpy as np
    import plotly.express as px
    import plotly.graph_objects as go

    """
    Bars are colored by CURRENT COST (light scale so black text is readable).
    Facets are sorted by total current_cost (desc).
    """
    df = df.copy()    
 
    # --- facet order by total current cost ---
    cost_order = (
        df.groupby("cost")["current_cost"]
        .sum()
        .sort_values(ascending=False)
        .index.tolist()
    )
 
    # --- labels ---
    df["cost_text"]  = df["current_cost"].map(lambda v: f"{v:,.2f} {units}")
    arrow = np.where(df["pct_cost"].to_numpy() > 0, "▲",
             np.where(df["pct_cost"].to_numpy() < 0, "▼", "•"))
    df["arrow_text"] = [f"{a}{p:.1f}{units}" for a, p in zip(arrow, df["pct_cost"])]
 
    # --- light colorscale (keeps extremes light for black text) ---
    # white → very light blue; adjust last color if you want slightly darker
    light_scale = [
        (0.00, "#ccffcc"),  # light green (most negative)
        (0.50, "#ffffff"),  # white (zero)
        (1.00, "#ffcccc"),  # light red (most positive)
    ]
 
    # color range based on pct_cost
    if len(df):
        cabs = float(np.nanmax(np.abs(df["pct_cost"])))  # max distance from 0
        if cabs == 0:
            cabs = 1.0  # avoid degenerate range if all zeros
    else:
        cabs = 1.0

    cmin = -cabs
    cmax = cabs
 
    if title is None:
        title = f"Current Cost by AB_Grade_ID and Cost Component ({units})"
 
    # --- base bars (color by current_cost) ---
    fig = px.bar(
        df.rename(columns={"cost":object_drilldown}),
        x="AB_Grade_ID",
        y="current_cost",
        facet_col=object_drilldown,
        facet_col_wrap=3,
        color="pct_cost",                 # << color by COST
        color_continuous_scale=light_scale,   # << light palette
        range_color=[cmin, cmax],
        text="cost_text",
        custom_data=["arrow_text", "previous_cost", "pct_cost", "current_cost"],
        category_orders={"cost": cost_order},
        title=title,
    )
 
    # inside text + thin borders; black text stays readable with light scale
    fig.update_traces(
        selector=dict(type="bar"),
        textposition="inside",
        insidetextanchor="middle",
        textfont=dict(size=11, color="black"),
        cliponaxis=False,
        hovertemplate=(
            "<b>%{facetcol} • ID %{x}</b><br>"
            f"Current: %{{y:,.3f}} {units}<br>"
            f"Previous: %{{customdata[1]:,.3f}} {units}<br>"
            "Δ: %{{customdata[2]:.2%}}<extra></extra>"
        ),
        marker_line_color="rgba(60,60,60,0.5)",
        marker_line_width=0.8,
    )
 
    # arrow text just above each bar (colored by sign of pct change)
    for tr in list(fig.data):
        if tr.type != "bar":
            continue
        cd = getattr(tr, "customdata", None)
        if cd is None:
            continue
        cd_list = cd.tolist() if hasattr(cd, "tolist") else list(cd)
        arrow_text = [row[0] for row in cd_list]
        pct_vals   = [row[2] for row in cd_list]
 
        yvals = np.asarray(tr.y, dtype=float)
        pad = 0.03 * (np.nanmax(yvals) if yvals.size else 1.0)
        y_text = (yvals + pad).tolist()
 
        arrow_colors = ["#2ca02c" if p < 0 else "#d62728" if p > 0 else "#666666" for p in pct_vals]
 
        fig.add_trace(go.Scatter(
            x=tr.x,
            y=y_text,
            mode="text",
            text=arrow_text,
            textposition="top center",
            textfont=dict(size=11, color=arrow_colors),
            hoverinfo="skip",
            showlegend=False,
            xaxis=getattr(tr, "xaxis", "x"),
            yaxis=getattr(tr, "yaxis", "y"),
            cliponaxis=False,
        ))
 
    # whitegrid styling
    base_width=800
    if len(cost_order) == 1:
        apect_ratio=9/16
    else:
        apect_ratio=16/16
    fig.update_layout(
        template="simple_white",
        plot_bgcolor="white",
        paper_bgcolor="white",
        coloraxis_colorbar_title= f"Overprocessing ({units})" if object_drilldown=="overprocessing" else f"Current cost ({units})" ,  
        xaxis_title="AB_Grade_ID",
        yaxis_title=f"Overprocessing ({units})" if object_drilldown=="overprocessing" else f"Current cost ({units})" ,
        font=dict(size=12, color="#222"),
        margin=dict(l=50, r=20, t=70, b=40),
        coloraxis1_showscale=False,
        autosize=True,
        width=None,
        height=base_width*apect_ratio
    )
    fig.update_xaxes(showgrid=True, gridcolor="rgba(200,200,200,0.4)", zeroline=False, tickangle=0)
    fig.update_yaxes(showgrid=True, gridcolor="rgba(200,200,200,0.4)", zeroline=False, automargin=True)
 
    # optional free y-scale per facet
    if free_y:
        fig.update_yaxes(matches=None)
 
    return fig

def daterange(start_date, end_date, jump="day"):
    from datetime import date, timedelta
    import pandas as pd

    d = start_date
    while d <= end_date:
        yield d
        if jump=="week":
            d += timedelta(days=7)
        elif jump=="month":
            d += pd.DateOffset(months=1)
        elif jump=="hour":
            d += pd.DateOffset(hours=1)
        else:
            d += timedelta(days=1)

def compute_icl(gmm, X_scores):
    import numpy as np

    """
    ICL = BIC + entropy of posterior responsibilities.
    Lower ICL is better.
    """
    bic = gmm.bic(X_scores)
    # responsibilities: shape (n_samples, n_components)
    resp = gmm.predict_proba(X_scores)
    # numerical stability: add tiny epsilon
    eps = 1e-12
    entropy = -np.sum(resp * np.log(resp + eps))
    return bic + entropy

def cluster_stability_ari(X_scores, k, n_boot=20, subsample_frac=0.8, random_state=0, ):
  import numpy as np
  from sklearn.mixture import GaussianMixture
  from sklearn.metrics import adjusted_rand_score

  """
  For a fixed k:
  - Refit GMM n_boot times on random subsamples of the data
  - Predict cluster labels on *all* samples each time
  - Measure average Adjusted Rand Index across all pairs of labelings
  Returns a scalar stability score in [0, 1].
  """
  rng = np.random.RandomState(random_state)
  n_samples = X_scores.shape[0]
  n_sub = int(subsample_frac * n_samples)

  all_labels = []

  for b in range(n_boot):
      # Subsample indices
      idx = rng.choice(n_samples, size=n_sub, replace=False)
      X_sub = X_scores[idx]

      gmm = GaussianMixture(
          n_components=k,
          covariance_type="full",
          random_state=rng.randint(0, 1_000_000)
      )
      gmm.fit(X_sub)

      # Predict labels on ALL samples to make ARI comparable
      labels_full = gmm.predict(X_scores)
      all_labels.append(labels_full)

  # Compute average pairwise ARI
  stability = 0.0
  count = 0
  for i in range(len(all_labels)):
      for j in range(i + 1, len(all_labels)):
          ari = adjusted_rand_score(all_labels[i], all_labels[j])
          stability += ari
          count += 1

  if count > 0:
      stability /= count
  else:
      stability = 0.0

  return stability

def clustering(
    df,
    ycol,
    n_pls_components=3,
    min_clusters=1,
    max_clusters=10,
    n_boot=20,
    subsample_frac=0.8,
    icl=True,
    stability=True,
    min_cluster_size=4,  
    verbose = False
):
    from sklearn.cross_decomposition import PLSRegression
    from sklearn.mixture import GaussianMixture
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import adjusted_rand_score
    import numpy as np

    X = df.drop(columns=[ycol]).copy()
    y = df[ycol].copy()
 
    # Drop rows with NaNs in X or y
    mask = X.notna().all(axis=1) & y.notna()
    X = X[mask]
    y = y[mask]
 
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
 
    pls = PLSRegression(n_components=n_pls_components)
    X_pls_scores, _ = pls.fit_transform(X_scaled, y)
 
    bic_values = []
    icl_values = []
    gmm_models = []
    ks = []  # keep track of which k each metric corresponds to
 
    # ---------- Model selection by BIC / ICL ----------
    for k in range(min_clusters, min(max_clusters, len(X_pls_scores)) + 1):
        gmm = GaussianMixture(
            n_components=k,
            covariance_type="full",
            random_state=0
        )
        gmm.fit(X_pls_scores)
 
        # If you want to already enforce min_cluster_size in the selection phase,
        # you can uncomment this block:
        #
        if (min_cluster_size is not None) and (k > min_clusters):
            labels_tmp = gmm.predict(X_pls_scores)
            counts = np.bincount(labels_tmp, minlength=k)
            if (counts < min_cluster_size).any():
                if verbose:
                    print(f"Skipping k={k}: some clusters smaller than {min_cluster_size} "
                      f"({counts})")
                continue
 
        gmm_models.append(gmm)
        ks.append(k)
        bic_values.append(gmm.bic(X_pls_scores))
        icl_values.append(compute_icl(gmm, X_pls_scores))
 
    bic_values = np.array(bic_values)
    icl_values = np.array(icl_values)
 
    if icl:
        best_k_icl = ks[np.argmin(icl_values)]
        if verbose:
            print(f"Initial suggested number of clusters by ICL: k = {best_k_icl}")
    else:
        best_k_icl = ks[np.argmin(bic_values)]
 
    # ---------- Stability-based selection ----------
    if stability:
        stability_scores = []
        ks_stab = []
 
        for k in range(max(min_clusters, 2),
                       min(max_clusters, int(subsample_frac * len(X_pls_scores))) + 1):
            stab_k = cluster_stability_ari(
                X_pls_scores,
                k,
                n_boot=n_boot,
                subsample_frac=subsample_frac,
                random_state=0,
            )
            stability_scores.append(stab_k)
            ks_stab.append(k)
            if verbose:
                print(f"k={k}: stability (ARI) = {stab_k:.3f}")
 
        stability_scores = np.array(stability_scores)
        best_k_stab = ks_stab[np.argmax(stability_scores)]
        if verbose:
            print(f"Best k by stability: k = {best_k_stab}")
    else:
        best_k_stab = np.inf
 
    # ---------- Combine criteria ----------
    final_k = min(best_k_icl, best_k_stab)
    if final_k == np.inf:  # if stability was off and best_k_stab = inf
        final_k = best_k_icl
 
    if verbose:
        print(f"Chosen final number of clusters before size check: k = {final_k}")
 
    # ---------- Enforce minimum cluster size in the final solution ----------
    def fit_with_min_size(k_start):
        """
        Try k = k_start, k_start-1, ..., min_clusters
        Return the first GMM for which all clusters have >= min_cluster_size points.
        """
        if min_cluster_size is None:
            # No constraint requested; just use k_start
            gmm = GaussianMixture(
                n_components=k_start,
                covariance_type="full",
                random_state=0
            )
            gmm.fit(X_pls_scores)
            labels = gmm.predict(X_pls_scores)
            return gmm, labels, k_start
 
        for k in range(k_start, min_clusters - 1, -1):
            gmm = GaussianMixture(
                n_components=k,
                covariance_type="full",
                random_state=0
            )
            gmm.fit(X_pls_scores)
            labels = gmm.predict(X_pls_scores)
            counts = np.bincount(labels, minlength=k)
 
            if (counts >= min_cluster_size).all():
                if verbose:
                    print(f"Final k after enforcing min_cluster_size={min_cluster_size}: "
                          f"k = {k} (cluster sizes: {counts})")
                return gmm, labels, k
 
            if verbose:
                print(f"k={k} rejected: some clusters smaller than {min_cluster_size} "
                      f"(sizes: {counts})")
 
        raise ValueError(
            f"Could not find any k between {min_clusters} and {k_start} "
            f"with all clusters >= {min_cluster_size} members."
        )
 
    final_gmm, final_labels, final_k = fit_with_min_size(final_k)
    if verbose:
        print(f"Chosen final number of clusters: k = {final_k}")
 
    return final_labels

def shapley_for_pair(row1, row2, cost, features, cost_variable=None,
                     add_unknown=False, unknown_name="unknown"):
    """
    Faster exact Shapley computation using the coalition formula.
 
    row1, row2: pandas Series (or mapping) with at least `features`
    cost: function(row_like) -> float
    features: list of feature names
    cost_variable: name of column with the *true* cost (optional)
    add_unknown: if True, add an 'unknown' residual contribution so that
                 total = true cost difference instead of model cost diff.
    """
    import itertools
    import math
 
    n = len(features)
    idxs = range(n)
 
    # Prebuild baseline/new values as simple dicts (only once)
    x1 = {f: float(row1[f]) for f in features}
    x2 = {f: float(row2[f]) for f in features}
 
    # 1) Evaluate the cost for ALL subsets S of features switched to x2
    v = {}  # key: frozenset of feature indices, value: cost
 
    for r in range(n + 1):
        for S in itertools.combinations(idxs, r):
            S_set = frozenset(S)
            row = x1.copy()
            # switch features in S from x2
            for j in S:
                f = features[j]
                row[f] = x2[f]
            v[S_set] = cost(row)
 
    # 2) Shapley formula over all subsets S ⊆ N\{i}
    contrib = {f: 0.0 for f in features}
    n_fact = math.factorial(n)
 
    for i in idxs:
        fi = features[i]
        # all subsets of N \ {i}
        others = [j for j in idxs if j != i]
 
        for r in range(n):  # |S| from 0 to n-1
            weight = math.factorial(r) * math.factorial(n - r - 1) / n_fact
            for S in itertools.combinations(others, r):
                S_set = frozenset(S)
                S_with_i = frozenset(S + (i,))
                contrib[fi] += weight * (v[S_with_i] - v[S_set])
 
    # 3) Optionally add the "unknown" residual to match true cost difference
    if add_unknown and cost_variable is not None:
        # model delta: cost(x2) - cost(x1)
        model_delta = v[frozenset(idxs)] - v[frozenset()]
        # true delta: row2[cost_variable] - row1[cost_variable]
        true_delta = float(row2[cost_variable]) - float(row1[cost_variable])
        # residual goes into an extra "feature"
        contrib[unknown_name] = true_delta - model_delta
 
    return contrib

def plot_shapley_contribution(shapley_df):
    from plotly.subplots import make_subplots
    import plotly.graph_objects as go

    id_col = "id"
    value_cols = [c for c in shapley_df.columns if c != id_col]
    total_col = value_cols[-1]           # last column = total change
    contrib_cols = value_cols[:-1]       # all previous columns = contributions

    x_labels = contrib_cols + [total_col]
    measure = ["relative"] * len(contrib_cols) + ["total"]

    # 2. Unique ids for facet-like subplots
    ids = shapley_df[id_col].unique()
    n_ids = len(ids)

    fig = make_subplots(
        rows=1,
        cols=n_ids,
        subplot_titles=[str(i) for i in ids]
    )

    # 3. Add one Waterfall trace per id (one facet per id)
    for col_idx, this_id in enumerate(ids, start=1):
        row = shapley_df[shapley_df[id_col] == this_id].iloc[0]   # assuming one row per id

        y_values = row[contrib_cols + [total_col]].values

        fig.add_trace(
            go.Bar(
                name=str(this_id),
                x=x_labels,
                y=y_values
            ),
            row=1,
            col=col_idx
        )

    # 4. Layout
    fig.update_layout(
        template="simple_white",
        plot_bgcolor="white",
        paper_bgcolor="white",
        showlegend=False,
    )
    return fig

def to_rgba(color, alpha=0.25):
  import re
  import plotly.graph_objects as go
  """
  Convert any Plotly color string into 'rgba(r,g,b,a)'.
  Handles:
    - named colors: "red"
    - hex: "#FF0000" or "#F00"
    - rgb: "rgb(255,0,0)"
    - rgba: "rgba(255,0,0,0.5)"
    - (optionally) tuples: (r, g, b)
  """
  # If it's already a tuple like (r, g, b)
  if isinstance(color, tuple) and len(color) >= 3:
      r, g, b = color[:3]
      return f"rgba({r},{g},{b},{alpha})"

  c = str(color).strip()

  # Already rgba(...) → just replace alpha
  if c.lower().startswith("rgba"):
      nums = re.findall(r"[\d.]+", c)
      r, g, b = nums[:3]
      return f"rgba({r},{g},{b},{alpha})"

  # rgb(...) → turn into rgba(...)
  if c.lower().startswith("rgb"):
      nums = re.findall(r"[\d.]+", c)
      r, g, b = nums[:3]
      return f"rgba({r},{g},{b},{alpha})"

  # Hex string "#RRGGBB" or "#RGB"
  if c.startswith("#"):
      hex_value = c.lstrip("#")
      # short hex "#F00" → "#FF0000"
      if len(hex_value) == 3:
          hex_value = "".join(ch * 2 for ch in hex_value)
      r = int(hex_value[0:2], 16)
      g = int(hex_value[2:4], 16)
      b = int(hex_value[4:6], 16)
      return f"rgba({r},{g},{b},{alpha})"
  
  # Otherwise, assume a named color like "red"
  # Let Plotly resolve it (often to "rgb(...)"), then recurse
  dummy = go.Figure(data=[go.Scatter(line=dict(color=c))])
  resolved = dummy.data[0].line.color  # typically "rgb(r,g,b)" or a hex
 
def shapley_for_pair_mc(
    row1, row2, cost, features,
    M=500, random_state=None,
    cost_variable=None,
    add_unknown=False,
    unknown_name="unknown"
):
    import random
    rnd = random.Random(random_state) if random_state is not None else random
 
    n = len(features)
 
    # Extract numeric values once
    x1_vals = {f: float(row1[f]) for f in features}
    x2_vals = {f: float(row2[f]) for f in features}
 
    contrib = {f: 0.0 for f in features}
 
    idxs = list(range(n))        # allocate once
    row = dict(x1_vals)          # allocate once
 
    for _ in range(M):
        rnd.shuffle(idxs)
        changed = []
 
        prev_cost = cost(row)
 
        for j in idxs:
            f = features[j]
            v2 = x2_vals[f]
 
            if row[f] == v2:
                continue
 
            changed.append(f)
            row[f] = v2
 
            new_cost = cost(row)
            contrib[f] += (new_cost - prev_cost)
            prev_cost = new_cost
 
        # restore row back to x1
        for f in changed:
            row[f] = x1_vals[f]
 
    invM = 1.0 / M
    for f in features:
        contrib[f] *= invM
 
    if add_unknown and cost_variable is not None:
        model_delta = cost(x2_vals) - cost(x1_vals)
        true_delta = float(row2[cost_variable]) - float(row1[cost_variable])
        contrib[unknown_name] = true_delta - model_delta
 
    return contrib


def shapley_for_pair_mc_batch(
    row1,
    row2,
    cost,
    features,
    M=200,
    random_state=None,
    cost_variable=None,
    add_unknown=False,
    unknown_name="unknown",
):
    import numpy as np

    rng = np.random.default_rng(random_state)

    features = list(features)
    n = len(features)

    x1 = {f: float(row1[f]) for f in features}
    x2 = {f: float(row2[f]) for f in features}

    contrib = {f: 0.0 for f in features}

    rows = []
    meta = []

    for _ in range(M):
        order = rng.permutation(n)

        current = x1.copy()
        rows.append(current.copy())
        prev_idx = len(rows) - 1

        for j in order:
            f = features[j]

            if current[f] == x2[f]:
                continue

            current[f] = x2[f]
            rows.append(current.copy())

            new_idx = len(rows) - 1
            meta.append((f, prev_idx, new_idx))
            prev_idx = new_idx
    
    preds = cost(rows)

    for f, prev_idx, new_idx in meta:
        contrib[f] += preds[new_idx] - preds[prev_idx]

    invM = 1.0 / M
    for f in features:
        contrib[f] *= invM

    if add_unknown and cost_variable is not None:
        model_delta = cost([x2, x1])
        model_delta = model_delta[0] - model_delta[1]

        true_delta = float(row2[cost_variable]) - float(row1[cost_variable])
        contrib[unknown_name] = true_delta - model_delta

    return contrib


def shapley_for_pair_mc_batch_conditional(
    row1,
    row2,
    cost,
    features,
    history,
    M=200,
    random_state=None,
    cost_variable=None,
    add_unknown=False,
    unknown_name="unknown",
    categorical_features=None,
    bandwidths=None,
    max_background=500,
    min_background=30,
    show_progress=True,
):
    import numpy as np
    import pandas as pd

    rng = np.random.default_rng(random_state)

    features = list(features)
    n_features = len(features)

    categorical_features = set(categorical_features or [])
    bandwidths = dict(bandwidths or {})

    # Prepare history once
    hist = history.loc[:, features].dropna().reset_index(drop=True)

    if len(hist) == 0:
        raise ValueError("No complete rows are available in history.")

    n_hist = len(hist)

    numeric_features = [
        f for f in features
        if f not in categorical_features
    ]

    # Precompute arrays once
    hist_arrays = {
        f: hist[f].to_numpy(copy=False)
        for f in features
    }

    numeric_arrays = {
        f: hist[f].to_numpy(dtype=float, copy=False)
        for f in numeric_features
    }

    # Precompute scales and bandwidths once
    feature_std = {}

    for f in numeric_features:
        std = float(np.nanstd(numeric_arrays[f], ddof=1))

        if not np.isfinite(std) or std <= 0:
            std = 1.0

        feature_std[f] = std

        if f not in bandwidths:
            bandwidths[f] = 0.25 * std

        if not np.isfinite(bandwidths[f]) or bandwidths[f] <= 0:
            bandwidths[f] = 1.0

    def _row_to_dict(row):
        return {f: row[f] for f in features}

    x1 = _row_to_dict(row1)
    x2 = _row_to_dict(row2)

    def _weighted_background_indices(x, fixed_features):
        """
        Select historical row indices approximating:

            X_missing | X_fixed = x_fixed
        """

        sample_size = min(max_background, n_hist)

        if not fixed_features:
            return rng.choice(
                n_hist,
                size=sample_size,
                replace=n_hist < sample_size,
            )

        valid_mask = np.ones(n_hist, dtype=bool)

        # Exact conditioning for categorical variables
        for f in fixed_features:
            if f in categorical_features:
                valid_mask &= hist_arrays[f] == x[f]

        valid_idx = np.flatnonzero(valid_mask)

        if valid_idx.size == 0:
            valid_idx = np.arange(n_hist)

        # Calculate weights only for rows surviving categorical filtering
        weights = np.ones(valid_idx.size, dtype=float)

        for f in fixed_features:
            if f not in categorical_features:
                values = numeric_arrays[f][valid_idx]
                z = (values - float(x[f])) / bandwidths[f]

                # Accumulate Gaussian-kernel weights
                weights *= np.exp(-0.5 * z * z)

        weight_sum = weights.sum()

        if (
            not np.isfinite(weight_sum)
            or weight_sum <= 0
        ):
            weights = np.ones(valid_idx.size, dtype=float)
            weight_sum = float(valid_idx.size)

        squared_weight_sum = np.dot(weights, weights)

        if squared_weight_sum > 0:
            effective_n = weight_sum**2 / squared_weight_sum
        else:
            effective_n = 0.0

        if effective_n < min_background:
            # Nearest-neighbour fallback
            distance = np.zeros(n_hist, dtype=float)

            for f in fixed_features:
                if f in categorical_features:
                    distance += np.where(
                        hist_arrays[f] == x[f],
                        0.0,
                        1e6,
                    )
                else:
                    delta = (
                        numeric_arrays[f] - float(x[f])
                    ) / feature_std[f]

                    distance += delta * delta

            nearest_count = min(
                n_hist,
                max(min_background, max_background),
            )

            if nearest_count < n_hist:
                # Faster than sorting the entire array
                nearest_idx = np.argpartition(
                    distance,
                    nearest_count - 1,
                )[:nearest_count]
            else:
                nearest_idx = np.arange(n_hist)

            return rng.choice(
                nearest_idx,
                size=min(max_background, nearest_idx.size),
                replace=nearest_idx.size < max_background,
            )

        probabilities = weights / weight_sum

        return rng.choice(
            valid_idx,
            size=min(max_background, valid_idx.size),
            replace=valid_idx.size < max_background,
            p=probabilities,
        )

    def _conditional_shap_for_row(x):
        """
        Monte Carlo permutation SHAP with coalition caching.
        """

        contributions = np.zeros(n_features, dtype=float)

        # Maps coalition tuples to estimated conditional values.
        #
        # A coalition is represented as a sorted tuple of feature indices.
        value_cache = {}

        def conditional_value(fixed_indices):
            key = tuple(sorted(fixed_indices))

            if key in value_cache:
                return value_cache[key]

            if len(key) == n_features:
                model_input = pd.DataFrame(
                    [{f: x[f] for f in features}],
                    columns=features,
                )
                value = float(np.asarray(cost(model_input)).reshape(-1)[0])
                value_cache[key] = value
                return value

            fixed_names = [features[i] for i in key]

            sampled_idx = _weighted_background_indices(
                x=x,
                fixed_features=fixed_names,
            )

            # Vectorized row construction: no iterrows()
            model_input = hist.iloc[sampled_idx].copy()

            for f in fixed_names:
                model_input.loc[:, f] = x[f]

            predictions = np.asarray(
                cost(model_input)
            ).reshape(-1)

            value = float(np.mean(predictions))
            value_cache[key] = value

            return value

        iterator = range(M)

        if show_progress:
            from tqdm.auto import tqdm

            iterator = tqdm(
                iterator,
                desc="Conditional SHAP",
                leave=False,
            )

        empty_value = conditional_value(())

        for _ in iterator:
            order = rng.permutation(n_features)

            fixed_indices = []
            previous_value = empty_value

            for feature_idx in order:
                fixed_indices.append(int(feature_idx))

                new_value = conditional_value(fixed_indices)

                contributions[feature_idx] += (
                    new_value - previous_value
                )

                previous_value = new_value

        contributions /= M

        return {
            feature: float(contributions[i])
            for i, feature in enumerate(features)
        }

    shap1 = _conditional_shap_for_row(x1)
    shap2 = _conditional_shap_for_row(x2)

    contributions = {
        f: shap2[f] - shap1[f]
        for f in features
    }

    if add_unknown and cost_variable is not None:
        pair_input = pd.DataFrame(
            [x2, x1],
            columns=features,
        )

        pair_predictions = np.asarray(
            cost(pair_input)
        ).reshape(-1)

        model_delta = float(
            pair_predictions[0] - pair_predictions[1]
        )

        true_delta = (
            float(row2[cost_variable])
            - float(row1[cost_variable])
        )

        contributions[unknown_name] = true_delta - model_delta

    return contributions



def shapley_for_pair_filtered(
    row1,
    row2,
    cost,
    features,
    process_data,
    M=500,
    random_state=None,
    cost_variable=None,
    add_unknown=False,
    unknown_name="unknown",
    min_delta_over_std=0.25,
    min_delta_over_range=0.05,
    min_abs_delta=None,
    keep_top_n=None,
    return_details=False,
    conditional=False
):
    import numpy as np
    import pandas as pd

    # ----------------------------
    # 1. Shapley contributions
    # ----------------------------
    
    if conditional:
        contrib_all = shapley_for_pair_mc_batch_conditional(
            row1=row1,
            row2=row2,
            cost=cost,
            features=features,
            history=process_data,
            M=100,
            random_state=random_state,
            cost_variable=cost_variable,
            add_unknown=add_unknown,
            unknown_name=unknown_name,
            show_progress=False
        )
    else:
        contrib_all = shapley_for_pair_mc_batch(
            row1=row1,
            row2=row2,
            cost=cost,
            features=features,            
            M=M,
            random_state=random_state,
            cost_variable=cost_variable,
            add_unknown=add_unknown,
            unknown_name=unknown_name,
        )


    # ----------------------------
    # 2. Precompute statistics ONCE
    # ----------------------------
    stats = {}

    available_cols = [f for f in features if f in process_data.columns]

    if available_cols:
        df = process_data[available_cols].apply(pd.to_numeric, errors="coerce")

        stds = df.std(ddof=1)
        p05 = df.quantile(0.05)
        p95 = df.quantile(0.95)

        for f in available_cols:
            stats[f] = (
                float(stds[f]) if not np.isnan(stds[f]) else np.nan,
                float(p05[f]) if not np.isnan(p05[f]) else np.nan,
                float(p95[f]) if not np.isnan(p95[f]) else np.nan,
            )

    # ----------------------------
    # 3. Filtering (no heavy DF yet)
    # ----------------------------
    kept = []
    diagnostics_rows = [] if return_details else None

    for f in features:
        x1 = float(row1[f])
        x2 = float(row2[f])
        delta = x2 - x1
        abs_delta = abs(delta)

        std, p05_f, p95_f = stats.get(f, (np.nan, np.nan, np.nan))
        robust_range = p95_f - p05_f if not np.isnan(p95_f) and not np.isnan(p05_f) else np.nan

        delta_over_std = abs_delta / std if std and std > 0 else np.nan
        delta_over_range = abs_delta / robust_range if robust_range and robust_range > 0 else np.nan

        keep = True

        # absolute threshold
        if min_abs_delta is not None:
            abs_thr = min_abs_delta.get(f) if isinstance(min_abs_delta, dict) else min_abs_delta
            if abs_thr is not None and abs_delta < abs_thr:
                keep = False

        # relative thresholds
        if not np.isnan(delta_over_std) and delta_over_std < min_delta_over_std:
            keep = False

        if not np.isnan(delta_over_range) and delta_over_range < min_delta_over_range:
            keep = False

        if keep:
            kept.append(f)

        if return_details:
            diagnostics_rows.append(
                (
                    f, x1, x2, delta, abs_delta,
                    std, p05_f, p95_f,
                    delta_over_std, delta_over_range,
                    contrib_all.get(f, 0.0),
                    abs(contrib_all.get(f, 0.0)),
                    keep,
                )
            )

    # ----------------------------
    # 4. Apply top-N filter
    # ----------------------------
    if keep_top_n and kept:
        kept = sorted(
            kept,
            key=lambda f: abs(contrib_all.get(f, 0.0)),
            reverse=True
        )[:keep_top_n]

    kept = [f for f in kept if not f.endswith("_L1")]

    contrib_filtered = {f: contrib_all[f] for f in kept}

    if add_unknown and unknown_name in contrib_all:
        contrib_filtered[unknown_name] = contrib_all[unknown_name]

    # ----------------------------
    # 5. Diagnostics only if needed
    # ----------------------------
    if return_details:
        diagnostics = pd.DataFrame(
            diagnostics_rows,
            columns=[
                "variable", "value_row1", "value_row2", "delta", "abs_delta",
                "std", "p05", "p95",
                "delta_over_std", "delta_over_range",
                "contribution", "abs_contribution", "keep",
            ],
        ).sort_values("abs_contribution", ascending=False)

        return {
            "contrib_all": contrib_all,
            "contrib_filtered": contrib_filtered,
            "diagnostics": diagnostics,
        }

    return contrib_filtered



def make_model_cost(model, feature_fn):
    cols = feature_fn()
    df = pd.DataFrame([[0.0] * len(cols)], columns=cols)  # allocate ONCE
 
    def cost(row):
        # overwrite values in-place (no allocation)
        df.iloc[0] = [row[c] for c in cols]
        return float(model.predict(df)[0])
 
    return cost

def make_models_cost(models, feature_fns, agg="sum"):
    """
    Parameters
    ----------
    models : dict[str, estimator]
        Trained models.
    feature_fns : dict[str, callable]
        Mapping model name -> function returning that model's expected columns.
    agg : {"sum", "mean"} | callable
        Aggregation rule across model predictions.
    """
    if not isinstance(models, dict):
        raise ValueError("For different feature sets, models must be a dict.")
    if not isinstance(feature_fns, dict):
        raise ValueError("For different feature sets, feature_fns must be a dict.")

    buffers = {}
    for name, model in models.items():
        cols = feature_fns[name]
        buffers[name] = {
            "cols": cols,
            "df": pd.DataFrame([[0.0] * len(cols)], columns=cols)
        }

    def _aggregate(preds_dict):
        if callable(agg):
            return float(agg(preds_dict))
        elif agg == "sum":
            return float(sum(preds_dict.values()))
        elif agg == "mean":
            return float(np.mean(list(preds_dict.values())))
        else:
            raise ValueError(f"Unknown agg='{agg}'")

    def cost(row, return_components=False):
        preds = {}

        for name, model in models.items():
            cols = buffers[name]["cols"]
            df = buffers[name]["df"]
            df.iloc[0] = [row[c] for c in cols]
            preds[name] = float(model.predict(df)[0])

        total = _aggregate(preds)

        if return_components:
            return {
                "components": preds,
                "total": total,
            }

        return total

    return cost

def make_model_cost_batch(model, feature_fn, weight=1):
    cols = list(feature_fn())

    def _to_frame(rows):
        import pandas as pd

        if isinstance(rows, pd.DataFrame):
            return rows.loc[:, cols]

        if isinstance(rows, pd.Series):
            return rows.to_frame().T.loc[:, cols]

        if isinstance(rows, dict):
            return pd.DataFrame([rows], columns=cols)

        if isinstance(rows, list):
            if len(rows) == 0:
                raise ValueError("cost_batch received an empty list.")
            return pd.DataFrame(rows, columns=cols)

        raise TypeError(f"Unsupported input type for cost_batch: {type(rows)}")

    def cost_batch(rows):
        import numpy as np

        X = _to_frame(rows)

        if len(X) == 0:
            raise ValueError("cost_batch generated an empty DataFrame.")

        return np.asarray(weight * model.predict(X), dtype=float).ravel()

    def cost_one(row):
        return weight * float(cost_batch(row)[0])

    return cost_one, cost_batch

def make_models_cost_batch(models, feature_fns, agg="sum", weights=None):

    if not isinstance(models, dict):
        raise ValueError("models must be a dict.")

    if not isinstance(feature_fns, dict):
        raise ValueError("feature_fns must be a dict.")

    # default weights
    if weights is None:
        weights = {name: 1.0 for name in models}

    # validate weights
    for name in models:
        if name not in weights:
            weights[name] = 1.0

    model_cols = {}

    for name in models:
        cols = feature_fns[name]

        # support both callable and list
        if callable(cols):
            cols = cols()

        model_cols[name] = list(cols)

    def _aggregate_matrix(preds_dict):

        weighted_preds = {
            name: preds_dict[name] * float(weights.get(name, 1.0))
            for name in preds_dict
        }

        mat = np.column_stack(
            [weighted_preds[name] for name in models]
        )

        if callable(agg):
            return np.asarray([
                agg({
                    k: weighted_preds[k][i]
                    for k in weighted_preds
                })
                for i in range(len(mat))
            ])

        if agg == "sum":
            return mat.sum(axis=1)

        elif agg == "mean":
            return mat.mean(axis=1)

        else:
            raise ValueError(f"Unknown agg='{agg}'")

    def _to_frame(rows, cols):

        if isinstance(rows, pd.DataFrame):
            return rows.loc[:, cols]

        if isinstance(rows, pd.Series):
            return rows.to_frame().T.loc[:, cols]

        if isinstance(rows, dict):
            return pd.DataFrame([rows], columns=cols)

        if isinstance(rows, list):

            if len(rows) == 0:
                raise ValueError("Empty rows list.")

            return pd.DataFrame(rows, columns=cols)

        raise TypeError(f"Unsupported rows type: {type(rows)}")

    def cost_batch(rows, return_components=False):

        preds = {}

        for name, model in models.items():

            cols = model_cols[name]

            X = _to_frame(rows, cols)

            if (callable(model)):
                preds[name] = model(X)
            else:    
                preds[name] = np.asarray(
                    model.predict(X),
                    dtype=float
                ).ravel()

        total = _aggregate_matrix(preds)

        if return_components:

            weighted_components = {
                k: preds[k] * float(weights.get(k, 1.0))
                for k in preds
            }

            return {
                "components": weighted_components,
                "raw_components": preds,
                "total": total,
            }

        return total

    def cost(row, return_components=False):

        out = cost_batch(
            row,
            return_components=return_components
        )

        if return_components:

            return {
                "components": {
                    k: float(v[0])
                    for k, v in out["components"].items()
                },

                "raw_components": {
                    k: float(v[0])
                    for k, v in out["raw_components"].items()
                },

                "total": float(out["total"][0]),
            }

        return float(out[0])

    return cost, cost_batch

def make_models_cost_batch_DEPRECATED(models, feature_fns, agg="sum"):
    if not isinstance(models, dict):
        raise ValueError("models must be a dict.")
    if not isinstance(feature_fns, dict):
        raise ValueError("feature_fns must be a dict.")

    model_cols = {}

    for name in models:
        cols = feature_fns[name]
        
        # support both callable and list
        if callable(cols):
            cols = cols()
            
        model_cols[name] = list(cols)

    def _aggregate_matrix(preds_dict):
        mat = np.column_stack([preds_dict[name] for name in models])

        if callable(agg):
            return np.asarray([agg({k: preds_dict[k][i] for k in preds_dict}) for i in range(len(mat))])

        if agg == "sum":
            return mat.sum(axis=1)
        elif agg == "mean":
            return mat.mean(axis=1)
        else:
            raise ValueError(f"Unknown agg='{agg}'")

    def _to_frame(rows, cols):
        if isinstance(rows, pd.DataFrame):
            return rows.loc[:, cols]

        if isinstance(rows, pd.Series):
            return rows.to_frame().T.loc[:, cols]

        if isinstance(rows, dict):
            return pd.DataFrame([rows], columns=cols)

        if isinstance(rows, list):
            if len(rows) == 0:
                raise ValueError("Empty rows list.")
            return pd.DataFrame(rows, columns=cols)

        raise TypeError(f"Unsupported rows type: {type(rows)}")

    def cost_batch(rows, return_components=False):
        preds = {}

        for name, model in models.items():
            cols = model_cols[name]
            X = _to_frame(rows, cols)

            preds[name] = np.asarray(
                model.predict(X),
                dtype=float
            ).ravel()

        total = _aggregate_matrix(preds)

        if return_components:
            return {
                "components": preds,
                "total": total,
            }

        return total

    def cost(row, return_components=False):
        out = cost_batch(row, return_components=return_components)

        if return_components:
            return {
                "components": {
                    k: float(v[0])
                    for k, v in out["components"].items()
                },
                "total": float(out["total"][0]),
            }

        return float(out[0])

    return cost, cost_batch




def _prediction_models(models_dir):
  import pickle
  import joblib
  from sklearn.linear_model import LinearRegression
  import numpy as np

  models={}
  features={}
  ref_date=pd.to_datetime("2025-2-5").strftime("%Y_%m_%d")
  for property in ["MBS_SCT_MD","MBS_SCT_CD","MBS_Burst","MBS_CMT30"]:
      with open(models_dir / f"{property}_V{ref_date}_retrained0.pkl", 'rb') as f:
          models[property] = joblib.load(f)
  for property in ["MBS_SCT_MD","MBS_SCT_CD","MBS_Burst","MBS_CMT30"]:
      with open(models_dir /  f"{property}_V{ref_date}_retrained0.pkl", 'rb') as f:        
          features[property] = pickle.load(f)
  LR_models={}

  for model_name in ["MBS_SCT_CD","MBS_SCT_MD","MBS_Burst","MBS_CMT30"]:
      lr = LinearRegression()
      coefs_arr = np.asarray(models[model_name].coef_, dtype=float)
      if coefs_arr.ndim == 1:
          n_features = coefs_arr.shape[0]
          lr.coef_ = coefs_arr
          lr.intercept_ = float(models[model_name].intercept_)
      elif coefs_arr.ndim == 2:
          n_targets, n_features = coefs_arr.shape
          lr.coef_ = coefs_arr
          intercept_arr = np.asarray(models[model_name].intercept_, dtype=float)
          if intercept_arr.shape == ():
              # same scalar intercept for all targets
              intercept_arr = np.full(n_targets, float(models[model_name].intercept_))
          elif intercept_arr.shape != (n_targets,):
              raise ValueError("For multi-output, intercept must be length n_targets.")
          lr.intercept_ = intercept_arr
      else:
          raise ValueError("`coefs` must be 1D (single-output) or 2D (multi-output).")

      if len(features[model_name]) != n_features:
          raise ValueError("Length of feature_names must match number of coefficients/features.")

      # Minimal attributes sklearn checks for during predict()
      lr.n_features_in_ = n_features
      lr.feature_names_in_ = np.array(features[model_name], dtype=object)

      # Optional extras (not required for predict, but nice to have)
      lr.rank_ = n_features
      lr.singular_ = np.ones(n_features, dtype=float)
      LR_models[model_name]=lr

  return LR_models

def _model_performance(LR_models, turnup, start_baseline, end_baseline):
  from sklearn.metrics import mean_absolute_error, root_mean_squared_error, r2_score, mean_absolute_percentage_error
  
  res=[]
  turnup_targets={}
  for ycol in LR_models.keys():
      turnup_targets[ycol]={}
      turnup_baseline=turnup[(turnup.Wedge_Time.dt.date>=start_baseline) & (turnup.Wedge_Time.dt.date<=end_baseline)][list(LR_models[ycol].feature_names_in_) + [ycol,'MBS_Current_reel_ID']]
      turnup_baseline['MBS_Current_reel_ID']=turnup_baseline['MBS_Current_reel_ID'].astype("str")
      y_pred=LR_models[ycol].predict(turnup_baseline.drop([ycol,'MBS_Current_reel_ID'],axis=1))
      y_test=turnup_baseline[ycol]
      res.append(pd.DataFrame([{"property":ycol,"MAE":round(mean_absolute_error(y_test, y_pred),3),"R2":round(r2_score(y_test, y_pred),2),"RMSE":round(root_mean_squared_error(y_test, y_pred),3),"MAPE":round(mean_absolute_percentage_error(y_test, y_pred)*100,1),"target":"baseline"}]))
      turnup_targets[ycol]["baseline"]=turnup_baseline
      for d in list(daterange(pd.to_datetime("2025-10-1"), pd.to_datetime("2026-1-1"), jump="month"))[:-1]:
          df=turnup[(turnup.Wedge_Time.dt.date>=d.date()) & (turnup.Wedge_Time.dt.date < (d + pd.DateOffset(months=1)).date())][list(LR_models[ycol].feature_names_in_) + [ycol,'MBS_Current_reel_ID']]
          df['MBS_Current_reel_ID']=df['MBS_Current_reel_ID'].astype("str")
          if len(df)>0:
              turnup_targets[ycol][d.strftime("%Y%b")]=df
              y_pred=LR_models[ycol].predict(df.drop([ycol,'MBS_Current_reel_ID'],axis=1))
              y_test=df[ycol]
              res.append(pd.DataFrame([{"property":ycol,"MAE":round(mean_absolute_error(y_test, y_pred),3),"R2":round(r2_score(y_test, y_pred),2),"RMSE":round(root_mean_squared_error(y_test, y_pred),2),"MAPE":round(mean_absolute_percentage_error(y_test, y_pred)*100,1),"target":d.strftime("%Y%b")}]))
  res = pd.concat(res,axis=0)
  
  return res, turnup_targets

def _rolling_lab_performance(turnup, strength_property, window):
  import numpy as np

  if "Wedge_Time" in turnup.columns:     
      turnup = turnup.set_index("Wedge_Time")
  turnup.sort_index(inplace=True)
  perc = 2.5

  def p_low(x):
      return np.percentile(x, perc)
  
  def p_high(x):
      return np.percentile(x, 100-perc)
  
  rolling_stats = (
      turnup
      .groupby("AB_Grade_ID")[[strength_property]]
      .rolling(window=window, min_periods=1)  
      .agg(["mean", "std", "median", p_low, p_high])
  )

  return rolling_stats[strength_property], strength_property

def _lab_performance(LR_models, turnup, start_baseline, end_baseline):
  import pandas as pd

  res=[]
  for grade in ["3200115", "6010085", "6010100", "6010120"]:   
      for ycol in LR_models.keys():
          turnup_baseline=turnup[(turnup.Wedge_Time.dt.date>=start_baseline) & (turnup.Wedge_Time.dt.date<=end_baseline) & (turnup.AB_Grade_ID==grade)][list(LR_models[ycol].feature_names_in_) + [ycol]]                        
          res.append(pd.DataFrame([{"property":ycol,"grade":grade,"mean":turnup_baseline[ycol].mean(),"sd":turnup_baseline[ycol].std(),"target":"baseline"}]))        
      for d in list(daterange(pd.to_datetime("2025-10-1"), pd.to_datetime("2026-1-1"), jump="month"))[:-1]:
          for ycol in LR_models.keys():
              df=turnup[(turnup.Wedge_Time.dt.date>=d.date()) & (turnup.Wedge_Time.dt.date < (d + pd.DateOffset(months=1)).date()) & (turnup.AB_Grade_ID==grade)][list(LR_models[ycol].feature_names_in_) + [ycol]]
              if len(df)>0:                
                  res.append(pd.DataFrame([{"property":ycol,"grade":grade,"mean":df[ycol].mean(),"sd":df[ycol].std(),"target":d.strftime("%Y%b")}]))            
          
  res = pd.concat(res,axis=0)
  return res

def _process_features(raw_data=None):
    process_features=["Speed","Production_Rate__T/h_", "Current_reel_weight","Current_reel_width","Current_reel_length","Current_basis_weight","Current_reel_moisture_average(reel)","Actual_moisture","Current_reel_dry_average","BSW_2_sigma","Mois_Size_Press_2_sigma", "Mois_2_sigma", "Contact_pressure_reel_holders", "Reel_discharge_pressure", "Draw_meaurement_pope_reel_FS", "Draw_measurement_pope_reel_DS", "Total_draw_measurement_pope_reel", "Contact_pressure_secondary_arm_OS", "Contact_pressure_secondary_arm_DS","Draw_AD7-PR","Draw_SS-AD6", "Draw_AD6-AD7", "DG4_Temperature_Inlet_Air", "Cylinder_36_steam_pressure", "Cylinder_36_differential_pressure", "DG5_Temperature_Inlet_Air", "Cylinder_37_steam_pressure", "Cylinder_38_differential_pressure", "Cylinder_37_differential_pressure", "Cylinder_38_steam_pressure", "Cylinder_39_steam_pressure", "Cylinder_36-39_steam_pressure", "Cylinder_39_differential_pressure", "Cylinder_40-53_differential_pressure", "Cylinder_40-53_steam_pressure", "Web_tension_AD6", "Steam_flow_to_AfterDryers", "Steam_flow_to_AfterDryers_sqm","Steam_flow_to_AfterDryers_index","DG4_Moisture_content_Outlet_Air", "DG5_Moisture_content_Outlet_Air", "DG_4-5_zero_level", "DG_4-5_zero_level_(Pa)", "DG5_Ventilator_Revolution_Output", "DG4_Ventilator_Revolution_Output", "AD7_fabric_tension_bottom", "AD6_fabric_tension", "AD6_speed", "AD7_speed_top", "AD7_speed_bottom", "Draw_PD5-SS", "SpeedSizer_Linepressure_DS", "SpeedSizer_Linepressure_FS", "Starch_uptake_by_paper_Bottom_Roll__g/m2_", "Starch_uptake_by_paper_Top_Roll__g/m2_", "Pressure_of_Starch_flow_Speedsizer_Bottom_Roll~^0", "Starch_consumption_Bottom___m³/h_", "Starch_consumption_Top__m³/h_", "Consistency_starch_main_line", "Pressure_of_Starch_flow_Speedsizer_Top_Roll", "Starch_application_FW_in_ml", "Starch_application_BW_in_ml", "Starch_Top_Roll__ml/m²_", "Starch_Bottom_Roll__ml/m²_", "AirTurn_Temperature", "Airturn_pillow_pressure", "Rod_Pressure_Bottom_Roll", "Rod_clamping_pressure_Bottom_Roll", "Air_pressure_of_rod_clamping_hose_Bottom_Roll", "Rod_clamping_pressure_Top_Roll", "Rod_pressure_Top_Roll", "Speed_Size_Press", "Air_pressure_of_rod_clamping_hose_Top_Roll", "Steam_flow_to_starch_kitchen", "Enzyme_flow_Slurry_1", "Slurry_1_dosing_screw_rotation", "Slurry_1_level", "Dilution_water_flow_slurry_1", "Flow_slurry_1_to_reactor", "Slurry_1_pumping_to_reactor", "Enzyme_flow_Slurry_2", "Slurry_2_dosing_screw_rotation", "Slurry_2_level", "Dilution_water_flow_slurry_2", "Flow_slurry_2_to_reactor", "Slurry_2_pumping_to_reactor", "Enzyme_flow_Slurry_3", "Slurry_3_dosing_screw_rotation", "Slurry_3_level", "Dilution_water_flow_slurry_3", "Flow_slurry_3_to_reactor", "Slurry_3_pumping_to_reactor", "Pressure_slurry_pipe_3", "Pressure_slurry_main_pipe", "Reactor_steam_pressure", "Reactor_Temperature", "Reactor_level", "Starch_flow_to_inactivation", "Pressure_to_inactivation", "Temperature_inactivation", "Pressure_after_inactivation", "Storage_tank_level", "Storage_tank_temperature", "Dilution_water_storage_tank", "Pressure_starch_main_line", "Flow_starch_main_line_to_working_tank_1~^0", "Dilution_water_working_tank_1", "Temperature_starch_working_tank_1", "Level_storage_tank_2~^0", "Differential_pressure_filter_storage_tank_1", "Flow_starch_main_line_to_working_tank_2~^0", "Dilution_water_working_tank_2", "Temperature_starch_working_tank_2", "Level_storage_tank_2", "Differential_pressure_filter_storage_tank_2", "Draw_PS-PD1", "Draw_PD2-PD3", "Draw_PD4-PD5", "Draw_PD3-PD4", "Draw_PD1-PD2", "Cylinder_1_differential_pressure", "Cylinder_1_steam_pressure", "Cylinder_2_steam_pressure", "Cylinder_3_differential_pressure", "Cylinder_2_differential_pressure", "Cylinder_3_steam_pressure", "Cylinder_4_differential_pressure", "Cylinder_5_steam_pressure", "Cylinder_4_steam_pressure", "Cylinder_5_differential_pressure", "Cylinder_1-5_steam_pressure", "Cylinder_1-5_fresh_steam", "Cylinder_6-15_differential_pressure", "Cylinder_6-15_steam_pressure", "Cylinder_1-5_steam_temperature", "Cylinder_14_differential_pressure", "Cylinder_16-24_steam_pressure", "Cylinder_25-35_steam_pressure", "Moisture_out_of_PreDryer", "Cylinder_6-35_differential_pressure", "Inlet_Air_2_Temperature", "Inlet_Air_1_Temperature", "Steam_flow_to_PreDryers", "Steam_flow_to_PreDryers_sqm","Electricity_index","Electricity_sqm","Steam_flow_to_PreDryers_index","DG_1-3_zero_point", "DG1_Ventilator_Revolution_Output", "DG1_Moisture_content_Outlet_Air", "DG1_temperature_Inlet_Air", "DG1_zero_point", "DG2_Moisture_content_Outlet_Air", "DG2_temperature_Inlet_Air", "DG2_Ventilator_Revolution_Output", "DG2-3_zero_point", "DG3_Moisture_content_Outlet_Air", "DG3_temperature_Inlet_Air", "DG3_Ventilator_Revolution_Output", "PD1_Fabric_tension", "PD2_Fabric_tension", "PD5_fabric_tension_bottom", "PD4_fabric_tension", "PD4_fabric_tension_bottom", "PD5_fabric_tension_top", "ProRelease_1_LoVac", "ProRelease_2_LoVac", "ProRelease_3_LoVac", "ProRelease_4_LoVac", "ProRelease_5_LoVac", "ProRelease_6_LoVac", "ProRelease_7_LoVac", "Compressor_1_outgoing_pressure", "Compressor_2_outgoing_pressure", "Speed_PD4_bottom", "Speed_PD4_top", "Speed_PD5_top", "Speed_PD5_bottom", "Speed_PD1", "Speed_PD3", "Speed_PD2", "Draw_WS-PS", "PickUp_Tension", "Vacuum_Zone_1_PickUp", "Vacuum_presszone_of_suction-press_roll", "Vacuum_holding/pre_positions_of_suction-press_roll", "Vacuum_uhle-box_Pick-Up", "Vacuum_uhle-box_bottom_felt", "Dewatering_Suction_Press_Roll", "Dewatering_Shoe_press", "Dewatering_Pick-Up", "Linepressure_1st_press_FS__bar_", "Linepressure_2nd_press_FS__bar_", "Linepressure_1st_press_DS__bar_", "Linepressure_2nd_press_DS__bar_", "Linepressure_shoe_press__bar_", "Uhle_box_1_flow___l/min_", "Uhle_box_2_flow___l/min_", "Top_Felt_Tension", "Bottom_Felt_Tension", "Total_Dewatering_Pick-Up", "Dewatering_First_Press_Roll", "Total_Dewatering_Bottom_Felt", "Bottom_wire_tension", "Vacuum_top_wire_suction_box_zone_1", "Vacuum_top_wire_suction_box_zone_2", "Vacuum_formning_roll", "Dewatering_top_wire_suction_box_zone_1", "Dewatering_Jet_channel", "Dewatering_top_wire_suction_box_zone_2", "Vacuum_suction_box_9", "Vacuum_wet_suction_box", "Vacuum_sheet_seperator_box", "Vacuum_suction_box_10", "Vacuum_suction_box_11", "Vacuum_wire_suction_box_1", "Vacuum_wire_suction_box_2", "Consistency_white_water", "White_water_temperature", "Conductivity_white_water_B46", "Top_wire_tenstion", "pH_measurement_white_water_B41", "Forming_Wire_Speed", "Fresh_water_main_pipe_pressure", "Differential_pressure_retention_aid_filter", "Inlet_pressure_TrumpJet_station_A1-A4", "Differential_pressure_A1-A4_between_stock_and_chemical", "Inlet_pressure_TrumpJet_station_C1-C4", "Differential_pressure_C1-C4_between_stock_and_chemical", "Pre_pressure_TrumpJet", "Stock_to_TrumpJet", "Mixing_water_to_TrumpJet", "Pressure_of_pressure_amplifying_pump_for_retention_aid_injection", "Flow_of_pressure_amplyfing_pump", "Bentonite_filter_differential_pressure", "Bentonite_flow_station_B1_TrumpJet", "Bentonite_flow_station_B2_TrumpJet", "Bentonite_flow_station_B4_TrumpJet", "Bentonite_flow_station_B3_TrumpJet", "Pressure_Bentonite_TrumpJet", "Differential_pressure_B1-B4_between_stock_and_chemical", "Backflow_cross-flow_distributor_dilution_water~^0", "Backflow_cross-flow_distributor_stock~^0", "Headbox_pressure", "Headbox_pressure_DS", "Headbox_pressure_FS", "Headbox_total_flow", "Lip_settings", "Jet/wire_ratio", "Thick_Stock_Consistency__%_", "Thick_Stock_Flow__l/min_", "Machine_chest_consistency", "Dilution_water_deculator_pressure", "Sorter_stock_power", "Dilution_water_deculator_temperature", "Stock_deculator_pressure", "Stock_deculator_temperature", "Dilutionwater_pump_power", "Stock_pump_power", "Short_fibre_flow", "Long_fibre_flow", "Short_fibre_B06_consistency", "Long_fibre_consistency_B07", "Dry_broke_flow", "Wet_broke_flow", "pH-Messung_Verdünnungswasser__2..12_pH_", "Wet_broke_consistency", "Sludge_addition_to_stock", "Free_gas_before_dilution_water_deculator_measurement_1~^0", "Free_gas_before_dilution_water_deculator_measurement_2", "Dissolved_gas_before_dilution_water_deculator", "Free_gas_after_stock_deculator~^0", "Dissolved_gas_after_stock_deculator_measurement_1", "Dissolved_gas_after_stock_deculator_measurement_2", "Ash_measurement_HC-line", "Stock_Valve_Opening_From_Machine_Chest", "Dry_Broke_Consistancy__%_", "Pulper_consistency", "ATS1_power", "ATS1_differential_pressure", "ATS1_light_reject_flow", "ATS2_differential_pressure", "ATS2_light_reject_flow", "Combisorter_1_power", "Combisorter_2_power", "Combisorter_3_power", "Contaminex_1_power", "Contaminex_2_power", "Contaminex_3_power", "Multifractor_1_long_fibre_flow", "Multifractor_1_short_fibre_flow", "Multifractor_1_Long_fibre_fraction", "Multifractor_1_consistency", "Multifractor_2_long_fibre_flow", "Multifractor_2_short_fibre_flow", "Multifractor_2_long_fibre_fraction", "Multifractor_2_consistency", "Multifractor_3_long_fibre_flow", "Multifractor_3_short_fibre_flow", "Multifractor_3_long_fibre_fraction", "Multifractor_3_consistency", "LF_screen_1_power", "LF_screen_1_accept_flow", "LF_screen_2_inlet_consistency", "LF_screen_2_power", "LF_screen_3_inlet_consistency", "LF_screen_3_power", "LF_screen_1_reject_flow", "LF_screen_2_accept_flow", "LF_screen_2_reject_flow", "LF_screen_3_reject_flow", "LF_screen_3_accept_flow", "Steam_flow_from_power_plant_to_PM", "Steam_flow_to_heat_exchangers", "Steam_flow_to_hall_heating", "Steam_flow_to_white_water_heating", "Steam_flow_to_steam_box", "Steam_flow_to_PM", "Pressure_main_steam_line", "Steam_temperature_for_PM", "Steam_pressure_for_PM", "Steam_energy_from_power_plant_to_paper_plant", "Condensate_energy_from_paper_plant_to_power_plant", "Condensate_conductivity", "Total_condensate_flow", "Freshwater_warm__l/min_", "Freshwater_retention__l/min_", "Freshwater_to_Machine_Tank__l/min_", "Freshwater_pressure_from_the_city__bar_","Starch_uptake__g/m2_","ratio_starch","Fibre_usage__T/h_","MC_SF_LF_Demand",'Flow_starch_main_line_to_working_tank',"concentration_starch_working_tank_1","concentration_starch_working_tank_2","SCT_CD_index"]
    if raw_data is None:
        return process_features
    return [v for v in process_features if v in raw_data.columns.to_list()]

def _cost_features(raw_data=None):
    cost_features = [_agg_cost_label(), 'Combined_cost__€/T_','Fibre_cost__€/T_','Steam__€/T_','Electricity__€/T_','Starch__€/T_','Sizing_Agent__€/T_','Combined_cost_current_€/h_',"Steam_current__€/h_","Electricity_current__€/h_","Starch_current__€/h_","Overprocessing_cost__€/T_"]
    if raw_data is None:
        return cost_features
    return [v for v in cost_features if v in raw_data.columns.to_list()]

def _quality_features():
    return ["MBS_SCT_MD","MBS_SCT_CD","MBS_Burst","MBS_CMT30","Overprocessing_percentage"]

def _component_features(raw_data=None):
    component_features = ["Retention_Aid_mass_flow__g/T_", "Bentonite_1_mass_flow__g/T_", "Bentonite_2_mass_flow__g/T_", "Fixative_2_mass_flow__g/T_", "Starch_mass_flow__kg/T_", "Act_Deaerator_mass_flow__g/T_", "Defoamer_mass_flow__g/T_", "Sizing_Agent__g/T_", "Dry_Strength_Agent_mass_flow__kg/T_", "Natriumhydroxide_mass_flow__g/T_", "CO2_mass_flow__g/T_", "Electricity__kWh/T_", "Steam__kWh/T_", "Fibre_usage__T/T_","Steam__kW"]
    if raw_data is None:
        return component_features
    return [v for v in component_features if v in raw_data.columns.to_list()]

def _costs_to_consider():
    return ['Steam__€/T_','Electricity__€/T_','Starch__€/T_','Fibre_cost__€/T_']

def _costs_to_consider2():
    return ['Steam__€/T_','Electricity__€/T_','Starch__€/T_','Chemicals__€/T_','Fibre_cost__€/T_']

def _consumptions_to_consider():
    return ['Steam__kWh/T_','Electricity__kWh/T_',"Starch_mass_flow__kg/T_","Fibre_usage__T/T_"]

def _prices_to_consider():
    return ['Steam_price','Electricity_price','Starch_price','Fibre_price']

def _agg_cost_label():
    return "Aggregated_cost__€/T_"

def _agg_cost_label2():
    return "Combined_cost__€/T_"

def _chemical_names():
    return ['Retention_Aid__€/T_','Bentonite_1__€/T_','Bentonite_2__€/T_','Fixative_2__€/T_','Deaerator__€/T_','Defoamer__€/T_','Sizing_Agent__€/T_','Dry_Strength_Agent__€/T_','Natriumhydroxide__€/T_']

def _steam_names():
    return ['Steam_Predryers__€/T_','Steam_Afterdryers__€/T_','Steam_Starchkitchen__€/T_','Steam_Heatexchangers__€/T_','Steam_Whitewater__€/T_']

def _electricity_names():
    return ['Electricity_Wiresection__€/T_', 'Electricity_Press_and_Steambox__€/T_', 'Electricity_Freqconverters__€/T_', 'Electricity_Other__€/T_', 'Electricity_Predryer__€/T_', 'Electricity_Afterdryer__€/T_', 'Electricity_Specific__€/T_']

def _steam_consumption_names():
    return ['Steam_Predryers__kWh/T_','Steam_Afterdryers__kWh/T_','Steam_Starchkitchen__kWh/T_','Steam_Heatexchangers__kWh/T_','Steam_Whitewater__kWh/T_']

def _electricity_consumption_names():
    return ['Electricity_Wiresection__kWh/T_', 'Electricity_Press_and_Steambox__kWh/T_', 'Electricity_Freqconverters__kWh/T_', 'Electricity_Other__kWh/T_', 'Electricity_Predryer__kWh/T_', 'Electricity_Afterdryer__kWh/T_', 'Electricity_Specific__kWh/T_']

def _chemical_consumption_names_raw():
    return ['Retention_Aid_mass_flow__g/T_','Bentonite_1_mass_flow__g/T_','Bentonite_2_mass_flow__g/T_','Fixative_2_mass_flow__g/T_', 'Act_Deaerator_mass_flow__g/T_','Defoamer_mass_flow__g/T_','Sizing_Agent__g/T_','Dry_Strength_Agent_mass_flow__g/T_','Natriumhydroxide_mass_flow__g/T_']

def _chemical_consumption_names():
    return [v.replace("_mass_flow","") for v in _chemical_consumption_names_raw()]

def _price_names(): 
    return ['Fibre_price','Steam_price','Electricity_price','Starch_price','Natriumhydroxide_price','Defoamer_price','Deaerator_price','Sizing_Agent_price', 'Dry_Strength_Agent_price','Retention_Aid_price','Bentonite_price','Fixative_2_price']

def _chemical_prices_names():
    return ['Retention_Aid_price','Bentonite_price','Bentonite_price','Fixative_2_price', 'Deaerator_price','Defoamer_price','Sizing_Agent_price','Dry_Strength_Agent_price','Natriumhydroxide_price']


def _overprocessing_vars():
    return ['Overprocessing_SCT_CD', 'Overprocessing_Burst', 'Overprocessing_CMT30']
    
def _cost_influencers_1():
    return ['Production_Rate__T/h_','Speed','Actual_moisture',
        'Moisture_out_of_PreDryer','Lip_settings','Draw_PS-PD1',
        'Draw_PD4-PD5','Draw_PD3-PD4','Draw_PD1-PD2',
        'Draw_PD5-SS','Jet/wire_ratio','Vacuum_uhle-box_Pick-Up']
    
def _cost_influencers_2():
    return ['Dewatering_top_wire_suction_box_zone_2','Linepressure_1st_press_FS__bar_','Linepressure_1st_press_DS__bar_',
            'Linepressure_2nd_press_FS__bar_','Linepressure_2nd_press_DS__bar_','Linepressure_shoe_press__bar_',
            'Vacuum_suction_box_10','Consistency_white_water','White_water_temperature',
            'Conductivity_white_water_B46','pH_measurement_white_water_B41','Current_basis_weight']
        
def _cost_influencers_3():
    return ["Starch_uptake__g/m2_",'Starch_uptake_by_paper_Bottom_Roll__g/m2_','Starch_uptake_by_paper_Top_Roll__g/m2_',
        'Consistency_starch_main_line',"concentration_starch_working_tank_1","concentration_starch_working_tank_2",
        'Rod_Pressure_Bottom_Roll','Rod_pressure_Top_Roll',
        'Bentonite_1_mass_flow__g/T_','Bentonite_2_mass_flow__g/T_','Retention_Aid_mass_flow__g/T_']

def _cost_influencers_4():
    return ['Steam_flow_to_PreDryers','Steam_flow_to_AfterDryers']

def _strength_influencers():
    return ["Starch_uptake__g/m2_",'Starch_uptake_by_paper_Bottom_Roll__g/m2_','Starch_uptake_by_paper_Top_Roll__g/m2_',
        'Consistency_starch_main_line',"concentration_starch_working_tank_1","concentration_starch_working_tank_2",
        'Rod_Pressure_Bottom_Roll','Rod_pressure_Top_Roll','Current_basis_weight',
        "Jet/wire_ratio"
        ]

def _strength_df(grade_data_process_clustered, setpoint_df, igrade):
  sp=setpoint_df[(setpoint_df.AB_Grade_ID==igrade)].drop("AB_Grade_ID",axis=1).pivot(index=["property"],columns="variable",values="value").reset_index()
  quality_df_=grade_data_process_clustered[['MBS_Current_reel_ID','target'] + _quality_features()].copy()
  quality_df_=quality_df_.rename(columns={"target":"cluster"})
  
  quality_df_res=pd.merge(pd.melt(quality_df_,id_vars=['MBS_Current_reel_ID','cluster'],var_name="property").dropna(),sp, on=["property"],how="left").dropna()
  return quality_df_res

def _acceptable_clusters(grade_data_process_clustered, setpoint_df, igrade, valid_pct):
    import numpy as np

    sp=setpoint_df[(setpoint_df.AB_Grade_ID==igrade)].drop("AB_Grade_ID",axis=1).pivot(index=["property"],columns="variable",values="value").reset_index()
    quality_df_=grade_data_process_clustered[["cluster"] + _quality_features()].copy()

    percentile_name=f"P{round(100-valid_pct)}"
    quality_df_res=pd.merge(pd.melt(quality_df_[_quality_features()+["cluster"]],id_vars=["cluster"],var_name="property").dropna(),sp, on=["property"],how="left").groupby(["cluster", "property"]).agg(percentile=("value", lambda x: np.percentile(x, 100-valid_pct)), min_value=("min", lambda x: min(x)), count=("value", lambda x: len(x))).reset_index().rename(columns={"percentile":percentile_name})
    quality_df_res[percentile_name]=round(quality_df_res[percentile_name],2)
    quality_df_res["valid"]=np.where(quality_df_res[percentile_name]>=quality_df_res["min_value"],"ok","bad")
    quality_df_res.dropna(inplace=True)
    quality_df_res["n_total"]=quality_df_res.groupby(["cluster"])["valid"].transform(lambda x : len(x))

    acceptable_res=quality_df_res[(quality_df_res[percentile_name]>=quality_df_res.min_value) & (quality_df_res["count"]>1)][["cluster","property","n_total"]]
    #acceptable_res=quality_df_res[(quality_df_res[percentile_name]>=quality_df_res.min_value)][["cluster","property","n_total"]]
    acceptable_res_total=acceptable_res.groupby(["cluster"]).agg(n_valid =("n_total", "size"), n_total =("n_total", "first")).reset_index()
    acceptable_res_total=acceptable_res_total[(acceptable_res_total.n_valid>=acceptable_res_total.n_total)][["cluster"]]
    return acceptable_res_total.cluster.to_list(),quality_df_res

def _quality_limits(setpoint_df, igrade, iclustered_quality):
        return setpoint_df[(setpoint_df.AB_Grade_ID==igrade) & (setpoint_df.property==iclustered_quality)]

def _pls_transformation(raw_data, process_data, igrade):
  from sklearn.preprocessing import StandardScaler
  from sklearn.cross_decomposition import PLSRegression

  # ---- config ----
  n_components = 4
  y_col = _agg_cost_label()
  X_cols = _process_features(raw_data)

  # ---- filter data for selected grade ----
  df_all = process_data
  df_features = df_all[df_all["AB_Grade_ID"] == igrade].copy()

  if df_features.empty:
      # Return empty structures gracefully
      return (pd.DataFrame(columns=[f"PLS {i}" for i in range(1, n_components + 1)]),
              pd.DataFrame(index=X_cols, columns=[f"PLS {i}" for i in range(1, n_components + 1)]),
              df_features)

  # ---- X / y preparation (numeric + median impute) ----
  X = df_features[X_cols].apply(pd.to_numeric, errors="coerce")
  y = pd.to_numeric(df_features[y_col], errors="coerce")

  X = X.fillna(X.median(numeric_only=True))
  y = y.fillna(y.median())

  # ---- scale X and y (PLS prefers centered/scaled) ----
  x_scaler = StandardScaler()
  y_scaler = StandardScaler()

  Xs = x_scaler.fit_transform(X.values)
  ys = y_scaler.fit_transform(y.values.reshape(-1, 1)).ravel()

  # ---- choose safe number of components ----
  max_comp = int(min(Xs.shape[0] - 1, Xs.shape[1]))  # <= min(n_samples-1, n_features)
  if max_comp < 1:
      # Not enough data to fit PLS; return empties with correct shapes
      comp_names = [f"PLS {i}" for i in range(1, n_components + 1)]
      return (pd.DataFrame(columns=comp_names),
              pd.DataFrame(index=X_cols, columns=comp_names),
              df_features)

  n = min(n_components, max_comp)

  # ---- fit PLS ----
  pls = PLSRegression(n_components=n, scale=False)  # already scaled
  pls.fit(Xs, ys)

  # ---- outputs to mirror your PCA return signature ----
  comp_names = [f"PLS {i}" for i in range(1, n + 1)]

  # Scores (X-scores): shape (n_samples, n_components)
  df_scores = pd.DataFrame(pls.x_scores_, columns=comp_names, index=df_features.index).reset_index(drop=True)

  # Loadings (X-loadings): shape (n_features, n_components)
  df_loadings = pd.DataFrame(pls.x_loadings_, columns=comp_names, index=X_cols)

  # (Optional) If you want predicted cost back in original units, uncomment:
  # y_pred = y_scaler.inverse_transform(pls.predict(Xs)).ravel()
  # df_features = df_features.copy()
  # df_features["Aggregated_cost_pred"] = y_pred

  return df_scores, df_loadings, df_features

def _principal_component_scoring(raw_data, process_data, igrade, variable_x_scoring):    
    df_scores, df_loadings, df_features = _pls_transformation(raw_data, process_data, igrade)
    pc = df_loadings[variable_x_scoring].to_frame("weight")
    pc.index.names=["feature"]
    pc=pc.reset_index()
    pc["abs_weight"]=abs(pc["weight"])
    return pc[pc["abs_weight"]>pc["abs_weight"].max()*0.8].sort_values("weight",ascending=False)

def _principal_components_features_scoring(raw_data, process_data, igrade, variable_x_scoring):
    pc=_principal_component_scoring(raw_data, process_data,  igrade, variable_x_scoring)
    return pc.feature.to_list()

def _principal_component_oprange(raw_data, process_data, igrade, principal_oprange):
  if principal_oprange=="cost influencers 1":
      return pd.DataFrame({"feature":_cost_influencers_1()})
  elif principal_oprange=="cost influencers 2":
      return pd.DataFrame({"feature":_cost_influencers_2()})
  elif principal_oprange=="cost influencers 3":
      return pd.DataFrame({"feature":_cost_influencers_3()})
  elif principal_oprange=="cost influencers 4":
      return pd.DataFrame({"feature":_cost_influencers_4()})
  elif principal_oprange=="strength influencers":
      return pd.DataFrame({"feature":_strength_influencers()})
  elif principal_oprange=="all cost influencers":
      return pd.DataFrame({"feature":_cost_influencers_1() + _cost_influencers_2() + _cost_influencers_3()})
  else:    
      df_scores, df_loadings, df_features = _pls_transformation(raw_data, process_data, igrade)
      pc = df_loadings[principal_oprange].to_frame("weight")
      pc.index.names=["feature"]
      pc=pc.reset_index()
      pc["abs_weight"]=abs(pc["weight"])
      
      return pc[pc["abs_weight"]>pc["abs_weight"].max()*0.8].sort_values("weight",ascending=False)
  
def _principal_components_features_oprange(raw_data, process_data, igrade, principal_oprange):
  pc=_principal_component_oprange(raw_data, process_data, igrade, principal_oprange)
  return pc.feature.to_list()

def _principal_component_pca(raw_data, process_data, igrade, principal_pca):
  df_scores, df_loadings, df_features = _pls_transformation(raw_data, process_data, igrade)
  pc = df_loadings[principal_pca].to_frame("weight")
  pc.index.names=["feature"]
  pc=pc.reset_index()
  pc["abs_weight"]=abs(pc["weight"])
  return pc[pc["abs_weight"]>pc["abs_weight"].max()*0.8].sort_values("weight",ascending=False)

def _principal_components_features_pca(raw_data, process_data, igrade, principal_pca):
  pc=_principal_component_pca(raw_data, process_data, igrade, principal_pca)
  return pc.feature.to_list()

def _principal_components(raw_data, process_data, igrade):
  df_scores, df_loadings, df_features = _pls_transformation(raw_data, process_data, igrade)
  return df_loadings.columns.to_list()

def impute_outside_limits_with_grade_median(
    df: pd.DataFrame,
    var: str,
    low: float,
    high: float,
    grade_col: str = "AB_Grade_ID",
    treat_na_as_bad: bool = True,
    inplace: bool = False,
) -> pd.DataFrame:
    """
    Impute values of `var` that fall outside [low, high] (and optionally NaNs)
    with the median of `var` within each grade group.
 
    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe.
    var : str
        Name of the variable/column to check and impute.
    low, high : float
        Inclusive bounds. Values < low or > high are imputed.
    grade_col : str
        Column used to group grades (default: "AB_Grade_ID").
    treat_na_as_bad : bool
        If True, NaNs are also imputed with grade median.
    inplace : bool
        If True, modifies df in place and returns it. Otherwise returns a copy.
 
    Returns
    -------
    pd.DataFrame
        DataFrame with imputed values in `var`.
    """
    if var not in df.columns:
        raise KeyError(f"Column '{var}' not found in df.")
    if grade_col not in df.columns:
        raise KeyError(f"Grade column '{grade_col}' not found in df.")
    if low > high:
        raise ValueError(f"low ({low}) must be <= high ({high}).")
 
    out = df if inplace else df.copy()
 
    # Ensure numeric; non-numeric become NaN (and may be imputed if treat_na_as_bad=True)
    out[var] = pd.to_numeric(out[var], errors="coerce")
 
    # Grade-level median (ignores NaN by default)
    grade_median = out.groupby(grade_col)[var].transform("median")
 
    mask_bad = (out[var] < low) | (out[var] > high)
    if treat_na_as_bad:
        mask_bad = mask_bad | out[var].isna()
 
    out.loc[mask_bad, var] = grade_median[mask_bad]
    return out

def detect_outliers(
    df: pd.DataFrame,
    value_col: str,
    method: str = "robust_z",
    group_col: str = None,
    window: int = None,
    threshold: float = 3.0,
    contamination: float = 0.01,
) -> pd.Series:
    """
    Returns a boolean Series indicating outliers.

    Parameters
    ----------
    df : pd.DataFrame
    value_col : str
        Column with values to analyze
    method : str
        One of: "robust_z", "iqr", "rolling_robust_z", "isolation_forest"
    group_col : str, optional
        Apply detection per group (e.g., grade)
    window : int, optional
        Window size for rolling method
    threshold : float
        Threshold for z-score methods
    contamination : float
        Used only for isolation forest

    Returns
    -------
    pd.Series (bool)
    """
    import numpy as np
    import pandas as pd
    from sklearn.ensemble import IsolationForest
     
    def _robust_z(x):
        median = np.median(x)
        mad = np.median(np.abs(x - median))
        if mad == 0:
            return pd.Series([False] * len(x), index=x.index)
        z = 0.6745 * (x - median) / mad
        return np.abs(z) > threshold

    def _iqr(x):
        q1 = x.quantile(0.25)
        q3 = x.quantile(0.75)
        iqr = q3 - q1
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr
        return (x < lower) | (x > upper)

    def _rolling_robust_z(x):
        if window is None:
            raise ValueError("window must be provided for rolling method")

        rolling_median = x.rolling(window).median()
        rolling_mad = x.rolling(window).apply(
            lambda v: np.median(np.abs(v - np.median(v))), raw=True
        )

        z = 0.6745 * (x - rolling_median) / rolling_mad
        return np.abs(z) > threshold

    def _isolation_forest(x):
        model = IsolationForest(
            contamination=contamination,
            random_state=42
        )
        preds = model.fit_predict(x.values.reshape(-1, 1))
        return pd.Series(preds == -1, index=x.index)

    method_map = {
        "robust_z": _robust_z,
        "iqr": _iqr,
        "rolling_robust_z": _rolling_robust_z,
        "isolation_forest": _isolation_forest,
    }

    if method not in method_map:
        raise ValueError(f"Unknown method: {method}")

    func = method_map[method]

    if group_col:
        return df.groupby(group_col)[value_col].transform(func)
    else:
        return func(df[value_col])

def impute(
    df: pd.DataFrame,
    value_col: str,
    outlier_flag, # <-- Series / array-like
    method: str = "median",
    group_col: str = None,
    constant_value=None,
    time_col: str = None,
    inplace: bool = False,
    new_col: str = None,
):
    """
    Impute values using an external outlier flag.

    Parameters
    ----------
    df : pd.DataFrame
    value_col : str
    outlier_flag : array-like or pd.Series (bool)
        True = outlier (will be imputed)
    method : str
        "median", "median_by_group", "ffill", "constant"
    group_col : str, optional
    constant_value : any
    time_col : str, optional
    inplace : bool
    new_col : str, optional

    Returns
    -------
    pd.Series or None
    """

    # Convert flag to Series aligned with df
    flag = pd.Series(outlier_flag, index=df.index)

    if len(flag) != len(df):
        raise ValueError("outlier_flag must have same length as df")

    # Copy values
    s = df[value_col].copy()

    # Replace flagged values with NaN
    s[flag] = np.nan

    # ---- Imputation ----
    if method == "median":
        result = s.fillna(s.median())

    elif method == "median_by_group":
        if group_col is None:
            raise ValueError("group_col required for median_by_group")

        result = s.fillna(
            df.groupby(group_col)[value_col].transform("median")
        )

    elif method == "ffill":
        if time_col:
            order = df[time_col].argsort()
            s_sorted = s.iloc[order].ffill()

            result = pd.Series(index=s.index, dtype=float)
            result.iloc[order] = s_sorted
        else:
            result = s.ffill()

    elif method == "constant":
        if constant_value is None:
            raise ValueError("constant_value must be provided")

        result = s.fillna(constant_value)

    else:
        raise ValueError(f"Unknown method: {method}")

    # ---- Output ----
    if inplace:
        target_col = new_col if new_col else value_col
        df[target_col] = result
        return None
    else:
        return result


def _feature_engineering(turnup, setpoint_df, steam_null, clip=True):
    from datetime import datetime
    import numpy as np
    import math

    for v in turnup.drop(['MBS_Current_reel_ID', "AB_Grade_ID", "Wedge_Time"], axis=1).columns.to_list():
        turnup[v] = turnup[v].astype("float32")

    turnup['MBS_Current_reel_ID'] = turnup['MBS_Current_reel_ID'].astype(int)
    turnup['AB_Grade_ID'] = turnup['AB_Grade_ID'].astype(int)
    turnup['Wedge_Time'] = pd.to_datetime(turnup['Wedge_Time'])

    turnup = turnup.assign(
        grammage=turnup["AB_Grade_ID"].mod(1000),
        paper_type=(turnup["AB_Grade_ID"] // 1000).astype("string"),
    )

    turnup = turnup[turnup.grammage.isin([85, 90, 95, 100, 110, 115, 120, 125, 130, 135])]
    turnup = turnup[turnup.paper_type.isin(["3200", "6010", "3300"])]

    update_turnup_grammage(turnup)

    paper_type = pd.get_dummies(turnup["paper_type"])
    turnup = pd.concat([turnup, paper_type], axis=1)

    if clip:
        for v in [v for v in turnup.columns if "speedsizer" not in v.lower() and "speed" in v.lower()]:
            impute_outside_limits_with_grade_median(turnup, v, 950, 1400, inplace=True)

        for v in [v for v in turnup.columns if "speedsizer_linepressure" in v.lower()]:
            impute_outside_limits_with_grade_median(turnup, v, 50, 80, inplace=True)

        # Draw variables (explicit per-variable bounds)
        impute_outside_limits_with_grade_median(turnup, 'Draw_AD7-PR', 0, 0.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Draw_SS-AD6', -0.3, 0.3, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Draw_AD6-AD7', 0, 0.1, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Draw_PD5-SS', -0.4, 0.4, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Draw_PS-PD1', 0, 4, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Draw_PD1-PD2', 0, 1, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Draw_PD2-PD3', 0, 0.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Draw_PD3-PD4', 0, 0.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Draw_PD4-PD5', 0, 0.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Draw_WS-PS', -0.005, 0.005, inplace=True)

        impute_outside_limits_with_grade_median(turnup, 'Pressure_of_Starch_flow_Speedsizer_Top_Roll', 0.35, 0.55, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Pressure_of_Starch_flow_Speedsizer_Bottom_Roll~^0', 0.14, 0.35, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Current_reel_moisture_average(SpeedSizer)', 8.5, 9.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Current_reel_moisture_average(reel)', 7, 10, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Actual_moisture', 7, 10, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Current_reel_dry_average', 60, 120, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Production_Rate__T/h_', 45, 75, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'BSW_2_sigma', 0.5, 3, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Mois_Size_Press_2_sigma', 0.5, 3, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Mois_2_sigma', 0.5, 3, inplace=True)

        for v in ['Contact_pressure_reel_holders', 'Reel_discharge_pressure', 'Contact_pressure_secondary_arm_OS', 'Contact_pressure_secondary_arm_DS']:
            impute_outside_limits_with_grade_median(turnup, v, 40, 60, inplace=True)

        impute_outside_limits_with_grade_median(turnup, 'Moisture_out_of_PreDryer', 8.5, 9.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'CO2_mass_flow__g/T_', 600, 1400, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Consistency_starch_main_line', 10, 30, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Consistency_white_water', 1, 305, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Headbox_consistency', 1, 2, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Thick_Stock_Consistency__%_', 4, 4.4, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Machine_chest_consistency', 4, 4.4, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Short_fibre_B06_consistency', 3.5, 6, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Long_fibre_consistency_B07', 3.5, 6, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Wet_broke_consistency', 2.5, 3.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Pulper_consistency', 1, 10, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Multifractor_1_consistency', 2.5, 3.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Multifractor_2_consistency', 2.5, 3.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Multifractor_3_consistency', 2.5, 3.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'LF_screen_2_inlet_consistency', 0.3, 1.8, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'LF_screen_3_inlet_consistency', 0, 1, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'DG4_Temperature_Inlet_Air', 70, 130, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'DG5_Temperature_Inlet_Air', 70, 130, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'AirTurn_Temperature', 70, 100, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Reactor_Temperature', 40, 100, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Storage_tank_temperature', 80, 120, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Temperature_starch_working_tank_1', 60, 90, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Temperature_starch_working_tank_2', 60, 90, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Cylinder_1-5_steam_temperature', 100, 140, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Inlet_Air_1_Temperature', 10, 50, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Inlet_Air_2_Temperature', 10, 50, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'DG1_temperature_Inlet_Air', 80, 120, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'DG2_temperature_Inlet_Air', 80, 120, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'DG3_temperature_Inlet_Air', 110, 140, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'White_water_temperature', 25, 55, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Dilution_water_deculator_temperature', 25, 55, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Stock_deculator_temperature', 25, 55, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Steam_temperature_for_PM', 150, 185, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Pressure_of_Starch_flow_Speedsizer_Bottom_Roll~^0', 0.1, 0.4, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Pressure_of_Starch_flow_Speedsizer_Top_Roll', 0.3, 0.6, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Starch_consumption_Bottom___m³/h_', 0.5, 3.0, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Starch_consumption_Top__m³/h_', 0.4, 1.6, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Flow_starch_main_line_to_working_tank_2~^0', 2, 8, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Flow_starch_main_line_to_working_tank_1~^0', 3, 14, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Starch_Top_Roll__ml/m²_', 20, 50, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Starch_Bottom_Roll__ml/m²_', 10, 40, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Starch_flow_to_inactivation', 10000, 20000, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Starch_application_FW_in_ml', 10, 40, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Starch_application_BW_in_ml', 5, 25, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Web_tension_AD6', 50, 150, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'AD7_fabric_tension_bottom', 0.5, 1.2, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'AD6_fabric_tension', 1, 1.4, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'PD1_Fabric_tension', 3.5, 4.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'PD2_Fabric_tension', 3.5, 4.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'PD4_fabric_tension', 2.5, 4.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'PD4_fabric_tension_bottom', 1.4, 2.4, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'PD5_fabric_tension_bottom', 0.8, 1.4, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'PD5_fabric_tension_top', 0.3, 1.1, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'PickUp_Tension', 2.4, 4.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Top_Felt_Tension', 3.0, 4.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Bottom_Felt_Tension', 3.0, 4.0, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Bottom_wire_tension', 7.8, 8.2, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'SpeedSizer_Linepressure_DS', 50, 80, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'SpeedSizer_Linepressure_FS', 50, 80, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Linepressure_1st_press_FS__bar_', 75, 80, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Linepressure_1st_press_DS__bar_', 75, 80, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Linepressure_2nd_press_FS__bar_', 90, 110, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Linepressure_2nd_press_DS__bar_', 90, 110, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Linepressure_shoe_press__bar_', 90, 110, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Airturn_pillow_pressure', 30, 90, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Rod_Pressure_Bottom_Roll', 0.4, 3.0, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Rod_pressure_Top_Roll', 0.4, 3.0, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Rod_clamping_pressure_Bottom_Roll', 1.5, 2.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Air_pressure_of_rod_clamping_hose_Bottom_Roll', 1.5, 2.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Rod_clamping_pressure_Top_Roll', 1.5, 2.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Air_pressure_of_rod_clamping_hose_Top_Roll', 1.5, 2.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Pressure_slurry_pipe_3', 0, 12, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Pressure_slurry_main_pipe', 0.5, 5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Reactor_steam_pressure', 0.2, 0.8, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Pressure_to_inactivation', 2, 5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Pressure_after_inactivation', 1.5, 2.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Differential_pressure_filter_storage_tank_1', -0.1, 0.1, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Differential_pressure_filter_storage_tank_2', -0.1, 0.1, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Fresh_water_main_pipe_pressure', 2, 5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Compressor_1_outgoing_pressure', 0.2, 1, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Compressor_2_outgoing_pressure', 0.2, 1, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Differential_pressure_retention_aid_filter', -0.1, 1, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Inlet_pressure_TrumpJet_station_A1-A4', 3, 7, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Differential_pressure_A1-A4_between_stock_and_chemical', 2, 3, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Differential_pressure_C1-C4_between_stock_and_chemical', 0.5, 1.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Pre_pressure_TrumpJet', 2, 5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Pressure_of_pressure_amplifying_pump_for_retention_aid_injection', 5, 15, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Differential_pressure_B1-B4_between_stock_and_chemical', -0.5, 1.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Headbox_pressure', 1, 3, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Headbox_pressure_DS', 1, 3, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Headbox_pressure_FS', 1, 3, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Dilution_water_deculator_pressure', -1.2, -0.8, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Stock_deculator_pressure', -1.2, -0.8, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'ATS1_differential_pressure', -0.2, 1, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'ATS2_differential_pressure', 1, 1.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Pressure_main_steam_line', 4, 8, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Steam_pressure_for_PM', 4, 8, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Auftrag_Stärkeslurry_FW', 4, 20, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Auftrag_Stärkeslurry_BW', 4, 20, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'VariSTEP_div._Hauben+Lueftung_Ventilatoren', 0.2, 1.2, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Dilution_water_working_tank_1', 2.0, 8.0, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Dilution_water_working_tank_2', 1.8, 7.0, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'LF_screen_1_power', 100, 140, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'LF_screen_2_power', 100, 140, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'LF_screen_1_accept_flow', 600, 1000, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'LF_screen_2_accept_flow', 400, 500, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'LF_screen_1_reject_flow', 130, 150, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'LF_screen_2_reject_flow', 35, 50, inplace=True)
        turnup['LF_screen_3_power'] = np.where((turnup['LF_screen_3_power'] > 20) & (turnup['LF_screen_3_power'] < 100), turnup['LF_screen_2_power'], 0)
        turnup['LF_screen_3_accept_flow'] = np.where((turnup['LF_screen_3_accept_flow'] > 150) & (turnup['LF_screen_3_accept_flow'] < 250), turnup['LF_screen_3_accept_flow'], 0)
        turnup['LF_screen_3_reject_flow'] = np.where((turnup['LF_screen_3_reject_flow'] > 10) & (turnup['LF_screen_3_reject_flow'] < 40), turnup['LF_screen_3_reject_flow'], 0)
        turnup['Headbox_total_flow'] = 0
        impute_outside_limits_with_grade_median(turnup, 'Multifractor_1_long_fibre_flow', 200, 400, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Multifractor_2_long_fibre_flow', 200, 400, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Multifractor_3_long_fibre_flow', 200, 400, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Multifractor_1_short_fibre_flow', 600, 1000, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Multifractor_2_short_fibre_flow', 600, 1000, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Multifractor_3_short_fibre_flow', 600, 1000, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Multifractor_1_Long_fibre_fraction', 25, 50, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Multifractor_2_long_fibre_fraction', 25, 50, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Multifractor_3_long_fibre_fraction', 25, 50, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Short_fibre_flow', 8000, 18000, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Long_fibre_flow', 3500, 8500, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'ATS1_light_reject_flow', 130, 160, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'ATS2_light_reject_flow', 130, 160, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Approach_flow_returns', 0.8, 1.3, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Stock_Valve_Opening_From_Machine_Chest', 50, 70, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Condensate_energy_from_paper_plant_to_power_plant', 2, 10, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'ATS1_power', 200, 700, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'ATS2_power', 200, 400, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Combisorter_1_power', 50, 150, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Combisorter_2_power', 50, 150, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Contaminex_1_power', 20, 120, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Contaminex_2_power', 20, 120, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Contaminex_3_power', 0, 120, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Jet/wire_ratio', -50, -10, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Inlet_Thickerner_2__m3/h_', 50, 70, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'Act_Production_Rate_Gross', 40, 80, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'MC_SF_LF_Demand', 20, 80, inplace=True)
        if 'Viscosity_for_working_tank_bottom_roll' in turnup.columns:
            impute_outside_limits_with_grade_median(turnup, 'Viscosity_for_working_tank_bottom_roll', 15, 65, inplace=True)

        impute_outside_limits_with_grade_median(turnup, 'MBS_SCT_MD', 2.2, 4.5, inplace=True)
        impute_outside_limits_with_grade_median(turnup, 'MBS_SCT_CD', 1.4, 2.4, inplace=True)

        for v in ['Moisture_after_SpeedSizer',
                  'Actual_moisture',
                  'SP1:_1-000-FC028_01____NaOH-Dosierung_Pulper_:__MESSWERT',
                  'SP1:_1-000-FC028_02____NaOH-Dosierung_Kurzfaser-SF_:__MESSWE',
                  'SP1:_1-000-FC028_03____NaOH-Dosierung_Langfaser-SF_:__MESSWE',
                  'Starch_uptake_by_paper_Top_Roll__g/m2_',
                  'Starch_uptake_by_paper_Bottom_Roll__g/m2_',
                  'Starch_uptake_by_paper_Bottom_Roll__g/m2_',
                  'Conductivity_white_water_B46',
                  ]:
            outlier_flag = detect_outliers(turnup, v,
                                           method="iqr",
                                           # group_col="AB_Grade_ID"
                                           )

        for v in ['Starch_uptake_by_paper_Top_Roll__g/m2_',
                  'Starch_uptake_by_paper_Bottom_Roll__g/m2_',
                  ]:
            outlier_flag = detect_outliers(turnup, v,
                                           method="iqr",
                                           group_col="AB_Grade_ID"
                                           )

            impute(turnup,
                   value_col=v,
                   outlier_flag=outlier_flag,
                   method="ffill",
                   group_col="AB_Grade_ID",
                   constant_value=None,
                   time_col="Wedge_Time",
                   inplace=True,
                   new_col=None,
                   )

        turnup["MBS_SCT_MD"] = turnup["MBS_SCT_MD"].bfill()
        turnup["MBS_SCT_CD"] = turnup["MBS_SCT_CD"].bfill()
        turnup["MBS_Burst"] = turnup["MBS_Burst"].bfill()

    turnup.loc[(turnup["AB_Grade_ID"] == "6010100") & (turnup["MBS_CMT30"] > 180), "MBS_CMT30"] = turnup[turnup["AB_Grade_ID"] == "6010100"]["MBS_CMT30"].mean()
    turnup.loc[(turnup["AB_Grade_ID"] == "6010100") & (turnup["MBS_CMT30"].isnull()), "MBS_CMT30"] = turnup[turnup["AB_Grade_ID"] == "6010100"]["MBS_CMT30"].mean()
    turnup.loc[(turnup["AB_Grade_ID"] == "6010120") & (turnup["MBS_CMT30"] < 180), "MBS_CMT30"] = turnup[turnup["AB_Grade_ID"] == "6010120"]["MBS_CMT30"].mean()
    turnup.loc[(turnup["AB_Grade_ID"] == "6010120") & (turnup["MBS_CMT30"].isnull()), "MBS_CMT30"] = turnup[turnup["AB_Grade_ID"] == "6010120"]["MBS_CMT30"].mean()
    turnup.loc[(turnup["AB_Grade_ID"] != "6010120") & (turnup["AB_Grade_ID"] != "6010100"), "MBS_CMT30"] = 0

    # TO ADD
    if not steam_null:
        turnup = turnup[turnup["Steam_flow_to_PreDryers"] > 42]
        turnup = turnup[~((turnup.Wedge_Time > "2025-10-23 11:56") & (turnup.Wedge_Time < "2025-11-16 10:00"))]
    # END TO ADD

    turnup = turnup.copy()

    turnup.rename(columns={
        'Electrical_Consumption_Wire_Section': 'Electrical_Consumtion_Wire_Section',
        'Spezifischer_Energieverbrauch_APA': 'Spezifischer_Energieverbrauch_APA_',
    }, inplace=True)

    cond_col = turnup['Condensate_energy_from_paper_plant_to_power_plant']
    cond_med = cond_col[(cond_col >= 0) & (cond_col <= 10)].median()
    if math.isnan(cond_med):
        cond_med = 5.11
    cond = cond_col.where((cond_col >= 0) & (cond_col <= 10), cond_med)

    impute_outside_limits_with_grade_median(turnup, 'Steam_flow_to_PreDryers', 0, 100, inplace=True)
    impute_outside_limits_with_grade_median(turnup, 'Steam_flow_to_AfterDryers', 15, 30, inplace=True)
    impute_outside_limits_with_grade_median(turnup, 'Steam_flow_to_starch_kitchen', 0, 10, inplace=True)
    impute_outside_limits_with_grade_median(turnup, 'Steam_flow_to_heat_exchangers', 0.2, 1.4, inplace=True)
    impute_outside_limits_with_grade_median(turnup, 'Steam_flow_to_white_water_heating', 0.0, 10.0, inplace=True)

    impute_outside_limits_with_grade_median(turnup, 'Steam_energy_from_power_plant_to_paper_plant', 20, 80.0, inplace=True)
    impute_outside_limits_with_grade_median(turnup, 'Steam_flow_from_power_plant_to_PM', 0, 120, inplace=True)
    impute_outside_limits_with_grade_median(turnup, 'Steam_flow_to_PM', 0, 120, inplace=True)

    turnup["Steam_power"] = turnup['Steam_flow_to_PM'] + turnup['Waste_steam_flow']
    turnup["Steam_power_corrected"] = (((turnup["Steam_power"] * 0.788 - cond) * 1.02 - (0.5938 / 24))) * 1000
    turnup["Steam__kWh/T_"] = turnup["Steam_power_corrected"] / turnup["Production_Rate__T/h_"]

    turnup["Electrical_power_MW"] = (
        turnup['Summe_Energieverbrauch_APA_in_kW'] +
        turnup['Mehrmotorenantrieb_Former__-1..10_MW_'] * 1000 +
        turnup['Mehrmotorenantrieb_Presse__-1..10_MW_'] * 1000 +
        turnup['VariSTEP_div._Hauben+Lueftung_Ventilatoren'] * 1000 +
        turnup['VariSTEP_div._Hauben+Lueftung_Ventilatoren'] * 1000 +
        turnup['Varisprint_660V__-10..10_MW_'] * 1000 +
        turnup['Varisprint_400V__-10..10_MW_'] * 1000 +
        turnup['Mehrmotorenantrieb_Trockenpartie__-1..10_MW_'] * 1000 +
        turnup['PM_400V__-1..10_MW_'] * 1000 +
        turnup['PM_660V_Festantriebe_Verteiler2__-1..10_MW_'] * 1000 +
        turnup['PM_660V_Festantriebe_Verteiler3__-1..10_MW_'] * 1000 +
        turnup['PM_660V_Festantriebe_Verteiler3__-1..10_MW_~^0'] * 1000 +
        turnup['PM_660V_Festantriebe_Verteiler2__-1..10_MW_~^1'] * 1000 +
        turnup['PM_660V_Festantriebe_Verteiler1__-1..10_MW_~^0'] * 1000 +
        turnup['PM_660V_Festantriebe_Verteiler1__-1..10_MW_~^1'] * 1000 +
        turnup['MCC_Einzel-FU_660V__-10..10_MW_~^0'] * 1000 +
        turnup['MCC_Einzel-FU_660V__-10..10_MW_~^1'] * 1000 +
        turnup['Last_Antrieb_10_1.TG__0..100_kW_'] +
        turnup['Last_Antrieb_11_1.TG__0..100_kW_'] +
        turnup['Last_Antrieb_12_2.TG__0..100_kW_'] +
        turnup['Last_Antrieb_13_2.TG__0..100_kW_'] +
        turnup['Last_Antrieb_14_2.TG__0..100_kW_'] +
        turnup['Last_Antrieb_15_3.TG__0..100_kW_'] +
        turnup['Last_Antrieb_16_3.TG__0..100_kW_'] +
        turnup['Last_Antrieb_17_3.TG__0..100_kW_'] +
        turnup['Last_Antrieb_18_4.TG__0..100_kW_'] +
        turnup['Last_Antrieb_19_4.TG__0..100_kW_'] +
        turnup['Last_Antrieb_20_4.TG__0..100_kW_'] +
        turnup['Last_Antrieb_21_4.TG__0..100_kW_'] +
        turnup['Last_Antrieb_22_5.TG__0..100_kW_'] +
        turnup['Last_Antrieb_23_5.TG__0..100_kW_'] +
        turnup['Last_Antrieb_24_5.TG__0..100_kW_'] +
        turnup['Last_Antrieb_25_5.TG__0..100_kW_'] +
        turnup['Last_Antrieb_31_6.TG__0..100_kW_'] +
        turnup['Last_Antrieb_32_6.TG__0..100_kW_'] +
        turnup['Last_Antrieb_33_6.TG__0..100_kW_'] +
        turnup['Last_Antrieb_34_6.TG__0..100_kW_'] +
        turnup['Last_Antrieb_35_6.TG__0..100_kW_'] +
        turnup['Last_Antrieb_36_7.TG__0..200_kW_'] +
        turnup['Last_Antrieb_37_7.TG__0..200_kW_'] +
        turnup['Last_Antrieb_38_7.TG__0..200_kW_'] +
        turnup['Last_Antrieb_39_7.TG__0..200_kW_']
    ) / 1000

    turnup["Starch_uptake__g/m2_"] = turnup["Starch_uptake_by_paper_Bottom_Roll__g/m2_"] + turnup["Starch_uptake_by_paper_Top_Roll__g/m2_"]
    turnup["concentration_starch_working_tank_1"] = 21.5 * turnup["Flow_starch_main_line_to_working_tank_1~^0"] / (turnup["Dilution_water_working_tank_1"] + turnup["Flow_starch_main_line_to_working_tank_1~^0"])
    turnup["concentration_starch_working_tank_2"] = 21.5 * turnup["Flow_starch_main_line_to_working_tank_2~^0"] / (turnup["Dilution_water_working_tank_2"] + turnup["Flow_starch_main_line_to_working_tank_2~^0"])
    turnup["retention"] = 1 - turnup['Consistency_white_water'] / (10 * turnup['Headbox_consistency'])

    electricity_consumptions = ['Electrical_Consumtion_Wire_Section', "Press_and_Steambox", 'PM_Freq_Converters_1_to_3', 'Other_PM_1_to_10', 'Predryers_sensor_10_to_25', 'Afterdryers_sensor_1_to_9', 'Spezifischer_Energieverbrauch_APA_']
    steam_flows = ['Steam_flow_to_PreDryers', 'Steam_flow_to_AfterDryers', 'Steam_flow_to_starch_kitchen', 'Steam_flow_to_heat_exchangers', 'Steam_flow_to_white_water_heating']
    
    impute_outside_limits_with_grade_median(turnup, "Electrical_power_MW", 10, 30, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Steam__kWh/T_", 850, 1200, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Electricity__kWh/T_", 250, 400, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Starch_mass_flow__kg/T_", 35, 80, inplace=True)

    impute_outside_limits_with_grade_median(turnup, "Electrical_Consumtion_Wire_Section", 5, 60, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "PM_Freq_Converters_1_to_3", 5, 60, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Other_PM_1_to_10", 50, 300, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Predryers_sensor_10_to_25", 1, 50, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Afterdryers_sensor_1_to_9", 1, 30, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Spezifischer_Energieverbrauch_APA_", 20, 150, inplace=True)
    impute_outside_limits_with_grade_median(turnup, 'Press_and_Steambox', 14, 30, inplace=True)

    impute_outside_limits_with_grade_median(turnup, "Natriumhydroxide_mass_flow__g/T_", 1000, 2000, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Defoamer_mass_flow__g/T_", 50, 200, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Act_Deaerator_mass_flow__g/T_", 70, 200, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Sizing_Agent__g/T_", 3500, 6000, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Dry_Strength_Agent_mass_flow__kg/T_", 10, 16, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Retention_Aid_mass_flow__g/T_", 100, 400, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Bentonite_1_mass_flow__g/T_", 0, 3000, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Bentonite_2_mass_flow__g/T_", 0, 3000, inplace=True)
    impute_outside_limits_with_grade_median(turnup, "Fixative_2_mass_flow__g/T_", 0, 2000, inplace=True)
    
    turnup['Steam_Predryers__kWh/T_'] = turnup['Steam__kWh/T_'] * turnup['Steam_flow_to_PreDryers'] / turnup[steam_flows].sum(axis=1)
    turnup['Steam_Afterdryers__kWh/T_'] = turnup['Steam__kWh/T_'] * turnup['Steam_flow_to_AfterDryers'] / turnup[steam_flows].sum(axis=1)
    turnup['Steam_Starchkitchen__kWh/T_'] = turnup['Steam__kWh/T_'] * turnup['Steam_flow_to_starch_kitchen'] / turnup[steam_flows].sum(axis=1)
    turnup['Steam_Heatexchangers__kWh/T_'] = turnup['Steam__kWh/T_'] * turnup['Steam_flow_to_heat_exchangers'] / turnup[steam_flows].sum(axis=1)
    turnup['Steam_Whitewater__kWh/T_'] = turnup['Steam__kWh/T_'] * turnup['Steam_flow_to_white_water_heating'] / turnup[steam_flows].sum(axis=1)

    
    turnup['Electricity_Wiresection__kWh/T_'] = turnup['Electricity__kWh/T_'] * turnup['Electrical_Consumtion_Wire_Section'] / turnup[electricity_consumptions].sum(axis=1)
    turnup['Electricity_Press_and_Steambox__kWh/T_'] = turnup['Electricity__kWh/T_'] * turnup['Press_and_Steambox'] / turnup[electricity_consumptions].sum(axis=1)
    turnup['Electricity_Freqconverters__kWh/T_'] = turnup['Electricity__kWh/T_'] * turnup['PM_Freq_Converters_1_to_3'] / turnup[electricity_consumptions].sum(axis=1)
    turnup['Electricity_Other__kWh/T_'] = turnup['Electricity__kWh/T_'] * turnup['Other_PM_1_to_10'] / turnup[electricity_consumptions].sum(axis=1)
    turnup['Electricity_Predryer__kWh/T_'] = turnup['Electricity__kWh/T_'] * turnup['Predryers_sensor_10_to_25'] / turnup[electricity_consumptions].sum(axis=1)
    turnup['Electricity_Afterdryer__kWh/T_'] = turnup['Electricity__kWh/T_'] * turnup['Afterdryers_sensor_1_to_9'] / turnup[electricity_consumptions].sum(axis=1)
    turnup['Electricity_Specific__kWh/T_'] = turnup['Electricity__kWh/T_'] * turnup['Spezifischer_Energieverbrauch_APA_'] / turnup[electricity_consumptions].sum(axis=1)

    turnup['Fibre_price'] = 146.46
    turnup['Steam_price'] = 89.03 / 1000
    turnup['Electricity_price'] = 113.66 / 1000
    turnup['Starch_price'] = 434.22 / 1000
    turnup['Natriumhydroxide_price'] = 0.30 / 1000
    turnup['Defoamer_price'] = 4.22 / 1000
    turnup['Deaerator_price'] = 1.53 / 1000
    turnup['Sizing_Agent_price'] = 0.84 / 1000
    turnup['Dry_Strength_Agent_price'] = 0.30 / 1000
    turnup['Retention_Aid_price'] = 4.08 / 1000
    turnup['Bentonite_price'] = 0.28 / 1000
    turnup['Fixative_2_price'] = 3.58 / 1000

    cost_dict = {}
    cost_dict["Natriumhydroxide_mass_flow__g/T_"] = {"unitary_cost": 'Natriumhydroxide_price', "cost_name": "Natriumhydroxide__€/T_"}
    cost_dict["Defoamer_mass_flow__g/T_"] = {"unitary_cost": 'Defoamer_price', "cost_name": "Defoamer__€/T_"}
    cost_dict["Act_Deaerator_mass_flow__g/T_"] = {"unitary_cost": 'Deaerator_price', "cost_name": "Deaerator__€/T_"}
    cost_dict["Sizing_Agent__g/T_"] = {"unitary_cost": 'Sizing_Agent_price', "cost_name": "Sizing_Agent__€/T_"}
    cost_dict["Dry_Strength_Agent_mass_flow__g/T_"] = {"unitary_cost": 'Dry_Strength_Agent_price', "cost_name": "Dry_Strength_Agent__€/T_"}
    cost_dict["Retention_Aid_mass_flow__g/T_"] = {"unitary_cost": 'Retention_Aid_price', "cost_name": "Retention_Aid__€/T_"}
    cost_dict["Bentonite_1_mass_flow__g/T_"] = {"unitary_cost": 'Bentonite_price', "cost_name": "Bentonite_1__€/T_"}
    cost_dict["Bentonite_2_mass_flow__g/T_"] = {"unitary_cost": 'Bentonite_price', "cost_name": "Bentonite_2__€/T_"}
    cost_dict["Fixative_2_mass_flow__g/T_"] = {"unitary_cost": 'Fixative_2_price', "cost_name": "Fixative_2__€/T_"}
    
    cost_dict["Fibre_usage__T/T_"] = {"unitary_cost": 'Fibre_price', "cost_name": "Fibre_cost__€/T_"}
    
    cost_dict["Steam__kWh/T_"] = {"unitary_cost": 'Steam_price', "cost_name": "Steam__€/T_"}
    for cost, consumption in zip(_steam_names(), _steam_consumption_names()):
        cost_dict[consumption] = {"unitary_cost": 'Steam_price', "cost_name": cost}

    cost_dict["Electricity__kWh/T_"] = {"unitary_cost": 'Electricity_price', "cost_name": "Electricity__€/T_"}
    for cost, consumption in zip(_electricity_names(), _electricity_consumption_names()):
        cost_dict[consumption] = {"unitary_cost": 'Electricity_price', "cost_name": cost}

    cost_dict["Starch_mass_flow__kg/T_"] = {"unitary_cost":'Starch_price', "cost_name": "Starch__€/T_"}


    turnup["Dry_Strength_Agent_mass_flow__g/T_"] = turnup["Dry_Strength_Agent_mass_flow__kg/T_"] * 1000

    turnup["Fibre_usage__T/T_"] = (turnup["Current_basis_weight"] * (1 - turnup["Current_reel_moisture_average(reel)"] / 100) - turnup["Starch_uptake_by_paper_Bottom_Roll__g/m2_"] - turnup["Starch_uptake_by_paper_Top_Roll__g/m2_"]) / turnup["Current_basis_weight"]

    turnup[_chemical_names()] = turnup[_chemical_names()].fillna(value=0)
    turnup[_chemical_consumption_names_raw()] = turnup[_chemical_consumption_names_raw()].fillna(value=0)

    new_cost_df = pd.DataFrame(
        {
            cost_dict[c]["cost_name"]:
                turnup[c] * turnup[cost_dict[c]["unitary_cost"]]
            for c in cost_dict
        },
        index=turnup.index,
    )

    turnup = pd.concat(
        [
            turnup.drop(
                columns=new_cost_df.columns,
                errors="ignore",
            ),
            new_cost_df,
        ],
        axis=1,
    )


    for new_name, old_name in zip(_chemical_consumption_names(), _chemical_consumption_names_raw()):
        turnup[new_name] = turnup[old_name]

    turnup['Chemicals__€/T_'] = turnup[_chemical_names()].sum(axis=1)

    turnup[_agg_cost_label()] = turnup[_costs_to_consider()].sum(axis=1)
    turnup[_agg_cost_label2()] = turnup[_costs_to_consider2()].sum(axis=1)

    turnup["Current_reel_weight"] = turnup["Current_reel_weight"]/1000
    
    coef_df = pd.DataFrame({
        "property": ["MBS_SCT_MD", "MBS_SCT_CD", "MBS_Burst", "MBS_CMT30"],
        "starch_coef": [0.1356332061139627, 0.15738688100760012, 10.8090692825425, 3.701831560389852],
    })

    turnup["Wedge_Date"] = turnup["Wedge_Time"].dt.date

    turnup.drop_duplicates(["MBS_Current_reel_ID"], keep="last", inplace=True)

    overprocessing = pd.melt(turnup[["Wedge_Time", 'AB_Grade_ID', 'MBS_Current_reel_ID', 'Current_basis_weight', 'Starch_uptake__g/m2_', 'MBS_SCT_MD', 'MBS_SCT_CD', 'MBS_Burst', 'MBS_CMT30']], id_vars=['Wedge_Time', 'AB_Grade_ID', 'MBS_Current_reel_ID', 'Current_basis_weight', 'Starch_uptake__g/m2_'], value_vars=['MBS_SCT_MD', 'MBS_SCT_CD', 'MBS_Burst', 'MBS_CMT30'], var_name="property").merge(setpoint_df.pivot(index=["AB_Grade_ID", "property"], columns=["variable"], values="value").reset_index(), on=["AB_Grade_ID", "property"], how="left").dropna()
    overprocessing = pd.merge(overprocessing, coef_df, on=["property"], how="left")
    overprocessing["property_diff"] = overprocessing["value"] - overprocessing["min"]
    overprocessing["property_pct"] = overprocessing["property_diff"] / overprocessing["min"]
    overprocessing["overprocessing_std"] = (overprocessing["value"] - (overprocessing["min"] + overprocessing["target"]) / 2) / ((overprocessing["target"] - overprocessing["min"]) / 2)
    overprocessing["overprocessing_score"] = (overprocessing["overprocessing_std"] - 1).clip(0)
    overprocessing["underprocessing_score"] = (-overprocessing["overprocessing_std"] - 1).clip(0)
    overprocessing["starch_uptake_diff"] = overprocessing["property_diff"] * overprocessing["starch_coef"]
    overprocessing["starch_mass_flow_diff_avg"] = overprocessing["starch_uptake_diff"] * 1000 / overprocessing['Current_basis_weight']  # kg/T
    overprocessing["starch_cost_diff"] = overprocessing["starch_mass_flow_diff_avg"] * 434.22 / 1000
    overprocessing = overprocessing[["MBS_Current_reel_ID", "property", "property_pct", "starch_cost_diff", "overprocessing_std", "overprocessing_score", "underprocessing_score"]]
    overprocessingT = overprocessing.groupby('MBS_Current_reel_ID').agg({"property_pct": "mean", "starch_cost_diff": "mean", "overprocessing_std": "mean", "overprocessing_score": "sum", "underprocessing_score": "sum"}).reset_index()
    overprocessingT["property"] = "ALL"
    overprocessing = pd.concat([overprocessing, overprocessingT], axis=0)
    overprocessing.pivot(index=["MBS_Current_reel_ID"], columns="property", values=["property_pct", "overprocessing_std", "starch_cost_diff"])
    overprocessing = overprocessing.pivot(index=["MBS_Current_reel_ID"], columns="property", values=["property_pct", "overprocessing_std", "starch_cost_diff"])
    overprocessing1 = overprocessing["property_pct"].rename(columns={"ALL": "Overprocessing_percentage", "MBS_SCT_CD": "Overprocessing_SCT_CD", "MBS_Burst": "Overprocessing_Burst", "MBS_CMT30": "Overprocessing_CMT30"})
    overprocessing2 = overprocessing["starch_cost_diff"][["ALL"]].rename(columns={"ALL": "Overprocessing_cost__€/T_"})
    overprocessing3 = overprocessingT[["MBS_Current_reel_ID", "overprocessing_std", "overprocessing_score", "underprocessing_score"]].set_index("MBS_Current_reel_ID")
    overprocessing4 = overprocessing["overprocessing_std"].rename(columns={"ALL": "Overprocessing_std_ALL", "MBS_SCT_CD": "Overprocessing_std_SCT_CD", "MBS_Burst": "Overprocessing_std_Burst", "MBS_CMT30": "Overprocessing_std_CMT30"})
    overprocessing = pd.concat([overprocessing1, overprocessing2, overprocessing3, overprocessing4], axis=1)
    overprocessing = overprocessing.reset_index()[["MBS_Current_reel_ID", "Overprocessing_percentage", "Overprocessing_SCT_CD", "Overprocessing_Burst", "Overprocessing_CMT30", "Overprocessing_cost__€/T_", 'Overprocessing_std_ALL', 'Overprocessing_std_Burst',
        'Overprocessing_std_CMT30', 'Overprocessing_std_SCT_CD', "overprocessing_std", "overprocessing_score", "underprocessing_score"]]
    turnup = pd.merge(turnup, overprocessing, on='MBS_Current_reel_ID', how="left")
    return turnup



def _turnup_data(local, bucket, fs, setpoint_df, steam_null):
    from datetime import datetime
    import numpy as np

    if local:

        from datetime import date
        import pandas as pd

        start = "2025-06-01"

        today = date.today()

        # If today is the first day of the month, exclude current month
        end = pd.Timestamp(today).replace(day=1)

        month_starts = pd.date_range(start=start, end=end, freq="MS")

        turnup = []

        for time_ref in month_starts.strftime("%Y-%m-%d"):
            try:    
                turnup.append(pd.read_parquet(f"./data/costimier_turnup_{time_ref}.parquet",engine="fastparquet"))
            except:
                ...

        turnup=pd.concat(turnup,axis=0).copy()
    else:            
        prefix = "turnup"
        paths = [
            f"s3://{bucket}/{prefix}/costimier_turnup_{d:%Y-%m-%d}.parquet"
            for d in daterange(datetime(2025, 6, 1), datetime.now(), jump="month")
        
        ]
        existing_paths = [p for p in paths if fs.exists(p)]
        
        turnup = pd.concat(
            (                    
                pd.read_parquet(p, filesystem=fs)   
                .assign(**{
                    c: lambda df, c=c: df[c].astype("float32")
                    for c in pd.read_parquet(p, filesystem=fs).select_dtypes(include=["number"]).columns
                })
                for p in existing_paths
            ),
            ignore_index=True,
            sort=False
        )
    turnup = _feature_engineering(turnup, setpoint_df, steam_null)

    return turnup 

def _raw_data(turnup_data):
  turnup = turnup_data
  turnup=turnup.drop(["Sheet_Off","Current_reel_weight","Current_reel_length","Dilution_water_storage_tank","ProRelease_1_LoVac","ProRelease_2_LoVac","ProRelease_3_LoVac","ProRelease_4_LoVac","ProRelease_5_LoVac","ProRelease_6_LoVac","ProRelease_7_LoVac","Ash_measurement_HC-line","Uhle_box_2_flow___l/min_",'Enzyme_flow_Slurry_1','Dilution_water_flow_slurry_1','Flow_slurry_1_to_reactor','Slurry_1_pumping_to_reactor','Enzyme_flow_Slurry_2','Enzyme_flow_Slurry_3','Slurry_3_level','Dilution_water_flow_slurry_3','Flow_slurry_3_to_reactor','Slurry_3_pumping_to_reactor',"DG_4-5_zero_level","Total_SQM_cost__€/hm2_","LF_screen_3_inlet_consistency", "LF_screen_3_power","LF_screen_3_reject_flow", "LF_screen_3_accept_flow"],axis=1)
  turnup=turnup.drop(["Headbox_total_flow"],axis=1)
  return turnup.sort_values("Wedge_Time").dropna(axis=1, how='all')

def shapley_contribution(df1, df2, cost_component, fibre_cost, steam_cost, electricity_cost, starch_cost, steam_features, electricity_features, starch_features, fibre_features):
  steam_feats = steam_features()
  elec_feats = electricity_features()
  starch_feats = starch_features()
  fibre_feats = fibre_features()

  results = []
  for idx in list(set(df1.index) & set(df2.index)):
      row1 = df1.loc[idx]
      row2 = df2.loc[idx]
      if cost_component=='Fibre_cost__€/T_':
          logger.info(cost_component)
          contrib = shapley_for_pair_mc(row1, row2, fibre_cost, fibre_feats,cost_variable=cost_component)
      elif cost_component=='Steam__€/T_':
          logger.info(cost_component)
          contrib = shapley_for_pair_mc(row1, row2, steam_cost, steam_feats,cost_variable=cost_component)
      elif cost_component=='Electricity__€/T_':
          logger.info(cost_component)
          contrib = shapley_for_pair_mc(row1, row2, electricity_cost, elec_feats,cost_variable=cost_component)
      elif cost_component=='Starch__€/T_':
          logger.info(cost_component)
          contrib = shapley_for_pair_mc(row1, row2, starch_cost, starch_feats,cost_variable=cost_component)
      else:
          return None            
      delta_cost = sum(contrib.values())  # should equal cost2 - cost1
      contrib["id"] = idx
      contrib["delta_cost"] = delta_cost
      results.append(contrib)

  shapley_df = pd.DataFrame(results).set_index("id")
  return shapley_df

def shapley_contribution_filtered(process_data,df1, df2, cost_component, fibre_cost, steam_cost, electricity_cost, starch_cost, steam_features, electricity_features, starch_features, fibre_features, conditional=False):
  

  steam_feats = steam_features()
  elec_feats = electricity_features()
  starch_feats = starch_features()
  fibre_feats = fibre_features()

  
  results = []
  for idx in list(set(df1.index) & set(df2.index)):
      row1 = df1.loc[idx]
      row2 = df2.loc[idx]
      if cost_component=='Fibre_cost__€/T_':
          logger.info(cost_component)
          contrib_full = shapley_for_pair_filtered(row1, row2, fibre_cost, fibre_feats, process_data, cost_variable=cost_component, return_details=True, conditional=conditional)
      elif cost_component=='Steam__€/T_':
          logger.info(cost_component)
          contrib_full = shapley_for_pair_filtered(row1, row2, steam_cost, steam_feats, process_data, cost_variable=cost_component, return_details=True, conditional=conditional)
      elif cost_component=='Electricity__€/T_':
          logger.info(cost_component)
          contrib_full = shapley_for_pair_filtered(row1, row2, electricity_cost, elec_feats, process_data, cost_variable=cost_component, return_details=True, conditional=conditional)
      elif cost_component=='Starch__€/T_':
          logger.info(cost_component)
          contrib_full = shapley_for_pair_filtered(row1, row2, starch_cost, starch_feats, process_data, cost_variable=cost_component, return_details=True, conditional=conditional)
      else:
          return None            
      
      contrib = contrib_full["contrib_filtered"]      
      delta_cost = sum(contrib.values())  # should equal cost2 - cost1
      contrib["id"] = idx
      contrib["delta_cost"] = delta_cost
      results.append(contrib)

  shapley_df = pd.DataFrame(results).set_index("id")
  return shapley_df, contrib_full["contrib_all"], contrib_full["diagnostics"]

def _shapley_contrib(data_version, df1, df2, cost_component, grade, fibre_cost, steam_cost, electricity_cost, starch_cost, steam_features, electricity_features, starch_features, fibre_features):
  df1 = df1.groupby("AB_Grade_ID").mean()
  df2 = df2.groupby("AB_Grade_ID").mean()
    
  shapley_df = shapley_contribution(df1, df2, cost_component, fibre_cost, steam_cost, electricity_cost, starch_cost, steam_features, electricity_features, starch_features, fibre_features)
  
  df = df2.subtract(df1, axis=0).reset_index()
  df = df[df.AB_Grade_ID.isin(shapley_df.index.unique())]

  df = pd.melt(shapley_df.drop("delta_cost",axis=1).div(shapley_df["delta_cost"].abs(),axis=0).reset_index(), id_vars="id", value_name="contribution").rename(columns={"id":"AB_Grade_ID"}).merge(pd.melt(df, id_vars="AB_Grade_ID", value_name="value_change"), on=["AB_Grade_ID","variable"], how="left")
  return df


def _shapley_contrib_filtered(data_version, process_data, df1, df2, cost_component, grade, fibre_cost, steam_cost, electricity_cost, starch_cost, steam_features, electricity_features, starch_features, fibre_features, conditional=False):
  
  df1 = df1.groupby("AB_Grade_ID").mean()
  df2 = df2.groupby("AB_Grade_ID").mean()
    
  shapley_df, contrib_filtered, diagnostics = shapley_contribution_filtered(process_data,df1, df2, cost_component, fibre_cost, steam_cost, electricity_cost, starch_cost, steam_features, electricity_features, starch_features, fibre_features, conditional=conditional)
  
  df = df2.subtract(df1, axis=0).reset_index()
  df = df[df.AB_Grade_ID.isin(shapley_df.index.unique())]

  df = pd.melt(shapley_df.drop("delta_cost",axis=1).div(shapley_df["delta_cost"].abs(),axis=0).reset_index(), id_vars="id", value_name="contribution").rename(columns={"id":"AB_Grade_ID"}).merge(pd.melt(df, id_vars="AB_Grade_ID", value_name="value_change"), on=["AB_Grade_ID","variable"], how="left")
  return df, contrib_filtered, diagnostics

def _process_data_clustered(data_version, process_data, cost_component, grade, cost_component_features):
  turnup_process = process_data
  turnup_main = []

  for grade in [grade]:#["3200115", "6010085", "6010100", "6010120"]:
      for target in ["historic","current"]:
          tu = turnup_process[(turnup_process.AB_Grade_ID==grade) & (turnup_process.target==target)][cost_component_features + [cost_component, "AB_Grade_ID","target"]].copy()
          if len(tu) > 0:
          
              clusters = clustering(tu.drop(["AB_Grade_ID","target"], axis=1),cost_component, stability = True)
              tu["cluster"] = clusters
          else:
              tu["cluster"] = -1
          turnup_main.append(tu)
  turnup_main=pd.concat(turnup_main, axis=0)
  return turnup_main

def _process_data_clustered_summary(process_data_clustered, cost_component, grade, fibre_cost, steam_cost, electricity_cost, starch_cost, steam_features, electricity_features, starch_features, fibre_features):
    turnup_main = process_data_clustered
    turnup_main = turnup_main[turnup_main["AB_Grade_ID"]==grade]
    
    #turnup_main["ratio_starch"]=turnup_main["Starch_uptake__g/m2_"]/turnup_main["Current_basis_weight"]
    turnup_results= turnup_main.groupby(["AB_Grade_ID","target","cluster"]).agg({cost_component:"mean"}).reset_index()
    ycol = cost_component
    
    turnup_summary =  turnup_main.groupby(["AB_Grade_ID","target"]).agg({cost_component:"mean"}).reset_index().pivot(index="AB_Grade_ID", columns="target", values=cost_component)
    turnup_summary["delta"]=turnup_summary["current"]-turnup_summary["historic"]
    
    turnup_results= turnup_main.groupby(["AB_Grade_ID","target","cluster"]).agg({cost_component:"mean"}).reset_index()
    best_historic=(turnup_results[turnup_results.target=="historic"].sort_values(["AB_Grade_ID",cost_component],ascending=[True, True]).groupby("AB_Grade_ID").head(1)[["AB_Grade_ID","target","cluster"]])
    worse_historic=(turnup_results[turnup_results.target=="historic"].sort_values(["AB_Grade_ID",cost_component],ascending=[True, False]).groupby("AB_Grade_ID").head(1)[["AB_Grade_ID","target","cluster"]])
    best_current=(turnup_results[turnup_results.target=="current"].sort_values(["AB_Grade_ID",cost_component],ascending=[True, True]).groupby("AB_Grade_ID").head(1)[["AB_Grade_ID","target","cluster"]])
    worse_current=(turnup_results[turnup_results.target=="current"].sort_values(["AB_Grade_ID",cost_component],ascending=[True, False]).groupby("AB_Grade_ID").head(1)[["AB_Grade_ID","target","cluster"]])

    baseline = []
    current = []
    for g in turnup_summary.index:
        tm = turnup_main[turnup_main.AB_Grade_ID==g]
        if(turnup_summary.loc[g]["delta"]) > 0:
            baseline.append(tm.merge(best_historic[best_historic.AB_Grade_ID==g], on=["AB_Grade_ID","target","cluster"], how="inner"))
            current.append(tm.merge(worse_current[worse_current.AB_Grade_ID==g], on=["AB_Grade_ID","target","cluster"], how="inner"))
        else:
            baseline.append(turnup_main.merge(worse_historic[worse_historic.AB_Grade_ID==g], on=["AB_Grade_ID","target","cluster"], how="inner"))
            current.append(turnup_main.merge(best_current[best_current.AB_Grade_ID==g], on=["AB_Grade_ID","target","cluster"], how="inner"))
    baseline = pd.concat(baseline, axis=0)
    current = pd.concat(current, axis=0)

    fibre_feats  = fibre_features()
    steam_feats  = steam_features()
    elec_feats   = electricity_features()
    starch_feats = starch_features()

    if ycol == 'Fibre_cost__€/T_':
        df1 = baseline[fibre_feats + ["AB_Grade_ID", ycol]].copy()
        df2 = current[fibre_feats + ["AB_Grade_ID", ycol]].copy()
    
        # fibre_cost expects mapping-like with names -> use the row Series directly
        df1["unknown"] = df1[ycol] - df1[fibre_feats].apply(fibre_cost, axis=1)
        df2["unknown"] = df2[ycol] - df2[fibre_feats].apply(fibre_cost, axis=1)
    
    elif ycol == 'Steam__€/T_':
        df1 = baseline[steam_feats + ["AB_Grade_ID", ycol]].copy()
        df2 = current[steam_feats + ["AB_Grade_ID", ycol]].copy()
    
        # steam_cost now expects dict-like keyed by feature name
        df1["unknown"] = df1[ycol] - df1[steam_feats].apply(steam_cost, axis=1)
        df2["unknown"] = df2[ycol] - df2[steam_feats].apply(steam_cost, axis=1)
    
    elif ycol == 'Electricity__€/T_':
        df1 = baseline[elec_feats + ["AB_Grade_ID", ycol]].copy()
        df2 = current[elec_feats + ["AB_Grade_ID", ycol]].copy()
    
        df1["unknown"] = df1[ycol] - df1[elec_feats].apply(electricity_cost, axis=1)
        df2["unknown"] = df2[ycol] - df2[elec_feats].apply(electricity_cost, axis=1)
    
    elif ycol == 'Starch__€/T_':
        df1 = baseline[starch_feats + ["AB_Grade_ID", ycol]].copy()
        df2 = current[starch_feats + ["AB_Grade_ID", ycol]].copy()
    
        df1["unknown"] = df1[ycol] - df1[starch_feats].apply(starch_cost, axis=1)
        df2["unknown"] = df2[ycol] - df2[starch_feats].apply(starch_cost, axis=1)
    
    else:
        df1 = None
        df2 = None
    
    return df1, df2



def drilldown_df(dfp, level, object_drilldown, reference_drilldown, secondary_object_drilldown="chemicals"):
    import numpy as np

    if reference_drilldown=="week":
        x_variable_summary="week"
    else:
        x_variable_summary="target"

    if object_drilldown=="cost":
        y_variable_summary = "Combined_cost__€/T_"
    elif object_drilldown=="overprocessing":
        y_variable_summary = "Overprocessing_percentage"    

    if level==1:
        color_variable_summary ="none"                
        df, dfg, c, x_var, color_var = get_process_grouped(dfp, y_variable_summary,x_variable_summary,color_variable_summary,_agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars())
        if object_drilldown=="cost":            
            dfg["cost"]="TOTAL"
        elif object_drilldown=="overprocessing":
            dfg["cost"]="AVERAGE"

        if reference_drilldown=="week":
            t = dfg.Wedge_Week.max() - 1                                
            C=dfg[(dfg.Wedge_Week==(t+1))].rename(columns={y_variable_summary:"current_cost"}).merge(dfg[(dfg.Wedge_Week==(t))].rename(columns={y_variable_summary:"previous_cost"})[["cost","previous_cost" ]], on= ["cost"], how="left" )
            
        else:
            C=dfg[(dfg.target=="current")].rename(columns={y_variable_summary:"current_cost"}).merge(dfg[(dfg.target=="historic")].rename(columns={y_variable_summary:"previous_cost"})[["cost","previous_cost" ]], on= ["cost"], how="left" )
        C["AB_Grade_ID"]="ALL" 
      
    elif level==0:
        color_variable_summary ="cost"                             
        df, dfg, c, x_var, color_var = get_process_grouped(dfp, y_variable_summary,x_variable_summary,color_variable_summary,_agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars())
        if reference_drilldown=="week":
            t = dfg.Wedge_Week.max() - 1
            C=dfg[(dfg.Wedge_Week==(t+1))].rename(columns={y_variable_summary:"current_cost"}).merge(dfg[(dfg.Wedge_Week==(t))].rename(columns={y_variable_summary:"previous_cost"})[["cost","previous_cost" ]], on= ["cost"], how="left" )
        else:
            C=dfg[(dfg.target=="current")].rename(columns={y_variable_summary:"current_cost"}).merge(dfg[(dfg.target=="historic")].rename(columns={y_variable_summary:"previous_cost"})[["cost","previous_cost" ]], on= ["cost"], how="left" )

        C["AB_Grade_ID"]="ALL" 
    elif level==2:
        color_variable_summary ="grade"                             
        df, dfg, c, x_var, color_var = get_process_grouped(dfp, y_variable_summary,x_variable_summary,color_variable_summary,_agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars())
        if object_drilldown=="cost":            
            dfg["cost"]="TOTAL"
        elif object_drilldown=="overprocessing":
            dfg["cost"]="AVERAGE"
        if reference_drilldown=="week":
            t = dfg.Wedge_Week.max() - 1                
            C=dfg[(dfg.Wedge_Week==(t+1))].rename(columns={y_variable_summary:"current_cost"}).merge(dfg[(dfg.Wedge_Week==(t))].rename(columns={y_variable_summary:"previous_cost"})[["AB_Grade_ID","cost","previous_cost" ]], on= ["AB_Grade_ID","cost"], how="left" )
        else:
            C=dfg[(dfg.target=="current")].rename(columns={y_variable_summary:"current_cost"}).merge(dfg[(dfg.target=="historic")].rename(columns={y_variable_summary:"previous_cost"})[["AB_Grade_ID","cost","previous_cost" ]], on= ["AB_Grade_ID","cost"], how="left" )
    elif level==3:
        color_variable_summary ="grade"                       
        df, dfg1, c, x_var, color_var = get_process_grouped(dfp, y_variable_summary,x_variable_summary,color_variable_summary,_agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars())
        
        if object_drilldown=="cost":
            color_variable_summary ="cost_grade"
            dfg1["cost"]="TOTAL"
        elif object_drilldown=="overprocessing":
            color_variable_summary ="overprocessing_grade"        
            dfg1["cost"]="AVERAGE"

        df, dfg2, c, x_var, color_var = get_process_grouped(dfp, y_variable_summary,x_variable_summary,color_variable_summary,_agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars())
        dfg = pd.concat([dfg1,dfg2],axis=0).dropna()
        
        if reference_drilldown=="week":
            t = dfg.Wedge_Week.max() - 1
            C=dfg[(dfg.Wedge_Week==(t+1))].rename(columns={y_variable_summary:"current_cost"}).merge(dfg[(dfg.Wedge_Week==(t))].rename(columns={y_variable_summary:"previous_cost"})[["AB_Grade_ID","cost","previous_cost" ]], on= ["AB_Grade_ID","cost"], how="left" )
        else:
            C=dfg[(dfg.target=="current")].rename(columns={y_variable_summary:"current_cost"}).merge(dfg[(dfg.target=="historic")].rename(columns={y_variable_summary:"previous_cost"})[["AB_Grade_ID","cost","previous_cost" ]], on= ["AB_Grade_ID","cost"], how="left" )
    elif level==4:
        if object_drilldown=="cost":
            color_variable_summary ="grade"                       
        
            if secondary_object_drilldown == "chemicals":
                y_variable_summary = 'Chemicals__€/T_'
                agg_cost_label = 'Chemicals__€/T_'
                costs_to_consider = _chemical_names()
                overprocessing_vars = _overprocessing_vars()
            elif secondary_object_drilldown == "steam":
                y_variable_summary = 'Steam__€/T_'
                agg_cost_label = 'Steam__€/T_'
                costs_to_consider = _steam_names()
                overprocessing_vars = _overprocessing_vars()
            elif secondary_object_drilldown == "electricity":
                y_variable_summary = 'Electricity__€/T_'
                agg_cost_label = 'Electricity__€/T_'
                costs_to_consider = _electricity_names()
                overprocessing_vars = _overprocessing_vars()

            df, dfg1, c, x_var, color_var = get_process_grouped(dfp, y_variable_summary,x_variable_summary,color_variable_summary,agg_cost_label, costs_to_consider, _overprocessing_vars())
            
            color_variable_summary ="cost_grade"
            dfg1["cost"]=secondary_object_drilldown

            df, dfg2, c, x_var, color_var = get_process_grouped(dfp, y_variable_summary,x_variable_summary,color_variable_summary,agg_cost_label, costs_to_consider, _overprocessing_vars())
            dfg = pd.concat([dfg1,dfg2],axis=0).dropna()

            if reference_drilldown=="week":
                t = dfg.Wedge_Week.max() - 1
                C=dfg[(dfg.Wedge_Week==(t+1))].rename(columns={y_variable_summary:"current_cost"}).merge(dfg[(dfg.Wedge_Week==(t))].rename(columns={y_variable_summary:"previous_cost"})[["AB_Grade_ID","cost","previous_cost" ]], on= ["AB_Grade_ID","cost"], how="left" )
            else:
                C=dfg[(dfg.target=="current")].rename(columns={y_variable_summary:"current_cost"}).merge(dfg[(dfg.target=="historic")].rename(columns={y_variable_summary:"previous_cost"})[["AB_Grade_ID","cost","previous_cost" ]], on= ["AB_Grade_ID","cost"], how="left" )

    C["pct_cost"]=(C["current_cost"]-C["previous_cost"])
    C["pct_cost"]=C["pct_cost"].replace(np.inf,1)
    return C

def _process_data(turnup_data, target_range, baseline_range, steam_null):
  df = _raw_data(turnup_data).copy()
  df["target"]="none"
  df.loc[(df.Wedge_Time.dt.date >= target_range[0]) & (df.Wedge_Time.dt.date <= target_range[1]),"target"]="current"
  df.loc[(df.Wedge_Time.dt.date >= baseline_range[0]) & (df.Wedge_Time.dt.date <= baseline_range[1]),"target"]="historic"
  
  if steam_null:
      df_temp=df.groupby("AB_Grade_ID").agg({"Steam__€/T_":"mean"}).reset_index()
      df["Aggregated_cost__€/T_"]=df["Aggregated_cost__€/T_"]-df["Steam__€/T_"]
      df["Combined_cost__€/T_"]=df["Combined_cost__€/T_"]-df["Steam__€/T_"]
      df.drop("Steam__€/T_",axis=1,inplace=True)
      df=df.merge(df_temp,on="AB_Grade_ID", how="left")
      df["Aggregated_cost__€/T_"]=df["Aggregated_cost__€/T_"]+df["Steam__€/T_"]
      df["Combined_cost__€/T_"]=df["Combined_cost__€/T_"]+df["Steam__€/T_"]
  # END TO REMOVE
  df=df[df.target!="none"]        
  return df

def _clusters(df_scores, num_samples):
  gmm, clusters, nclusters, sizes = gmm_with_min_size(
      df_scores, 
      min_size=num_samples,       # <-- set your minimum samples per cluster here
      k_min=2, 
      k_max=None,        # or an explicit upper bound
      random_state=1
  )
  
  return clusters

def _grade_data_general(process_data, igrade_general):    
  return process_data[process_data["AB_Grade_ID"].isin(igrade_general)]

def _best_cluster(grade_data_process_clustered, acceptable_clusters):
  df = grade_data_process_clustered.copy()        
  best_df=df[(df.cluster.isin(acceptable_clusters))]
  if len(best_df)>0:
      bc=best_df.groupby("cluster").agg({_agg_cost_label():"median"}).sort_values(_agg_cost_label(),ascending=True).reset_index().iloc[0].cluster
      best_df  = best_df[best_df.cluster==bc].copy()
      best_df["target"]="best"
      best_df=best_df.reset_index(drop=True)            
  else:
      bc=-1
      best_df = None
  return bc,best_df

def _data_benchmark(i_variable_benchmark, grade_data_process_clustered, best_cluster, best_cluster_dataframe):
  from scipy.stats import ks_2samp
  import numpy as np

  if i_variable_benchmark==_agg_cost_label():
      df=grade_data_process_clustered[["cluster","target",i_variable_benchmark]].copy()
  else:
      df=grade_data_process_clustered[["cluster","target",i_variable_benchmark,_agg_cost_label()]].copy()
  
  historic_df=df[df.target=="historic"][[i_variable_benchmark]].copy().reset_index(drop=True)
  historic_df["target"]="historic"
  current_df=df[df.target=="current"][[i_variable_benchmark]].copy().reset_index(drop=True)
  current_df["target"]="current"
  
  potential_savings=0
  true_savings=0

  if best_cluster!=-1:
      best_df=best_cluster_dataframe[[i_variable_benchmark,"target"]]
      res=pd.concat([historic_df,best_df,current_df],axis=0)
      
      best_values  = best_df[i_variable_benchmark]
      current_values  = current_df[i_variable_benchmark]
      statistic, p_value_bc = ks_2samp(best_values, current_values)
      if p_value_bc<0.05:
          potential_savings=np.mean(best_values)-np.mean(current_values)                    
  else:
      res=pd.concat([historic_df,current_df],axis=0)            
      p_value_bc = np.inf
  
  historic_values  = historic_df[i_variable_benchmark]
  current_values  = current_df[i_variable_benchmark]
  statistic, p_value_hc = ks_2samp(historic_values, current_values)
  if p_value_hc<0.05:
      true_savings = np.mean(historic_values)-np.mean(current_values)
  
  return res,true_savings,potential_savings, p_value_hc,p_value_bc

def mix_effect(object_drilldown,reference_drilldown,grades_drilldown, process_data):
    if object_drilldown=="overprocessing":           
        y_variable_summary = "Overprocessing_percentage"
    elif object_drilldown=="cost":
        y_variable_summary = "Combined_cost__€/T_"    
    else:
        return None        

    color_variable_summary ="grade"        
    if reference_drilldown=="week":
        x_variable_summary="week"
    else:
        x_variable_summary="target"

    dfp = process_data
    dfp = dfp[dfp.AB_Grade_ID.isin(grades_drilldown)]

    df, dfg, c, x_var, color_var = get_process_grouped(dfp, y_variable_summary,x_variable_summary,color_variable_summary, _agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars())       
    
    A=dfg.rename(columns={"n": "n_samples"}).reset_index()

    if reference_drilldown=="week":
        t = dfg.Wedge_Week.max() - 1
        mix_comp= decompose_avg_cost_change(A[A.Wedge_Week==(t)], A[A.Wedge_Week==(t+1)],y_variable_summary)
    else:
        mix_comp= decompose_avg_cost_change(A[A.target=="historic"], A[A.target=="current"],y_variable_summary)

    return mix_comp["mix_effect"], mix_comp["cost_effect"]

def plot_KDE(df, variable, color, name):
  from scipy.stats import gaussian_kde
  import numpy as np
  import plotly.graph_objects as go

  data = df[variable].dropna().values
  kde = gaussian_kde(data, bw_method=0.2)
  xmin, xmax = data.min(), data.max()
  x = np.linspace(xmin, xmax, 500)
  y = kde(x)

  p025 = np.percentile(data, 2.5)
  p975 = np.percentile(data, 97.5)
  p500 = np.percentile(data, 50)

  traces = []
  shapes = []
  
  traces.append(
      go.Scatter(
          x=x,
          y=y,
          mode="lines",
          line=dict(color=color, width=3),
          fill="tozeroy",
          fillcolor=to_rgba(color, 0.25),
          name=name
      )
  )
  # shapes.append(
  #     dict(
  #         type="line",
  #         x0=p025,
  #         x1=p025,
  #         y0=0,
  #         y1=max(y),
  #         line=dict(
  #             color=color,
  #             width=2,
  #             dash="dash"
  #         ),
  #         name="2.5th percentile"
  #     )
  # )

  shapes.append(
      dict(
          type="line",
          x0=p500,
          x1=p500,
          y0=0,
          y1=max(y),
          line=dict(
              color=color,
              width=3,
              dash="dash"
          ),
          name="median"
      )
  )
  
  # Vertical dashed line at 97.5 percentile
  # shapes.append(
  #     dict(
  #         type="line",
  #         x0=p975,
  #         x1=p975,
  #         y0=0,
  #         y1=max(y),
  #         line=dict(
  #             color=color,
  #             width=2,
  #             dash="dash"
  #         ),
  #         name="97.5th percentile"
  #     )
  # )
  return traces, shapes, x, y

def _grade_data_process_clustered(process_data, igrade, clusters):
  df = process_data
  df = df[df["AB_Grade_ID"] == igrade]
  df["cluster"]=clusters
  return df

def _scores_clustered(df_scores, df_features, clusters):
  df=df_scores.copy()
  df["cluster"]= clusters
  return pd.concat([df.reset_index(drop=True),df_features.reset_index(drop=True)],axis=1)

def _model_performance_table(model_metric, model_performance):
  res = model_performance
  res["grade"]="TOTAL"
  tt = res.sort_values(["property"],ascending=[False])[["grade","property",model_metric,"target"]].pivot(index=["grade","target"],columns="property", values=model_metric).reset_index()
  for q in _quality_features():
      if "overprocessing" not in q.lower():
          tt[q]=tt[q].astype("double")
          tt[q]=round(tt[q],1)
  return tt

def _strength_variability_table(model_grade, lab_performance):
  metric_var = lab_performance  
  metric_var = metric_var.sort_values(["property","grade"],ascending=[False,True])
  tt = metric_var[metric_var.grade==model_grade][["grade","property","sd","target"]].pivot(index=["grade","target"],columns="property",values="sd").reset_index()
  for q in _quality_features():
      if "overprocessing" not in q.lower():
          tt[q]=tt[q].astype("double")
          tt[q]=round(tt[q],1)
  return tt

def _lab_performance_plot(turnup_data, strength_property, start_baseline, end_baseline, reference_time, model_grade):
  import plotly.graph_objects as go
  import pandas as pd

  turnup = turnup_data.copy()        
  strength_property = strength_property
  turnup = turnup[(turnup.Wedge_Time.dt.date >= start_baseline) & (turnup.Wedge_Time.dt.date <= end_baseline)  & (turnup.AB_Grade_ID == model_grade)]
  
  fig = go.Figure()
  tt,ss,x,y = plot_KDE(turnup, strength_property, "red", "baseline")
  
  fig.add_traces(tt)
  for s in ss:
      fig.add_shape(s)

  t0 = pd.to_datetime(reference_time)
  start = t0 - pd.Timedelta("30D")
  turnup = turnup_data.copy()                
  turnup = turnup[(turnup.Wedge_Time >= start) & (turnup.Wedge_Time <= t0)  & (turnup.AB_Grade_ID == model_grade)]
  tt,ss,x,y = plot_KDE(turnup, strength_property,"green", "current")
  fig.add_traces(tt)
  for s in ss:
      fig.add_shape(s)

  min_df=setpoint_df.query(f"AB_Grade_ID == '{model_grade}' & property == '{strength_property}' & variable == 'min'")
  if len(min_df) > 0:
      fig.add_shape(
          type="line",
          x0=min_df.value.values[0],
          x1=min_df.value.values[0],
          y0=0,
          y1=max(y),
          line=dict(
              color="red",
              width=4,
              dash="dash"
          ),
          name="Minimum"
      )

  fig.update_layout(template="plotly_white")

  return fig

def _rolling_lab_performance_plot(rolling_stats, strength_property, start_baseline, end_baseline, model_grade, setpoint_df):   
  import plotly.graph_objects as go

  df_plot, strength_property = rolling_stats, strength_property
  
  df_plot = df_plot.loc[model_grade].reset_index()
  
  fig = go.Figure()

  if strength_property=="MBS_CMT30" and (model_grade!="6010120" or model_grade != "6010100"):
      fig.update_layout(                
          template="plotly_white",                                
      )
          
      return fig

  # Upper bound (95th percentile)
  fig.add_trace(
      go.Scatter(
          x=df_plot["Wedge_Time"],
          y=df_plot["p_high"],
          mode="lines",
          line=dict(width=0),
          name="95th percentile",
          showlegend=False,   # we’ll label the band once
      )
  )
  
  # Lower bound (5th percentile), filled up to previous trace
  fig.add_trace(
      go.Scatter(
          x=df_plot["Wedge_Time"],
          y=df_plot["p_low"],
          mode="lines",
          line=dict(width=0),
          fill="tonexty",             # fills to previous trace (95th)
          fillcolor="rgba(0, 100, 200, 0.2)",
          name="5–95% band",
          hoverinfo="skip",           # optional: cleaner hover
          opacity=0.02,
          showlegend=False
      )
  )
  
  # Median line
  fig.add_trace(
      go.Scatter(
          x=df_plot["Wedge_Time"],
          y=df_plot["median"],
          mode="lines",
          name="Median",
          showlegend=False
      )
  )

  shapes = []
  min_df=setpoint_df.query(f"AB_Grade_ID == '{model_grade}' & property == '{strength_property}' & variable == 'min'")
  
  if len(min_df) > 0:                        
      shapes.append(
          dict(
              type="line",
              xref="x",
              yref="y",
              x0=df_plot["Wedge_Time"].min(),
              x1=df_plot["Wedge_Time"].max(),
              y0=min_df.value.values[0],
              y1=min_df.value.values[0],
              line=dict(
                  color="red",
                  width=3,
                  dash="dash",
              ),
              layer="above",
          )
      )
  shapes.append(
      dict(
          type="rect",
          xref="x",
          yref="paper",
          x0=start_baseline,
          x1=end_baseline,
          y0=0,
          y1=1,
          fillcolor="rgba(255, 0, 0, 0.15)",  # low alpha
          line=dict(width=0),
          layer="below",
      )
  )        
  
  fig.update_layout(
      title=f"{strength_property} – Median with 5–95% Band (Grade {model_grade})",
      xaxis_title="Time",
      yaxis_title=strength_property,
      template="plotly_white",
      hovermode="x",
      xaxis=dict(
          showspikes=True,
          spikemode="across",
          spikecolor="red",
          spikethickness=2,
          spikedash="solid",   # you can remove this if not needed
      ),
      shapes=shapes
      
  )

  return fig

def _model_performance_plot(model_metrics, model_targets, prediction_models, strength_property, target_model):      
  from sklearn.metrics import mean_absolute_error, root_mean_squared_error, r2_score, mean_absolute_percentage_error
  import plotly.graph_objects as go
  import numpy as np

  res,turnup_targets = model_metrics, model_targets
  LR_models = prediction_models

  ycol = strength_property
  target = target_model

  y_pred = LR_models[ycol].predict(
      turnup_targets[ycol][target].drop([ycol, 'MBS_Current_reel_ID'], axis=1)
  )
  y_test = turnup_targets[ycol][target][ycol]

  rmse = root_mean_squared_error(y_test, y_pred)
  mae = mean_absolute_error(y_test, y_pred)
  r2 = r2_score(y_test, y_pred)

  # print(f"{ycol} — RMSE: {rmse:.3f}, MAE: {mae:.3f}, R2: {r2:.3f}")

  # Axis limits
  lims = [
      np.nanmin([y_test.min(), y_pred.min()]),
      np.nanmax([y_test.max(), y_pred.max()])
  ]

  target_name = ycol

  fig = go.Figure()

  # Scatter: observed vs predicted
  fig.add_trace(
      go.Scatter(
          x=y_test,
          y=y_pred,
          mode="markers",
          opacity=0.5,
          name="Observed vs Predicted"
      )
  )

  # 45-degree reference line: y = x
  fig.add_trace(
      go.Scatter(
          x=lims,
          y=lims,
          mode="lines",
          line=dict(dash="dash", width=1),
          name="y = x"
      )
  )
  base_width=800
  aspect_ratio=8/16
  fig.update_layout(
      template="simple_white",
      plot_bgcolor="white",
      paper_bgcolor="white",
      autosize=True,
      #width=None,
      #height=base_width*aspect_ratio,
      title=dict(
          text=(
              "Observed vs. Predicted<br>"
              f"<sup>{ycol} — RMSE: {rmse:.3f}, MAE: {mae:.3f}, R2: {r2:.3f}</sup>"
          ),
          x=0.5
      ),
      xaxis_title=f"Observed {target_name}",
      yaxis_title=f"Predicted {target_name}",
      legend=dict(x=0.01, y=0.99)
  )

  # Match axes to same range & aspect
  #fig.update_xaxes(range=lims)
  #fig.update_yaxes(range=lims, scaleanchor="x", scaleratio=1)
  return fig

def _working_plot(shapley_contrib, df1, df2, cost_component_drilldown):
    import plotly.graph_objects as go
    import plotly.express as px
    import pandas as pd
    from collections import defaultdict
    import numpy as np
    import textwrap

    df = shapley_contrib.copy()
    contrib_vars = list(df.groupby("variable").agg(contribution_abs=("contribution", lambda s: s.abs().max())).sort_values("contribution_abs", ascending=False).head(10).index.values)

    df1 = df1[df1.AB_Grade_ID.isin(list(set(df1.AB_Grade_ID) & set(df2.AB_Grade_ID)))]
    df2 = df2[df2.AB_Grade_ID.isin(list(set(df1.AB_Grade_ID) & set(df2.AB_Grade_ID)))]

    df1 = df1[contrib_vars + ["AB_Grade_ID", cost_component_drilldown]]
    df2 = df2[contrib_vars + ["AB_Grade_ID", cost_component_drilldown]]

    dfb = pd.melt(
        df1,
        id_vars=["AB_Grade_ID"],
    )
    dfb["target"] = "baseline"

    dfc = pd.melt(
        df2,
        id_vars=["AB_Grade_ID"],
    )
    dfc["target"] = "current"

    df = pd.concat([dfb, dfc], axis=0)

    # --- Aggregate to mean + std + count + median (median unused now) ---
    agg = (
        df.groupby(["AB_Grade_ID", "variable", "target"])["value"]
        .agg(mean="mean", std="std", count="count", median="median")
        .reset_index()
    )

    # standard error
    agg["stderr"] = agg["std"] / np.sqrt(agg["count"])

    vars_all = list(agg["variable"].unique())
    vars_cost = sorted([v for v in vars_all if "€" in v.lower()])
    vars_other = sorted([v for v in vars_all if "€" not in v.lower()])
    if vars_cost:
        variable_order = vars_cost + vars_other
    else:
        variable_order = vars_all

    n_grades = agg["AB_Grade_ID"].nunique()
    row_height = 120  # adjust if needed

    # --- Bar plot with error bars ---
    fig = px.bar(
        agg,
        x="target",
        y="mean",
        facet_row="AB_Grade_ID",
        facet_col="variable",
        facet_col_wrap=1,
        color="target",
        error_y="stderr",
        facet_row_spacing=0.02,
        height=row_height * n_grades,
        custom_data=["median"],   # median is passed but not used anymore
        category_orders={"variable": variable_order},
    )

    # Clean facet labels: "AB_Grade_ID=123" -> "123"
    # fig.for_each_annotation(
    #     lambda a: a.update(
    #         text=a.text.split("=")[-1].split("__")[0],
    #         font=dict(size=11),
    #     )
    # )

    # Short variable labels
    var_map = {
        v: v[:12] + "..."
        if len(v) > 15 else v
        for v in variable_order
    }

    for a in fig.layout.annotations:

        if a.text.startswith("variable="):
            full_var = a.text.split("=", 1)[1]
            a.update(
                text=var_map.get(full_var, full_var),
                font=dict(size=11),
            )

        elif a.text.startswith("AB_Grade_ID="):
            a.update(
                text=a.text.split("=", 1)[1],
                font=dict(size=11),
            )

    

    # Independent y-axes + visible labels everywhere
    fig.update_yaxes(matches=None, showticklabels=True)

    # --- Per-axis range based on mean ± stderr (without forcing zero) ---
    axis_extents = defaultdict(lambda: {"low": np.inf, "high": -np.inf})

    for trace in fig.data:
        axis_name = trace.yaxis if hasattr(trace, "yaxis") else "y"
        y = np.array(trace.y, dtype=float)

        # error bars
        err_obj = getattr(trace, "error_y", None)
        if err_obj is not None:
            if getattr(err_obj, "array", None) is not None:
                e = np.array(err_obj.array, dtype=float)
            elif getattr(err_obj, "value", None) is not None:
                e = np.full_like(y, float(err_obj.value))
            else:
                e = np.zeros_like(y)
        else:
            e = np.zeros_like(y)

        low = np.min(y - e)
        high = np.max(y + e)

        axis_extents[axis_name]["low"] = min(axis_extents[axis_name]["low"], low)
        axis_extents[axis_name]["high"] = max(axis_extents[axis_name]["high"], high)

    # Apply per-axis ranges
    for axis_name, ext in axis_extents.items():
        lo, hi = ext["low"], ext["high"]

        # padding
        if lo == hi:
            pad = abs(lo) * 0.1 if lo != 0 else 1.0
            lo -= pad
            hi += pad
        else:
            pad = (hi - lo) * 0.1
            lo -= pad
            hi += pad

        layout_axis = "yaxis" if axis_name == "y" else "yaxis" + axis_name[1:]
        fig.layout[layout_axis].update(range=[lo, hi])

    # --- Add mean labels (top of bars, shifted right) ---
    for trace in fig.data:
        if trace.type != "bar":
            continue

        for x, y, cd in zip(trace.x, trace.y, trace.customdata):
            mean_val = y

            fig.add_annotation(
                x=x,
                y=y,
                xref=trace.xaxis,
                yref=trace.yaxis,
                text=f"{mean_val:.2f}",   # ⬅ show mean
                showarrow=False,
                xanchor="left",
                yanchor="bottom",
                xshift=6,                # slight right shift
                yshift=2,                # small lift above bar
                font=dict(size=10),
            )

    # Layout
    base_width=800
    aspect_ratio=16/16
    fig.update_layout(
        template="simple_white",
        plot_bgcolor="white",
        paper_bgcolor="white",
        autosize=True,
        width=None,
        height=base_width*aspect_ratio,
        yaxis_title="mean(value)",
        margin=dict(l=80, r=20, t=40, b=40),
        showlegend=False,
    )     

    # Build mapping text in columns
    items = [f"{code}: {var}" for var, code in var_map.items()]

    n_cols = 3
    rows = []

    for i in range(0, len(items), n_cols):
        rows.append(" &nbsp;&nbsp;&nbsp; ".join(items[i:i+n_cols]))

    mapping_text = "<br>".join(rows)

    fig.add_annotation(
        text=mapping_text,
        xref="paper",
        yref="paper",
        x=0,
        y=-0.18,
        showarrow=False,
        align="left",
        xanchor="left",
        yanchor="top",
        font=dict(size=10),
    )

    fig.update_layout(
        margin=dict(
            l=80,
            r=20,
            t=60,
            b=120 + 20 * len(rows) # adapt to legend size
        )
    )


    return fig




def _cost_driver_plot(shapley_contrib):
  import plotly.graph_objects as go
  import plotly.express as px
  import pandas as pd
  import numpy as np

  df = shapley_contrib.copy()

  contrib_vars = df.groupby("variable").agg(contribution_abs=("contribution", lambda s: s.abs().max())).sort_values("contribution_abs", ascending=False).head(10).index.values
  df = df[df.variable.isin(contrib_vars)]

  light_scale = [
      (0.00, "#ccffcc"),  # light green (most negative)
      (0.50, "#ffffff"),  # white (zero)
      (1.00, "#ffcccc"),  # light red (most positive)
  ]

  units = ""
  df["value_text"]  = df["contribution"].map(lambda v: f"{v:,.2f} {units}")
  arrow = np.where(df["value_change"].to_numpy() > 0, "▲",
              np.where(df["value_change"].to_numpy() < 0, "▼", "•"))

  df["arrow_text"] = [f"{a}{p:.2f}{units}" for a, p in zip(arrow, df["value_change"])]

  # color range based on pct_cost
  if len(df):
      cabs = float(np.nanmax(np.abs(df["contribution"])))  # max distance from 0
      if cabs == 0:
          cabs = 1.0  # avoid degenerate range if all zeros
  else:
      cabs = 1.0

  cmin = -cabs
  cmax = cabs

  # --- base bars (color by current_cost) ---
  fig = px.bar(
      df,
      x="variable",
      y="contribution",
      facet_col="AB_Grade_ID",
      facet_col_wrap=1,
      text="value_text",
      color="contribution",                 # << color by COST
      color_continuous_scale=light_scale,   # << light palette
      range_color=[cmin, cmax],   
      custom_data=["arrow_text","value_change","contribution"], 
  )

  for tr in list(fig.data):
      if tr.type != "bar":
          continue
      cd = getattr(tr, "customdata", None)
      if cd is None:
          continue
      cd_list = cd.tolist() if hasattr(cd, "tolist") else list(cd)
      arrow_text = [row[0] for row in cd_list]
      pct_vals   = [row[1] for row in cd_list]
      contrib_vals   = [row[2] for row in cd_list]
  
      yvals = np.asarray(tr.y, dtype=float)
      xvals = np.asarray(tr.x)
  
      # single symmetric pad based on magnitude
      if yvals.size:
          pad = 0.03 * np.nanmax(np.abs(yvals))
      else:
          pad = 0.03
  
      # colors for all points
      arrow_colors = np.array(
          ["#2ca02c" if p < 0 else "#d62728" if p > 0 else "#666666" for p in pct_vals]
      )
  
      # --- positive (and zero) bars: text ABOVE bar ---
      pos_mask = yvals >= 0
      if np.any(pos_mask):
          fig.add_trace(go.Scatter(
              x=xvals[pos_mask],
              y=yvals[pos_mask] + pad,          # slightly above bar
              mode="text",
              text=[arrow_text[i] for i in np.where(pos_mask)[0]],
              textposition="top center",
              textfont=dict(
                  size=11,
                  color=arrow_colors[pos_mask],
              ),
              hoverinfo="skip",
              showlegend=False,
              xaxis=getattr(tr, "xaxis", "x"),
              yaxis=getattr(tr, "yaxis", "y"),
              cliponaxis=False,
          ))
  
      # --- negative bars: text BELOW bar ---
      neg_mask = yvals < 0
      if np.any(neg_mask):
          fig.add_trace(go.Scatter(
              x=xvals[neg_mask],
              y=yvals[neg_mask] - pad,          # slightly below bar end
              mode="text",
              text=[arrow_text[i] for i in np.where(neg_mask)[0]],
              textposition="bottom center",
              textfont=dict(
                  size=11,
                  color=arrow_colors[neg_mask],
              ),
              hoverinfo="skip",
              showlegend=False,
              xaxis=getattr(tr, "xaxis", "x"),
              yaxis=getattr(tr, "yaxis", "y"),
              cliponaxis=False,
          ))

  # inside text + thin borders; black text stays readable with light scale
  fig.update_traces(
      selector=dict(type="bar"),
      textposition="inside",
      insidetextanchor="middle",
      textfont=dict(size=11, color="black"),
      cliponaxis=False,
  
      marker_line_color="rgba(60,60,60,0.5)",
      marker_line_width=0.8,
  )
  fig.update_yaxes(matches=None)


  base_width=800
  aspect_ratio=16/16
  fig.update_layout(
      autosize=True,
      width=None,
      height=base_width*aspect_ratio,
      template="simple_white",
      plot_bgcolor="white",
      paper_bgcolor="white"
      )

  return fig

def _overall_analysis_table(process_data, grades_drilldown, reference_drilldown):
  dfp = process_data
  dfp = dfp[dfp.AB_Grade_ID.isin(grades_drilldown)]

  tt1 = drilldown_df(dfp, 1, "cost", reference_drilldown, _agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars())  

  color_variable_summary ="grade"   
  if reference_drilldown=="week":
      x_variable_summary="week"
  else:
      x_variable_summary="target"

  y_variable_summary = "Combined_cost__€/T_" 
  df, dfg, c, x_var, color_var = get_process_grouped(dfp, y_variable_summary, x_variable_summary, color_variable_summary, _agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars())       
  A=dfg.rename(columns={"n": "n_samples"}).reset_index()

  if reference_drilldown=="week":
      t = dfg.Wedge_Week.max() - 1
      mix_comp= decompose_avg_cost_change(A[A.Wedge_Week==(t)], A[A.Wedge_Week==(t+1)],y_variable_summary)
      tt1=tt1.rename(columns={"cost":"component","current_cost":"cost","pct_cost":"Δ","Wedge_Week":"week"})
      tt1=tt1[["week","AB_Grade_ID","component","cost","n","Δ"]]   
  else:
      mix_comp= decompose_avg_cost_change(A[A.target=="historic"], A[A.target=="current"],y_variable_summary)
      tt1=tt1.rename(columns={"cost":"component","current_cost":"cost","pct_cost":"Δ"})
      tt1=tt1[["target","AB_Grade_ID","component","cost","n","Δ"]]   
  
  
  tt1["cost"]=round(tt1["cost"],1)
  tt1["Δ"]=round(tt1["Δ"],1)
  tt1["Δ Mix Effect"] = round(mix_comp["mix_effect"],1)
  tt1["Δ Cost Effect"] = round(mix_comp["cost_effect"],1)

  tt2 = drilldown_df(dfp, 1,"overprocessing",reference_drilldown, _agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars())
  tt1["Overprocessing"]=round(tt2["current_cost"],1)

  return tt1

def _grade_analysis_table(process_data, grades_drilldown, reference_drilldown):
  dfp = process_data
  dfp = dfp[dfp.AB_Grade_ID.isin(grades_drilldown)]

  tt1 = drilldown_df(dfp, 2, "cost", reference_drilldown, _agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars())  

  if reference_drilldown=="week":
      tt1=tt1.rename(columns={"cost":"component","current_cost":"cost","pct_cost":"Δ","Wedge_Week":"week"})
      tt1=tt1[["week","AB_Grade_ID","component","cost","n","Δ"]]   
  else:
      tt1=tt1.rename(columns={"cost":"component","current_cost":"cost","pct_cost":"Δ"})
      tt1=tt1[["target","AB_Grade_ID","component","cost","n","Δ"]]   

  tt1["cost"]=round(tt1["cost"],1)
  tt1["Δ"]=round(tt1["Δ"],1)

  tt2 = drilldown_df(dfp, 2,"overprocessing", reference_drilldown, _agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars())
  tt1["Overprocessing"]=round(tt2["current_cost"],1)

  return tt1

def _component_analysis_table(process_data, grades_drilldown, reference_drilldown):
  dfp = process_data
  dfp = dfp[dfp.AB_Grade_ID.isin(grades_drilldown)]

  tt1 = drilldown_df(dfp, 3,"cost",reference_drilldown, _agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars())  

  if reference_drilldown=="week":
      tt1=tt1.rename(columns={"cost":"component","current_cost":"cost","pct_cost":"Δ","Wedge_Week":"week"})
      tt1=tt1[["week","AB_Grade_ID","component","cost","n","Δ"]] 
  else:
      tt1=tt1.rename(columns={"cost":"component","current_cost":"cost","pct_cost":"Δ"})
      tt1=tt1[["target","AB_Grade_ID","component","cost","n","Δ"]]
  
  tt1["cost"]=round(tt1["cost"],1)
  tt1["Δ"]=round(tt1["Δ"],1)

  tt1["component"]=tt1["component"].str.replace("__€/T_","")
  tt1["component"]=tt1["component"].str.replace("_cost","")
                        
  if reference_drilldown=="week":
      pivot = tt1.pivot_table(
          index=["week","AB_Grade_ID","n"],
          columns="component",
          values=["cost", "Δ"],            
      )
  else:
      pivot = tt1.pivot_table(
          index=["target","AB_Grade_ID","n"],
          columns="component",
          values=["cost", "Δ"],            
      )

  tt2 = drilldown_df(dfp, 2,"overprocessing", reference_drilldown, _agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars())        

  
  df_grid = pivot.copy()
  if isinstance(df_grid.index, pd.MultiIndex):
      df_grid = df_grid.reset_index()

  # 2. Flatten MultiIndex columns into single strings
  def flatten_col(c):
      # c will be a tuple for MultiIndex; leave non-tuples as is
      if isinstance(c, tuple):
          # join non-empty levels with "__"
          parts = [str(p) for p in c if p not in (None, "")]
          return "__".join(parts)
      return c

  df_grid.columns = [flatten_col(c) for c in df_grid.columns]
  df_grid["Overprocessing"]=round(tt2["current_cost"],1)

  return df_grid

def drilldown_plot(process_data, level, object_drilldown, reference_drilldown, grades_drilldown):
  dfp = process_data
  dfp = dfp[dfp.AB_Grade_ID.isin(grades_drilldown)]

  C = drilldown_df(dfp, level, object_drilldown, reference_drilldown, _agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars())
  if object_drilldown=="overprocessing":
      units="%"            
  elif object_drilldown=="cost":
      units="€/t"
  else:
      units=""
  fig = plot_cost_breakdown(C, free_y=True, units=units, title=f"Comparison of {object_drilldown} by grade and {reference_drilldown}")
  if level==1:
      mix, efficiency = mix_effect(object_drilldown, reference_drilldown, grades_drilldown, process_data)
      for tr in fig.data:
          if tr.type == "scatter" and tr.mode == "text" and "top center" in (tr.textposition or ""):                
              if mix > 0:
                  mix_text = f"▲ {round(mix,1)} {units}"
              elif mix < 0:
                  mix_text = f"▼ {round(mix,1)} {units}"
              else:
                  mix_text = f"• 0"
              if efficiency > 0:
                  mix_efficiency = f"▲ {round(efficiency,1)} {units}"
              elif efficiency < 0:
                  mix_efficiency = f"▼ {round(efficiency,1)} {units}"
              else:
                  mix_efficiency = f"• 0"
              tr.text = f"{tr.text[0]} (Mix {mix_text}, Process {mix_efficiency})",
  return fig

def _drilldown_analysis_plot(drilldown, mix_contribution, level, object_drilldown, reference_drilldown):
  C = drilldown

  if object_drilldown=="overprocessing":
      units="%"            
  elif object_drilldown=="cost":
      units="€/t"
  else:
      units=""
  
  fig = plot_cost_breakdown(object_drilldown, C, free_y=True, units=units, title=f"Comparison of {object_drilldown} by grade and {reference_drilldown}")
  if level==1 and mix_contribution is not None:
      mix, efficiency = mix_contribution
      for tr in fig.data:
          if tr.type == "scatter" and tr.mode == "text" and "top center" in (tr.textposition or ""):                
              if mix > 0:
                  mix_text = f"▲ {round(mix,1)} {units}"
              elif mix < 0:
                  mix_text = f"▼ {round(mix,1)} {units}"
              else:
                  mix_text = f"• 0"
              if efficiency > 0:
                  mix_efficiency = f"▲ {round(efficiency,1)} {units}"
              elif efficiency < 0:
                  mix_efficiency = f"▼ {round(efficiency,1)} {units}"
              else:
                  mix_efficiency = f"• 0"
              tr.text = f"{tr.text[0]} (Mix {mix_text}, Process {mix_efficiency})",
  return fig

def _strengthplot(strength_df, plotly_theme, igrade):
  import plotly.express as px
  import plotly.graph_objects as go
  import numpy as np

  df=strength_df
  df["cluster"]=df["cluster"].astype(str)
  template = plotly_theme
  nbins_hist = 10
  nbins2d = 10

  if df.empty:
      raise ValueError("Input dataframe is empty.")
  req_cols = {"MBS_Current_reel_ID", "property", "value", "min"}
  missing = req_cols - set(df.columns)
  if missing:
      raise ValueError(f"Missing required columns: {missing}")

  # Ensure cluster is string when present
  if "cluster" in df.columns:
      df = df.copy()
      df["cluster"] = df["cluster"].astype(str)

  props = df["property"].dropna().unique().tolist()
  if len(props) == 0:
      raise ValueError("Column 'property' has no values.")
  if len(props) > 2:
      raise ValueError("This helper supports up to 2 properties.")

  # Build a consistent color map from clusters -> Alphabet
  palette = px.colors.qualitative.Alphabet
  if "cluster" in df.columns:
      clusters = sorted(df["target"].dropna().unique().tolist())
      #color_map = {cl: palette[i % len(palette)] for i, cl in enumerate(clusters)}
      color_map =  dict(zip(["historic","best","current","none"], ["blue","green","red","gray"]))
      category_orders = {"cluster": clusters}
      color_arg = "cluster"
  else:
      color_map = None
      category_orders = None
      color_arg = None

  # ---------- CASE A: ONE PROPERTY -> mirror (value vs value) ----------
  if len(props) == 1:
      p = props[0]
      dP = df[df["property"] == p].copy()

      # Global min for this property (prefer unique, fallback to median)
      mins = dP["min"].dropna().unique()
      p_min = float(mins[0]) if len(mins) == 1 else float(dP["min"].median())

      # Build a "wide" dataframe with identical x/y = value
      # Keep cluster for coloring (if present)
      pivot = dP[["MBS_Current_reel_ID", "value"] + ([ "cluster"] if "cluster" in dP.columns else [])].copy()
      pivot.rename(columns={"value": f"value_{p}"}, inplace=True)
      # Duplicate as y column
      pivot[f"value_{p}_y"] = pivot[f"value_{p}"]

      xcol = f"value_{p}"
      ycol = f"value_{p}_y"

      jitter_frac = 0.10
      rng = np.random.default_rng(42)
      val_std = float(np.nanstd(pivot[xcol])) or 1.0
      jitter_scale = jitter_frac * val_std
      pivot[ycol] = pivot[ycol] + rng.normal(0.0, jitter_scale, size=len(pivot))
      pivot[xcol] = pivot[xcol] + rng.normal(0.0, jitter_scale, size=len(pivot))

      # Scatter + marginals (PDFs)
      fig = px.scatter(
          pivot,
          x=xcol,
          y=ycol,
          color=color_arg,
          opacity=0.8,
          marginal_x="histogram",
          marginal_y="histogram",
          template=template,
          color_discrete_map=color_map,
          category_orders=category_orders
      )

      # Make marginal histograms show PDF
      fig.update_traces(
          selector=dict(type="histogram"),
          histnorm="probability density",
          nbinsx=nbins_hist,
          nbinsy=nbins_hist,
          opacity=0.5
      )

      # 2D density contours (on the mirrored data)
      d2 = px.density_contour(
          pivot,
          x=xcol,
          y=ycol,
          color=None,
          nbinsx=nbins2d,
          nbinsy=nbins2d,
          template=template
      )
      for tr in d2.data:
          tr.update(line=dict(color="rgba(0,0,0,0.35)", width=1), showscale=False, hoverinfo="skip")
          fig.add_trace(tr)

      # y=x reference (main panel only)
      # Determine range
      x_min_data = np.nanmin(pivot[xcol])
      x_max_data = np.nanmax(pivot[xcol])
      fig.add_trace(go.Scatter(
          x=[x_min_data, x_max_data],
          y=[x_min_data, x_max_data],
          mode="lines",
          line=dict(color="rgba(0,0,0,0.25)", dash="dot"),
          name="y=x",
          showlegend=False
      ))

      # Red min lines (same threshold on both axes), main panel only
      fig.add_shape(
          type="line",
          x0=p_min, x1=p_min, y0=0, y1=1,
          xref="x", yref="y domain",
          line=dict(color="red", width=2, dash="dash"),
          layer="above"
      )
      fig.add_shape(
          type="line",
          x0=0, x1=1, y0=p_min, y1=p_min,
          xref="x domain", yref="y",
          line=dict(color="red", width=2, dash="dash"),
          layer="above"
      )

      fig.update_layout(
          xaxis_title=p,
          yaxis_title=p,
          legend_title="cluster" if color_arg else None,
          title=f"Strength {igrade}"
      )
      return fig

  # ---------- CASE B: TWO PROPERTIES ----------
  p1, p2 = props

  # Wide pivot: one row per reel (+ cluster), value/min per property
  pivot = df.pivot_table(
      index=["MBS_Current_reel_ID"] + (["cluster"] if "cluster" in df.columns else []),
      columns="property",
      values=["value", "min"],
      aggfunc="first"
  )
  pivot.columns = [f"{a}_{b}" for a, b in pivot.columns]  # ('value','P1')->'value_P1'
  pivot = pivot.reset_index()

  xcol, ycol = f"value_{p1}", f"value_{p2}"

  # Min thresholds (prefer unique per property; else median)
  x_min_vals = df.loc[df["property"] == p1, "min"].dropna().unique()
  y_min_vals = df.loc[df["property"] == p2, "min"].dropna().unique()
  x_min = float(x_min_vals[0]) if len(x_min_vals) == 1 else float(df.loc[df["property"] == p1, "min"].median())
  y_min = float(y_min_vals[0]) if len(y_min_vals) == 1 else float(df.loc[df["property"] == p2, "min"].median())

  # Scatter + marginals with consistent colors
  fig = px.scatter(
      pivot,
      x=xcol,
      y=ycol,
      color=color_arg,
      opacity=0.8,
      marginal_x="histogram",
      marginal_y="histogram",
      template=template,
      color_discrete_map=color_map,
      category_orders=category_orders
  )

  #Marginals as PDFs
  fig.update_traces(
      selector=dict(type="histogram"),
      histnorm="probability density",
      nbinsx=nbins_hist,
      nbinsy=nbins_hist,
      opacity=0.5
  )        

  # 2D density contours
  d2 = px.density_contour(
      pivot,
      x=xcol,
      y=ycol,
      color=None,
      nbinsx=nbins2d,
      nbinsy=nbins2d,
      template=template
  )
  for tr in d2.data:
      tr.update(line=dict(color="rgba(0,0,0,0.35)", width=1), showscale=False, hoverinfo="skip")
      fig.add_trace(tr)

  # Red min lines (main panel only)
  fig.add_shape(
      type="line",
      x0=x_min, x1=x_min, y0=0, y1=1,
      xref="x", yref="y domain",
      line=dict(color="red", width=2, dash="dash"),
      layer="above"
  )
  fig.add_shape(
      type="line",
      x0=0, x1=1, y0=y_min, y1=y_min,
      xref="x domain", yref="y",
      line=dict(color="red", width=2, dash="dash"),
      layer="above"
  )

  fig.update_layout(
      xaxis_title=p1,
      yaxis_title=p2,
      legend_title="cluster" if color_arg else None,
      title=f"Strength {igrade}"
  )
  return fig

def _scoringplot(grade_data_process_clustered, scores_clustered, best_cluster, variable_x_scoring, variable_y_scoring, feature_scoring, samples_pca, centroids_pca, plotly_theme):
  import plotly.graph_objects as go
  import numpy as np
  import plotly.express as px

  bc = best_cluster

  if feature_scoring == "score":
      datax = scores_clustered.copy()
      datay = scores_clustered.copy()
  else:
      datax = grade_data_process_clustered.copy()
      datay = scores_clustered.copy()

  # ensure consistent types
  datax["cluster"] = datax["cluster"].astype(str)
  datay["cluster"] = datay["cluster"].astype(str)

  varx = variable_x_scoring if feature_scoring == "score" else feature_scoring
  vary = variable_y_scoring

  pcgx = datax[[varx, "cluster"] + (["target"] if "target" in datax.columns else [])]
  pcgy = datay[[vary, "cluster"] + (["target"] if "target" in datay.columns else [])]

  pcgx_stat = pcgx.groupby(["cluster"]).agg(avg=(varx, "mean"), std=(varx, "std")).reset_index()
  pcgy_stat = pcgy.groupby(["cluster"]).agg(avg=(vary, "mean"), std=(vary, "std")).reset_index()

  fig = go.Figure()

  if samples_pca:
      for cluster in sorted(datax["cluster"].unique()):
          selx = datax["cluster"] == cluster
          sely = datay["cluster"] == cluster

          cluster_datax = datax.loc[selx, :]
          cluster_datay = datay.loc[sely, :]

          x_vals = cluster_datax[varx].to_numpy()
          y_vals = cluster_datay[vary].to_numpy()

          # Determine the 'target' per point; prefer datax if available, else datay; else None
          if "target" in cluster_datax.columns:
              target_vals = cluster_datax["target"].astype(str).to_numpy()
          elif "target" in cluster_datay.columns:
              target_vals = cluster_datay["target"].astype(str).to_numpy()
          else:
              target_vals = None

          color = px.colors.qualitative.Alphabet[int(cluster)]
          size = 12 if int(cluster) == bc else 8

          # Build per-point outline styling
          if target_vals is not None:
              is_current = (target_vals == "current")
              line_colors = np.where(is_current, "red", color)
              line_widths = np.where(is_current, 2, 1)
          else:
              # fallback (no 'target' column)
              line_colors = color
              line_widths = 2

          trace = go.Scatter(
              x=x_vals,
              y=y_vals,
              mode="markers",
              name=f"Best {cluster}" if int(cluster) == bc else f"Cluster {cluster}",
              marker=dict(
                  symbol="circle",
                  color=color,
                  size=size,
                  line=dict(
                      color=line_colors,  # supports array-like for per-point outline color
                      width=line_widths   # supports array-like for per-point outline width
                  )
              ),
              showlegend=True
          )
          fig.add_trace(trace)

  if centroids_pca:
      for i, row in pcgx_stat.iterrows():
          cluster = int(row["cluster"])
          avg_x = row["avg"]
          avg_y = pcgy_stat.loc[i, "avg"]
          color = px.colors.qualitative.Alphabet[cluster]

          trace = go.Scatter(
              x=[avg_x],
              y=[avg_y],
              mode="markers",
              name=f"Best {cluster}" if int(cluster) == bc else f"Cluster {cluster}",
              marker=dict(
                  symbol="x",
                  color=color,
                  size=20 if int(cluster) == bc else 15,
                  line=dict(width=2)
              ),
              showlegend=False if samples_pca else True
          )
          fig.add_trace(trace)

          std_x = row["std"]
          std_y = pcgy_stat.loc[i, "std"]
          if (pd.notna(std_x) and pd.notna(std_y) and (std_x > 0) and (std_y > 0)):
              fig.add_shape(
                  type="circle",
                  xref="x",
                  yref="y",
                  x0=avg_x - 2 * std_x,
                  x1=avg_x + 2 * std_x,
                  y0=avg_y - 2 * std_y,
                  y1=avg_y + 2 * std_y,
                  fillcolor=color,
                  line=dict(color=color),
                  opacity=0.3 if int(cluster) == bc else 0.2,
                  layer="below",
              )

  fig.update_layout(
      showlegend=True,
      margin=dict(t=40, b=40, l=40, r=40),
      autosize=True,
      template=plotly_theme
  )

  return fig

def _loadingsplot(principal_component, plotly_theme):
  import plotly.graph_objects as go

  pc = principal_component
  fig = go.Figure(go.Bar(
      x=pc.weight,
      y=pc.feature,
      orientation='h'))

  fig.update_layout(yaxis={'categoryorder': 'total ascending'},margin=dict(t=40, b=40, l=40, r=40), autosize=True, template=plotly_theme)

  return fig

def _clusteredcostplot(grade_data_process_clustered, acceptable_clusters, best_cluster, iclustered_cost, plotly_theme):
  import plotly.express as px

  aa = acceptable_clusters
  c = dict(zip(["historic","best","current"], ["blue","green","red"]))

  gdpc=grade_data_process_clustered.copy()

  bc = best_cluster
  gdpc.loc[gdpc["cluster"] == bc, "target"] = "best"
  
  gdpc=gdpc.sort_values("cluster")

  fig = px.box(
      gdpc, 
      x="cluster", 
      y=iclustered_cost, 
      color="cluster",
      color_discrete_sequence=px.colors.qualitative.Alphabet
  )
  
  quantile = gdpc.groupby("cluster")[iclustered_cost].quantile(0.65)
  for cluster, quantile in quantile.items():
      if len(gdpc[(gdpc.target!="current") & (gdpc.cluster==cluster)])==0:
          label = "CURRENT"
      else:
          if cluster==bc:
              label = "BEST"
          elif cluster in aa:
              label = "OK"
          else:
              label = "BAD"
      fig.add_annotation(
      x=cluster,
          y=quantile,  # slightly above median
          text=label,
          showarrow=False,
          font=dict(color="red" if label == "BAD" else "green", size=12),
          xanchor="center"
      )

  # Optional: set figure layout to auto-size
  fig.update_layout(margin=dict(t=40, b=40, l=40, r=40), autosize=True, template=plotly_theme)
  #fig.update_traces(boxpoints=False) 
  return fig

def _costevolutionplot(raw_data, igrade, i_variable_benchmark, target_range, baseline_range, box_evolution, plotly_theme):
  import plotly.express as px
  import plotly.graph_objects as go

  c = dict(zip(["historic","best","current","none"], ["blue","green","red","gray"]))
  
  
  df = raw_data.copy()
  df["Wedge_Time"] = pd.to_datetime(df["Wedge_Time"])
  df["Wedge_Date"]=df["Wedge_Time"].dt.date
  df["target"]="none"
  df.loc[(df.Wedge_Time.dt.date>=target_range[0]) & (df.Wedge_Time.dt.date<=target_range[1]),"target"]="current"
  df.loc[(df.Wedge_Time.dt.date>=baseline_range[0]) & (df.Wedge_Time.dt.date<=baseline_range[1]),"target"]="historic"   
  df = df[df.Wedge_Time.dt.date <= target_range[1]]     
  
  # TO REMOVE
  df_temp=df[df.target=="historic"].groupby("AB_Grade_ID").agg({"Steam__€/T_":"mean"}).reset_index()
  df["Aggregated_cost__€/T_"]=df["Aggregated_cost__€/T_"]-df["Steam__€/T_"]
  df["Combined_cost__€/T_"]=df["Aggregated_cost__€/T_"]-df["Steam__€/T_"]
  df.drop("Steam__€/T_",axis=1,inplace=True)
  df=df.merge(df_temp,on="AB_Grade_ID", how="left")
  df["Aggregated_cost__€/T_"]=df["Aggregated_cost__€/T_"]+df["Steam__€/T_"]
  df["Combined_cost__€/T_"]=df["Aggregated_cost__€/T_"]+df["Steam__€/T_"]
  # END TO REMOVE

  
  df=df[df["AB_Grade_ID"] == igrade][["target","Wedge_Date",i_variable_benchmark]]

  if box_evolution:
      fig = px.box(
          df, 
          x="Wedge_Date", 
          y=i_variable_benchmark, 
          color="target",
          color_discrete_map=c
      )
      fig.update_traces(marker=dict(opacity=0)) 
  else:            
      fig = px.line(                 
          x=df["Wedge_Date"], 
          y=df.groupby("Wedge_Date")[i_variable_benchmark].transform("mean"), 
          color=df["target"],
          color_discrete_map=c,
          markers=True              
      )
      
  
  fig.update_layout(
      title=go.layout.Title(
              text=f"{igrade}: {i_variable_benchmark}",
              xref="paper",
              x=0
          ),
          template=plotly_theme,
          margin=dict(t=40, b=40, l=40, r=40), 
          autosize=True
      )
  
  return fig

def _benchmarkplot(data, true_savings, potential_savings, p_value_hc, p_value_bc, i_variable_benchmark, igrade, plotly_theme):    
  import plotly.express as px
  import numpy as np
  import plotly.graph_objects as go

  c = dict(zip(["historic","best","current"], ["blue","green","red"]))

  if "€" in i_variable_benchmark:
      if p_value_bc is np.inf or p_value_bc > 0.05:
          msg=f"Current savings {round(true_savings,1)} €/T (p-value:{round(p_value_hc,4)})"
      else:
          msg=f"Current savings {round(true_savings,1)} €/T (p-value:{round(p_value_hc,4)}), Potential savings {round(-potential_savings, 1)} €/T (p-value:{round(p_value_bc,4)})"
      
  else:
      if p_value_bc is np.inf:
          msg=f"Current improvement {round(-true_savings,1)} (p-value:{round(p_value_hc,4)})"
      else:
          msg=f"Current improvement {round(-true_savings,1)} (p-value:{round(p_value_hc,4)}), Potential improvement {round(-potential_savings, 1)} (p-value:{round(p_value_bc,4)})"

  
  
  fig = px.box(data, x="target", y = i_variable_benchmark, color="target",color_discrete_map=c)
  fig.update_layout(
      title=go.layout.Title(
              text=f"{igrade}: {i_variable_benchmark}",
              xref="paper",
              x=0
          ),
          xaxis=go.layout.XAxis(
              title=go.layout.xaxis.Title(
                  text=msg
                  )
          ),
          template=plotly_theme,
          margin=dict(t=40, b=40, l=40, r=40), 
          autosize=True
      )
  
  return fig

def _clusteredqualityplot(grade_data_process_clustered, acceptable_clusters, best_cluster, quality_limits, iclustered_quality, box_quality, plotly_theme):
  import plotly.express as px

  aa = acceptable_clusters
  c = dict(zip(["historic","best","current"], ["blue","green","red"]))

  sp=quality_limits

  if "min" in sp.variable.unique():
      min_value=sp[sp.variable=="min"].value.values[0]
  else:
      min_value=None

  if "target" in sp.variable.unique():
      target_value=sp[sp.variable=="target"].value.values[0]
  else:
      target_value=None

  gdpc=grade_data_process_clustered.copy()
  

  bc = best_cluster
  gdpc.loc[gdpc["cluster"] == bc, "target"] = "best"
  
  gdpc=gdpc.sort_values("cluster")
  
  if box_quality:
      fig = px.box(
          gdpc, 
          x="cluster", 
          y=iclustered_quality, 
          color="cluster",
          color_discrete_sequence=px.colors.qualitative.Alphabet
      )
  else:
      fig = px.strip(
          gdpc, 
          x="cluster", 
          y=iclustered_quality, 
          color="target",
          color_discrete_map=c
      )


  quantiles = gdpc.groupby("cluster")[iclustered_quality].quantile(0.65)
  for cluster, quantile in quantiles.items():
      if len(gdpc[(gdpc.target!="current") & (gdpc.cluster==cluster)])==0:
          label = "CURRENT"
      else:
          if cluster==bc:
              label = "BEST"
          elif cluster in aa:
              label = "OK"
          else:
              label = "BAD"

      fig.add_annotation(
          x=cluster,
          y=quantile,  # slightly above median
          text=label,
          showarrow=False,
          font=dict(color="red" if label == "BAD" else "green", size=12),
          xanchor="center"
      )

  if min_value is not None:
      fig.add_shape(
          type="line",
          x0=gdpc.cluster.min(),
          x1=gdpc.cluster.max(),
          y0=min_value,
          y1=min_value,
          xref="paper",  # spans the entire x-axis
          yref="y",      # in data coordinates
          line=dict(color="Red", width=2, dash="dash")  # customize color/style
      )

  if target_value is not None:
      fig.add_shape(
          type="line",
          x0=gdpc.cluster.min(),
          x1=gdpc.cluster.max(),
          y0=target_value,
          y1=target_value,
          xref="paper",  # spans the entire x-axis
          yref="y",      # in data coordinates
          line=dict(color="Green", width=2, dash="dash")  # customize color/style
      )


  # Optional: set figure layout to auto-size
  fig.update_layout(margin=dict(t=40, b=40, l=40, r=40), autosize=True, template=plotly_theme)
  #fig.update_traces(boxpoints=False) 
  return fig

def _oprangeplot(grade_data_process_clustered, best_cluster, principalfeature_oprange, principal_oprange, filter_oprange, box_oprange, igrade, plotly_theme):
  import plotly.graph_objects as go
  import plotly.express as px

  if "all" in principal_oprange:
      gdpc=grade_data_process_clustered.copy()
      bc = best_cluster
      gdpc.loc[(gdpc["cluster"] == bc) & (gdpc["target"] == "historic"), "target"] = "best"
      gdpc=gdpc[gdpc.target=="best"]
      gdpc=pd.melt(gdpc[_cost_influencers_1() + _cost_influencers_2() + _cost_influencers_3()], var_name="feature").reset_index(drop=True).groupby("feature")["value"].agg("mean").reset_index().sort_values("feature")
      gdpc["value"]=round(gdpc["value"],2)
      fig = go.Figure(
          data=[go.Table(
              header=dict(values=list(gdpc.columns)),
              cells=dict(values=[gdpc[c] for c in gdpc.columns])
          )]
      )
      return fig
  else:
      gdpc=grade_data_process_clustered.copy()
      bc = best_cluster
      gdpc.loc[(gdpc["cluster"] == bc) & (gdpc["target"] == "historic"), "target"] = "best"
      c = dict(zip(["historic","best","current"], ["blue","green","red"]))
      
      if filter_oprange:
          gdpc=gdpc[gdpc.target=="best"]

      gdpc=pd.melt(gdpc[["cluster","target"]+list(principalfeature_oprange)], id_vars=["cluster","target"],var_name="feature").reset_index()

      if len(gdpc)>0:
          if box_oprange:
              fig = px.box(gdpc, 
                      x="cluster", 
                      y="value", 
                      color="target",
                      facet_col="feature",
                      facet_col_wrap=3,
                      color_discrete_map=c
                  )
          else:
              fig = px.strip(gdpc, 
                      x="cluster", 
                      y="value", 
                      color="target",
                      facet_col="feature",
                      facet_col_wrap=3,
                      color_discrete_map=c
                  )
              

          fig.update_yaxes(matches=None, showticklabels=True)

          fig.update_layout(margin=dict(t=40, b=40, l=40, r=40), autosize=True, template=plotly_theme,title=f"Cost effective Operating range {igrade}")
          return fig
      else:
          fig= go.Figure()
          fig.update_layout(margin=dict(t=40, b=40, l=40, r=40), autosize=True, template=plotly_theme)
          return fig

def _featureclusteredplot(grade_data_process_clustered, principalfeature_pca, plotly_theme):
  import plotly.express as px

  c = dict(zip(["historic","best","current"], ["blue","green","red"]))

  fig = px.strip(grade_data_process_clustered, 
          x="cluster", 
          y=principalfeature_pca, 
          color="target",
          color_discrete_map=c,
          stripmode = "overlay"   # Select between "group" or "overlay" mode
      )

  fig.update_layout(margin=dict(t=40, b=40, l=40, r=40), autosize=True, template=plotly_theme)
  return fig

def _correlationplot(grade_data_general, itarget, plotly_theme):
  import plotly.express as px

  c = dict(zip(["historic","best","current"], ["blue","green","red"]))

  fig = px.box(
      grade_data_general(), 
      x="AB_Grade_ID", 
      y=itarget, 
      color="target",
      color_discrete_map=c
  )
  # Optional: set figure layout to auto-size
  fig.update_layout(margin=dict(t=40, b=40, l=40, r=40), autosize=True, template=plotly_theme)
  return fig

def _summary_cost_plot(process_data, x_variable_summary, y_variable_summary, y_variable_summary_secondary, color_variable_summary, trim_summary, grades_summary, type_summary, summary_bar_lines, plotly_theme):      
  import plotly.express as px
  import numpy as np
  from plotly.subplots import make_subplots
  import plotly.graph_objects as go

  if trim_summary:
      df = process_data.sort_values(["grammage","paper_type"])
      df[y_variable_summary]=np.where(df[y_variable_summary]>df[y_variable_summary].mean(),df[y_variable_summary].mean(),df[y_variable_summary])
  else:    
      df = process_data.sort_values(["grammage","paper_type"])

  df = df[df.AB_Grade_ID.isin(grades_summary)]


  df, dfg, c, x_var, color_var =  get_process_grouped(df, y_variable_summary, x_variable_summary, color_variable_summary, _agg_cost_label2(), _costs_to_consider2(), _overprocessing_vars(), y_variable_summary_secondary)

  
  if type_summary=="box":
      fig = px.box(
          df.astype({x_var: 'str'}),
          x=x_var, 
          y=y_variable_summary, 
          color=color_var,
          color_discrete_map=c,
          category_orders=  {x_var:[str(v) for v in dfg[x_var].unique()]}
      )
      # Optional: set figure layout to auto-size
      fig.update_layout(margin=dict(t=40, b=40, l=40, r=40), autosize=True, template=plotly_theme)
  elif type_summary=="line":            
      fig = px.line(
          dfg.astype({x_var: 'str'}), 
          x=x_var, 
          y=y_variable_summary, 
          color=color_var,
          color_discrete_map=c,
          markers=True,
          category_orders=  {x_var:[str(v) for v in dfg[x_var].unique()]}
      )
      # Optional: set figure layout to auto-size
      fig.update_layout(margin=dict(t=40, b=40, l=40, r=40), autosize=True, template=plotly_theme)
  elif type_summary=="violin":
      fig = px.violin(
          df.astype({x_var: 'str'}),
          x=x_var, 
          y=y_variable_summary, 
          color=color_var,
          color_discrete_map=c,
          points="all",
          category_orders=  {x_var:[str(v) for v in dfg[x_var].unique()]}
          #jitter=0.35
      )

      fig.update_traces(
          selector=dict(type="violin"),
          points="all",
          pointpos=0,           # 0=center of the violin; [-1,1] moves left/right
          jitter=0.3,           # horizontal jitter so they spread within the violin
          marker=dict(size=4, opacity=0.55),
          width=0.9             # (optional) wider violins
      )
      
      # key: overlay the color traces instead of grouping side-by-side
      fig.update_layout(violinmode="overlay")

      fig.update_layout(margin=dict(t=40, b=40, l=40, r=40), autosize=True, template=plotly_theme)
  elif type_summary=="bar":
      fig = make_subplots(specs=[[{"secondary_y": True}]])
      
      bar_fig = []
      if  color_var is None:
          group_df = dfg    
          if x_variable_summary=="week" and color_variable_summary=="grade":
              
              width_base=(dfg[x_var].max()-dfg[x_var].min())/(len(dfg[x_var].unique())*dfg["n"].max())
              bar_fig.append(go.Bar(
                  x=group_df[x_var],
                  y=group_df[y_variable_summary],            
                  width=width_base*group_df["n"]
              ))
          else:
              bar_fig.append(go.Bar(
                  x=group_df[x_var],
                  y=group_df[y_variable_summary],
              ))

          for tr in bar_fig:
              fig.add_trace(tr, secondary_y=False)
      else:
          for group in dfg[color_var].unique():
              group_df = dfg[dfg[color_var] == group]
              
      
              if x_variable_summary=="week" and color_variable_summary=="grade":
                  
                  weeks = dfg[x_var].unique()                  
                  weeks_dif = int(weeks[-1])-int(weeks[0])

                  if weeks_dif<=0:
                      weeks_dif += 52

                  width_base=(weeks_dif)/(len(dfg[x_var].unique())*len(dfg[color_var].unique())*dfg["n"].max())
                  bar_fig.append(go.Bar(
                      x=group_df[x_var],
                      y=group_df[y_variable_summary],                                
                      name=f"{group}",
                      marker=dict(color=c[group]),
                      legendgroup=group,
                      width=width_base*group_df["n"]
                  ))
              else:
                  bar_fig.append(go.Bar(
                      x=group_df[x_var],
                      y=group_df[y_variable_summary], 
                      name=f"{group}",
                      marker=dict(color=c[group]),
                      legendgroup=group,                    
                  ))                

          for tr in bar_fig:
              fig.add_trace(tr, secondary_y=False)

      if summary_bar_lines:
          if x_variable_summary=="grade":
              if color_variable_summary=="cost":
                  df_1= df.groupby([x_var, "grammage","paper_type","cost"])[y_variable_summary].agg("mean").reset_index().sort_values(["grammage","paper_type"])
                  df_1= df_1.groupby([x_var, "grammage","paper_type"])[y_variable_summary].agg("sum").reset_index().sort_values(["grammage","paper_type"])

              else:
                  df_1= df.groupby([x_var, "grammage","paper_type"])[y_variable_summary].agg("mean").reset_index().sort_values(["grammage","paper_type"])
              df_2= df.groupby([x_var, "grammage","paper_type"])[y_variable_summary_secondary].agg("mean").reset_index().sort_values(["grammage","paper_type"])

          else:              
              if x_var=="Wedge_Week":
                  x_var_  = ["Wedge_Year","Wedge_Week"]
              else:
                  x_var_  = ["Wedge_Week"]
              if color_variable_summary=="cost":
                  df_1= df.groupby(x_var_ + ["cost"])[y_variable_summary].agg("mean").reset_index().sort_values(x_var_)
                  df_1= df_1.groupby(x_var_)[y_variable_summary].agg("sum").reset_index().sort_values(x_var_)
              else:
                  df_1= df.groupby(x_var_)[y_variable_summary].agg("mean").reset_index().sort_values(x_var_)
              
              df_2= df.groupby(x_var_)[y_variable_summary_secondary].agg("mean").reset_index().sort_values(x_var_)

              

          fig.add_scatter(
              x=df_1[x_var], 
              y=df_1[y_variable_summary], 
              marker=dict(size=10, color='blue'), 
              mode="lines+markers",
              line=dict(color='blue', width=2),
              name="avg",
              secondary_y=False,
          )
          
          fig.add_scatter(
              x=df_2[x_var], 
              y=df_2[y_variable_summary_secondary], 
              marker=dict(size=10, color='blue'), 
              mode="lines+markers",
              line=dict(color='red', width=2),
              name=y_variable_summary_secondary,
              secondary_y=True,
          )

          y1 = y_variable_summary
          y2 = y_variable_summary_secondary
          primary_vals, secondary_vals = [], []
          for tr in fig.data:
              if tr.type in ("bar", "scatter") and tr.y is not None:
                  vals = [v for v in tr.y if v is not None]
                  if getattr(tr, "yaxis", "y") in ("y", "y1"):
                      primary_vals.extend(vals)
                  elif getattr(tr, "yaxis", None) == "y2":
                      secondary_vals.extend(vals)
          
          def padded_range(vals):
              vmin, vmax = float(np.min(vals)), float(np.max(vals))
              if vmin == vmax:
                  pad = 0.05 * (abs(vmax) + 1.0)
              else:
                  pad = 0.05 * (vmax - vmin)
              return [vmin - pad, vmax + pad]
          
          if primary_vals:
              fig.update_yaxes(autorange=False, range=padded_range(primary_vals), secondary_y=False)
          if secondary_vals:
              fig.update_yaxes(autorange=False, range=padded_range(secondary_vals), secondary_y=True)
      
          # (optional) axis titles
          order = dfg[x_var].astype(str).unique().tolist()
          fig.update_xaxes(
              type="category",
              categoryorder="array",
              categoryarray=order
          )
          fig.update_yaxes(title_text=y1, secondary_y=False)
          fig.update_yaxes(title_text=y2, secondary_y=True)
          # Optional: set figure layout to auto-size
      else:
          y1 = y_variable_summary
          y2 = y_variable_summary_secondary
          primary_vals, secondary_vals = [], []
          for tr in fig.data:
              if tr.type in ("bar") and tr.y is not None:
                  vals = [v for v in tr.y if v is not None]
                  if getattr(tr, "yaxis", "y") in ("y", "y1"):
                      primary_vals.extend(vals)
                  
          
          def padded_range(vals):
              vmin, vmax = float(np.min(vals)), float(np.max(vals))
              if vmin == vmax:
                  pad = 0.05 * (abs(vmax) + 1.0)
              else:
                  pad = 0.05 * (vmax - vmin)
              return [vmin - pad, vmax + pad]
          
          order = dfg[x_var].astype(str).unique().tolist()
          fig.update_xaxes(
              type="category",
              categoryorder="array",
              categoryarray=order
          )

          if primary_vals:
              fig.update_yaxes(autorange=False, range=padded_range(primary_vals), secondary_y=False)
          if secondary_vals:
              fig.update_yaxes(autorange=False, range=padded_range(secondary_vals), secondary_y=True)

      fig.update_layout(margin=dict(t=40, b=40, l=40, r=40), autosize=True, template=plotly_theme,barmode="group")
          
  return fig

def _targetplot(grade_data_general, itarget, plotly_theme):
  import plotly.express as px

  c = dict(zip(["historic","best","current"], ["blue","green","red"]))

  fig = px.box(
      grade_data_general, 
      x="AB_Grade_ID", 
      y=itarget, 
      color="target",
      color_discrete_map=c
  )
  # Optional: set figure layout to auto-size
  fig.update_layout(margin=dict(t=40, b=40, l=40, r=40), autosize=True, template=plotly_theme)
  return fig

def _generalplot(grade_data_general, diff, ivariable_x_general, ivariable_y_general, ivariable_y2_general, ivariable_group_general, plotly_theme):
    import plotly.graph_objects as go
    import plotly.express as px

    df = grade_data_general.copy()
    df["Wedge_Time"] = pd.to_datetime(df["Wedge_Time"])

    if diff:
        num = df.select_dtypes(include="number").diff()  # default axis=0, periods=1            
        df[num.columns] = num

        
    x_col = ivariable_x_general
    y1_col = ivariable_y_general
    y2_col = ivariable_y2_general
    group_col = ivariable_group_general

    traces = []

    # Flag for whether secondary Y should be included
    use_secondary_y = y2_col != ""

    if group_col == "":
        # No grouping
        traces.append(go.Scatter(
            x=df[x_col],
            y=df[y1_col],
            mode='markers',
            name=y1_col,
            marker=dict(color='blue')
        ))

        if use_secondary_y:
            traces.append(go.Scatter(
                x=df[x_col],
                y=df[y2_col],
                mode='markers',
                name=y2_col,
                marker=dict(color='red', symbol='circle-open'),
                yaxis='y2'
            ))

    elif group_col in ["AB_Grade_ID", "target"]:
        # Grouping enabled
        unique_groups = df[group_col].unique()
        color_map = dict(zip(unique_groups, px.colors.qualitative.Plotly))

        for group in unique_groups:
            group_df = df[df[group_col] == group]

            # Primary Y-axis
            traces.append(go.Scatter(
                x=group_df[x_col],
                y=group_df[y1_col],
                mode='markers',
                name=f"{group} - {y1_col}",
                marker=dict(color=color_map[group]),
                legendgroup=group,
            ))

            # Secondary Y-axis (only if specified)
            if use_secondary_y:
                traces.append(go.Scatter(
                    x=group_df[x_col],
                    y=group_df[y2_col],
                    mode='markers',
                    name=f"{group} - {y2_col}",
                    marker=dict(color=color_map[group], symbol='circle-open'),
                    legendgroup=group,
                    yaxis='y2'
                ))
    else:
        
        # Primary Y-axis
        traces.append(go.Scatter(
            x=df[x_col],
            y=df[y1_col],
            mode='markers',
            marker=dict(
                color=df[group_col],                 # Continuous variable for color
                colorscale='Viridis',               # Any continuous colorscale: Viridis, Plasma, Cividis, etc.
                colorbar=dict(title=group_col),     # Colorbar legend
                showscale=True                      # Show the color scale
            ),
            name=f"{y1_col}",
            showlegend=False                       # Legend would be redundant with continuous colorbar
        ))

        # Secondary Y-axis (only if specified)
        if use_secondary_y:
            traces.append(go.Scatter(
                x=df[x_col],
                y=df[y2_col],
                mode='markers',
                marker=dict(
                    color=df[group_col],
                    colorscale='Viridis',
                    colorbar=dict(title=group_col),
                    showscale=False,               # Only one colorbar is needed
                    symbol='circle-open'
                ),
                name=f"{y2_col}",
                showlegend=False,
                yaxis='y2'
            ))

    # Layout
    layout = go.Layout(
            title='Scatter Plot',
            xaxis=dict(title=x_col),
            yaxis=dict(title=y1_col),
            legend=dict(title=group_col if group_col else "Legend"),
        )

    if x_col=="Wedge_Time":
        layout.xaxis=dict(
            title=x_col,
            type='date',   # <-- important
            tickformat='%Y-%m-%d'  # customize as you like
        )

    # Only add secondary y-axis if needed
    if use_secondary_y:
        layout.yaxis2 = dict(
            title=y2_col,
            overlaying='y',
            side='right'
        )

    fig = go.Figure(data=traces, layout=layout)

    fig.update_layout(margin=dict(t=40, b=40, l=40, r=40), autosize=True, template=plotly_theme)
    return fig

def _processplot(grade_data_process_clustered, ivariable_x_process, ivariable_y_process, ivariable_group_process, plotly_theme):
    import plotly.express as px

    gdpc=grade_data_process_clustered.copy()        
    if ivariable_group_process != "":
        if ivariable_group_process=="cluster":
            gdpc["cluster"]=gdpc["cluster"].astype(str)
            fig = px.scatter(
                gdpc, 
                x=ivariable_x_process, 
                y=ivariable_y_process, 
                color="cluster",
                color_discrete_sequence=px.colors.qualitative.Alphabet
            )
        else:    
                fig = px.scatter(
                gdpc, 
                x=ivariable_x_process, 
                y=ivariable_y_process, 
                color=ivariable_group_process
            )
    else:
        fig = px.scatter(
            gdpc, 
            x=ivariable_x_process, 
            y=ivariable_y_process
        )
    # Optional: set figure layout to auto-size
    fig.update_layout(margin=dict(t=40, b=40, l=40, r=40), autosize=True, template=plotly_theme)
    return fig

def describe_drilldown_row(row, decimals=2):
    import pandas as pd

    # --- grade text
    grade = row.get("AB_Grade_ID", None)
    grade_txt = "all considered grades" if str(grade).upper() == "ALL" else f"grade {grade}"
 
    # --- amount + direction
    pct = row.get("pct_cost", None)
    if pd.isna(pct):
        change_txt = "an unknown change"
        amount_txt = ""
    else:
        if pct > 0:
            change_txt = "an increase"
        elif pct < 0:
            change_txt = "a decrease"
        else:
            change_txt = "no change"
        amount_txt = f"{abs(pct):.{decimals}f}"
 
    # --- cost component (your example: TOTAL cost)
    component = row.get("cost", "TOTAL")
    component_txt = f"{component} cost"
 
    # --- resulting cost
    curr = row.get("current_cost", None)
    curr_txt = "an unknown value" if pd.isna(curr) else f"{curr:.{decimals}f}"
 
    # Optional extras if you want them
    prev = row.get("previous_cost", None)
    prev_part = "" if pd.isna(prev) else f" (previously {prev:.{decimals}f})"
 
    if pd.isna(pct):
        return f"For {grade_txt}, {component_txt} resulted in {curr_txt} €/t{prev_part}."
    if pct == 0:
        return f"For {grade_txt}, {component_txt} was unchanged at {curr_txt} €/t{prev_part}."
    return (
        f"For {grade_txt}, {component_txt} saw {change_txt} of {amount_txt} €/t, "
        f"resulting in {curr_txt} €/t."
    )

def build_drilldown_text(drilldown, mix_contribution=None, lang="en"):
    """
    Multiline Markdown-ready report text.

    Rules:
      - Normal case (no component breakdown):
          * print row-level grade descriptions
          * include 'Looking across...' summary for strongest grade increase/decrease (if applicable)
          * include ALL-only mix/process sentence (if mix_contribution provided)
      - Component breakdown case (and ONLY then):
          * ignore row-level grade descriptions entirely
          * ignore the 'Looking across...' grade summary entirely
          * report only the component breakdown analysis (excluding TOTAL / AVERAGE)
          * output order:
              1) Average change by component
              2) A more detailed breakdown... (largest avg increase/decrease + peak/trough grades)
          * still includes ALL-only mix/process sentence if applicable

    Units:
      - cost -> €/t
      - overprocessing -> %
    """
    import pandas as pd
    import re

    # ----------------------------
    # Language helpers
    # ----------------------------
    lang = (lang or "en").lower()

    def _t(en, de):
        return en if lang == "en" else de

    def _translate_row_text_de(text: str) -> str:
        """
        Conservative EN->DE phrase replacement for describe_drilldown_row() output.
        (No external translation service; only patterns we know.)
        """
        if not isinstance(text, str):
            text = str(text)

        # Ordered: longer/more specific first
        patterns = [
            # New items you reported
            (r"\bsaw a\b", "verzeichnete einen"),
            (r"\bresulting in\b", "was zu"),
            (r"\bresulting\b", "wodurch"),

            # "For ..." cases
            (r"\bFor all considered grades\b", "Für alle betrachteten Sorten"),
            (r"\bFor the considered grades\b", "Für die betrachteten Sorten"),
            (r"\bFor all grades\b", "Für alle Sorten"),
            (r"\bFor the grade\b", "Für die Sorte"),
            (r"\bFor grade\b", "Für Sorte"),
            (r"\bFor\b", "Für"),

            # Existing items
            (r"\bconsidered grades\b", "betrachtete Sorten"),
            (r"\bLooking across individual grades\b", "Über alle einzelnen Sorten betrachtet"),
            (r"\bLooking across grades\b", "Über alle Sorten betrachtet"),
            (r"\bindividual grades\b", "einzelne Sorten"),
            (
                r"\bThese movements stand out and may require further investigation\b",
                "Diese Bewegungen stechen hervor und sollten ggf. weiter untersucht werden",
            ),
            (
                r"\bmay require further investigation\b",
                "sollten ggf. weiter untersucht werden",
            ),
            (r"\bfurther investigation\b", "weitere Untersuchung"),

            # cost / overprocessing words
            (r"\boverprocessing\b", "Überverarbeitung"),
            (r"\bcost\b", "Kosten"),

            # common verbs/adjectives
            (r"\bwas observed for\b", "wurde beobachtet bei"),
            (r"\bwas driven by\b", "wurde verursacht durch"),
            (r"\bdriven by\b", "verursacht durch"),
            (r"\bdue to\b", "aufgrund von"),
            (r"\bexplained by\b", "erklärt durch"),
            (r"\bassociated with\b", "verbunden mit"),
            (r"\bstrongest\b", "stärkste"),
            (r"\bhigher\b", "höher"),
            (r"\blower\b", "niedriger"),
            (r"\bincrease\b", "Anstieg"),
            (r"\bdecrease\b", "Rückgang"),
            (r"\bimprovement\b", "Verbesserung"),
            (r"\bdeterioration\b", "Verschlechterung"),
            (r"\bmore expensive\b", "teurer"),
            (r"\bcheaper\b", "günstiger"),
            (r"\bunchanged\b", "unverändert"),
            (r"\bincreased\b", "gestiegen"),
            (r"\bdecreased\b", "gesunken"),

            # grade phrasing
            (r"\bgrades\b", "Sorten"),
            (r"\bgrade\b", "Sorte"),
        ]

        out = text
        for pat, sub in patterns:
            out = re.sub(pat, sub, out, flags=re.IGNORECASE)
        return out

    # ----------------------------
    # Detect metric + unit + component column
    # ----------------------------
    metric = "cost"
    if (
        "overprocessing" in drilldown.columns
        or drilldown.astype(str).apply(lambda s: s.str.lower().eq("overprocessing")).any().any()
    ):
        metric = "overprocessing"

    is_overprocessing = metric == "overprocessing"
    metric_noun_en = "overprocessing" if is_overprocessing else "cost"
    metric_noun_de = "Überverarbeitung" if is_overprocessing else "Kosten"
    metric_noun = _t(metric_noun_en, metric_noun_de)
    unit = "%" if is_overprocessing else "€/t"

    # Column that holds component names (TOTAL / AVERAGE / component labels)
    component_col = "overprocessing" if is_overprocessing else "cost"
    has_component_col = component_col in drilldown.columns

    # Breakdown detection:
    # - cost: any component != TOTAL
    # - overprocessing: any component != AVERAGE
    sub_components = ["chemicals","steam","electricity"]
    breakdown_flag_value = "AVERAGE" if is_overprocessing else "TOTAL"
    breakdown_exists = False
    if has_component_col:
        breakdown_exists = (
            ~drilldown[component_col].astype(str).str.upper().eq(breakdown_flag_value)
        ).any()

    sub_components_ = list(set(drilldown[component_col].astype(str).unique()).intersection(set(sub_components)))
    if len(sub_components_)>0:
        sub_component = sub_components_[0]
    else:
        sub_component = ""

    # ----------------------------
    # Formatting helpers
    # ----------------------------
    def _fmt_signed(x, decimals=2):
        x = float(x)
        sign = "+" if x > 0 else ""
        return f"{sign}{x:.{decimals}f} {unit}"

    def _fmt_abs(x, decimals=2):
        return f"{abs(float(x)):.{decimals}f} {unit}"

    def _cheaper_or_more_expensive(x):
        x = float(x)
        if x < 0:
            return _t(
                "lower" if is_overprocessing else "cheaper",
                "niedriger" if is_overprocessing else "günstiger",
            )
        if x > 0:
            return _t(
                "higher" if is_overprocessing else "more expensive",
                "höher" if is_overprocessing else "teurer",
            )
        return _t("unchanged", "unverändert")

    def _improvement_or_deterioration(x):
        x = float(x)
        if x < 0:
            return _t("an improvement in the process", "einer Verbesserung im Prozess")
        if x > 0:
            return _t("a deterioration in the process", "einer Verschlechterung im Prozess")
        return _t("no change in the process", "keiner Veränderung im Prozess")

    def _avg_direction_word(x):
        x = float(x)
        if x > 0:
            return _t("increased", "gestiegen")
        if x < 0:
            return _t("decreased", "gesunken")
        return _t("was unchanged", "unverändert geblieben")

    
    # ----------------------------
    # Detect ALL-only case (for mix/process line)
    # ----------------------------
    has_grade = "AB_Grade_ID" in drilldown.columns
    grades = drilldown["AB_Grade_ID"].astype(str).str.upper().unique().tolist() if has_grade else []
    all_only = has_grade and len(drilldown) == 1 and len(grades) == 1 and grades[0] == "ALL"

    extra_lines = []

    # Kept even in breakdown mode
    if all_only and mix_contribution is not None:
        mix, process = mix_contribution[0], mix_contribution[1]
        mix_dir = _cheaper_or_more_expensive(mix)
        proc_phrase = _improvement_or_deterioration(process)
        extra_lines.append(
            _t(
                f"Breaking down the overall {metric_noun_en} change, {_fmt_signed(mix)} was driven by a {mix_dir} mix of grades, "
                f"and {_fmt_signed(process)} was due to {proc_phrase}.",
                f"Bei der Aufschlüsselung der gesamten Veränderung der {metric_noun_de} ergibt sich, dass {_fmt_signed(mix)} durch eine {mix_dir} Sortenmischung verursacht wurden "
                f"und {_fmt_signed(process)} auf {proc_phrase} zurückzuführen sind."
            )
        )

    # ----------------------------
    # Component breakdown mode (ONLY when breakdown exists)
    # ----------------------------
    if breakdown_exists:
        required = {"pct_cost", "AB_Grade_ID", component_col}
        if not required.issubset(drilldown.columns):
            return "\n\n".join(extra_lines) if extra_lines else ""

        dd_comp = drilldown.copy()
        dd_comp[component_col] = dd_comp[component_col].astype(str)

        # Keep only component rows (exclude TOTAL/AVERAGE) and valid changes
        dd_comp = dd_comp[
            ~dd_comp[component_col].str.upper().eq(breakdown_flag_value)
        ].dropna(subset=["pct_cost"])

        if dd_comp.empty:
            return "\n\n".join(extra_lines) if extra_lines else ""


        # Average change per component
        avg_by_comp = dd_comp[(dd_comp.current_cost>0) & ~dd_comp[component_col].isin(sub_components)].groupby(component_col, as_index=False)["pct_cost"].mean()


        lines = []

        # 1) Average change by component
        if sub_component=="chemicals":
            lines.append(_t("Average change by chemicals:", "Durchschnittliche Veränderung je Chemikalie:"))
        elif sub_component=="steam":
            lines.append(_t("Average change by steam:", "Durchschnittliche Veränderung je Dampf:"))
        elif sub_component=="electricity":
            lines.append(_t("Average change by electricity:", "Durchschnittliche Veränderung je Strom:"))
        else:    
            lines.append(_t("Average change by component:", "Durchschnittliche Veränderung je Komponente:"))

        avg_sorted = avg_by_comp.copy()        
        avg_sorted["abs_avg"] = avg_sorted["pct_cost"].abs()
        avg_sorted = avg_sorted.sort_values(["abs_avg", component_col], ascending=[False, True])

        for _, r in avg_sorted.iterrows():
            comp = r[component_col]
            avgv = float(r["pct_cost"])
            lines.append(
                _t(
                    f"- **{comp}** {_avg_direction_word(avgv)} on average ({_fmt_signed(avgv)}).",
                    f"- **{comp}** ist im Durchschnitt {_avg_direction_word(avgv)} ({_fmt_signed(avgv)})."
                )
            )

        # 2) A more detailed breakdown...
        avg_inc = avg_by_comp[avg_by_comp["pct_cost"] > 0]
        avg_dec = avg_by_comp[avg_by_comp["pct_cost"] < 0]
        detail_parts = []

        if not avg_inc.empty:
            row = avg_inc.loc[avg_inc["pct_cost"].idxmax()]
            comp = row[component_col]
            peak_rows = dd_comp[dd_comp[component_col] == comp]
            peak = peak_rows.loc[peak_rows["pct_cost"].idxmax()]
            detail_parts.append(
                _t(
                    f"the largest average increase comes from **{comp}** ({_fmt_signed(row['pct_cost'])} on average), "
                    f"with the highest increase in grade {peak['AB_Grade_ID']} ({_fmt_signed(peak['pct_cost'])})",
                    f"die größte durchschnittliche Zunahme stammt von **{comp}** (im Mittel {_fmt_signed(row['pct_cost'])}), "
                    f"mit dem höchsten Anstieg in Sorte {peak['AB_Grade_ID']} ({_fmt_signed(peak['pct_cost'])})"
                )
            )

        if not avg_dec.empty:
            row = avg_dec.loc[avg_dec["pct_cost"].idxmin()] # most negative
            comp = row[component_col]
            trough_rows = dd_comp[dd_comp[component_col] == comp]
            trough = trough_rows.loc[trough_rows["pct_cost"].idxmin()]
            detail_parts.append(
                _t(
                    f"the largest average decrease comes from **{comp}** ({_fmt_signed(row['pct_cost'])} on average), "
                    f"with the biggest drop in grade {trough['AB_Grade_ID']} ({_fmt_signed(trough['pct_cost'])})",
                    f"die größte durchschnittliche Abnahme stammt von **{comp}** (im Mittel {_fmt_signed(row['pct_cost'])}), "
                    f"mit dem stärksten Rückgang in Sorte {trough['AB_Grade_ID']} ({_fmt_signed(trough['pct_cost'])})"
                )
            )

        if detail_parts:
            lines.append(
                _t(
                    "A more detailed breakdown by component shows that "
                    + " and ".join(detail_parts)
                    + ". These components stand out and may require further investigation.",
                    "Eine detailliertere Aufschlüsselung nach Komponenten zeigt, dass "
                    + " und ".join(detail_parts)
                    + ". Diese Komponenten stechen hervor und sollten ggf. weiter untersucht werden."
                )
            )

        return "\n\n".join(lines + extra_lines)

    # ----------------------------
    # Normal mode (no breakdown): row-level descriptions + 'Looking across...'
    # ----------------------------
    descriptions = drilldown.apply(describe_drilldown_row, axis=1).astype(str).tolist()

    # If overprocessing, adjust wording + units in row-level descriptions
    if is_overprocessing:
        descriptions = [
            re.sub(
                r"\bcost\b",
                _t("overprocessing", "Überverarbeitung"),
                d,
                flags=re.IGNORECASE
            ).replace("€/t", "%")
            for d in descriptions
        ]

    # Translate row-level descriptions if German is requested
    if lang == "de":
        descriptions = [_translate_row_text_de(d) for d in descriptions]

    # Multi-grade summary "Looking across..." (exclude ALL)
    dd_grades = drilldown.copy()
    if has_grade:
        dd_grades = dd_grades[dd_grades["AB_Grade_ID"].astype(str).str.upper() != "ALL"]

    if len(dd_grades) > 1 and {"pct_cost", "AB_Grade_ID"}.issubset(dd_grades.columns):
        dd_valid = dd_grades.dropna(subset=["pct_cost"])
        attention_parts = []

        if not dd_valid.empty:
            inc = dd_valid[dd_valid["pct_cost"] > 0]
            if not inc.empty:
                inc_row = inc.loc[inc["pct_cost"].idxmax()]
                attention_parts.append(
                    _t(
                        f"the strongest {metric_noun_en} increase was observed for grade {inc_row['AB_Grade_ID']} "
                        f"({_fmt_signed(inc_row['pct_cost'])})",
                        f"der stärkste {metric_noun_de}-Anstieg wurde für Sorte {inc_row['AB_Grade_ID']} beobachtet "
                        f"({_fmt_signed(inc_row['pct_cost'])})"
                    )
                )

            dec = dd_valid[dd_valid["pct_cost"] < 0]
            if not dec.empty:
                dec_row = dec.loc[dec["pct_cost"].idxmin()]
                attention_parts.append(
                    _t(
                        f"the strongest {metric_noun_en} decrease was observed for grade {dec_row['AB_Grade_ID']} "
                        f"({_fmt_signed(dec_row['pct_cost'])})",
                        f"der stärkste {metric_noun_de}-Rückgang wurde für Sorte {dec_row['AB_Grade_ID']} beobachtet "
                        f"({_fmt_signed(dec_row['pct_cost'])})"
                    )
                )

        if attention_parts:
            extra_lines.append(
                _t(
                    "Looking across individual grades, "
                    + " and ".join(attention_parts)
                    + ". These movements stand out and may require further investigation.",
                    "Über alle einzelnen Sorten betrachtet "
                    + " und ".join(attention_parts)
                    + ". Diese Bewegungen stechen hervor und sollten ggf. weiter untersucht werden."
                )
            )

    return "\n\n".join(descriptions + extra_lines)



def build_shapley_text(shapley_contrib, top_frac=0.20, lang="en"):
    """
    Build a human-readable, Markdown-ready summary of the main SHAP (Shapley) contributors.

    Parameters
    ----------
    shapley_contrib : pd.DataFrame
        Expected columns:
          - AB_Grade_ID
          - variable
          - contribution  (signed impact on predicted cost change, e.g. €/t)
          - value_change  (signed change in the feature value)
    top_frac : float
        Fraction of variables (per grade) to keep as "top contributors" by absolute contribution.
        Example: 0.20 keeps the top 20%.
    lang : {"en","de"}
        Output language. "en" keeps English. "de" outputs German.

    Returns
    -------
    str : multi-paragraph Markdown text (LaTeX-safe).
    """
    import pandas as pd
    import numpy as np
    import re

    lang = (lang or "en").lower()

    def _t(en, de):
        return en if lang == "en" else de

    df = shapley_contrib.copy()
    df = df[~df["variable"].astype(str).str.lower().eq("unknown")]

    required = {"AB_Grade_ID", "variable", "contribution", "value_change"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"shapley_contrib is missing required columns: {sorted(missing)}")

    # Clean + types
    df["variable"] = df["variable"].astype(str)
    df["contribution"] = pd.to_numeric(df["contribution"], errors="coerce")
    df["value_change"] = pd.to_numeric(df["value_change"], errors="coerce")
    df = df.dropna(subset=["contribution", "value_change"])

    if df.empty:
        return _t(
            "No SHAP contribution data available to summarise.",
            "Keine SHAP-Beitragsdaten zur Zusammenfassung verfügbar."
        )

    df["abs_contribution"] = df["contribution"].abs()

    def _pretty_var(name: str) -> str:
        # Make variable names more readable, without adding units.
        # Examples: "Starch_uptake__g/m2_" -> "Starch uptake"
        s = name
        s = s.replace("__", " ")
        s = s.replace("_", " ")
        s = re.sub(r"\s+", " ", s).strip()
        if name.lower() == name or "_" in name:
            s = s[:1].upper() + s[1:]
        return s

    def _fmt_signed(x, decimals=2):
        x = float(x)
        sign = "+" if x > 0 else ""
        return f"{sign}{x:.{decimals}f}"

    def _fmt_abs(x, decimals=2):
        return f"{abs(float(x)):.{decimals}f}"

    def _direction_word(x):
        x = float(x)
        if x > 0:
            return _t("increased", "gestiegen")
        if x < 0:
            return _t("decreased", "gesunken")
        return _t("was unchanged", "unverändert geblieben")

    # Build text per grade
    out_lines = []
    for grade, g in df.groupby("AB_Grade_ID", sort=False):
        g = g.sort_values("abs_contribution", ascending=False).copy()
        n = len(g)
        k = max(1, int(np.ceil(n * float(top_frac))))
        top = g.head(k).copy()

        inc = top[top["contribution"] > 0].copy()
        dec = top[top["contribution"] < 0].copy()

        header = _t(
            f"For grade {grade}, the cost change is mainly explained by the following factors (top {int(top_frac*100)}% by contribution):",
            f"Für Sorte {grade} wird die Kostenänderung hauptsächlich durch die folgenden Faktoren erklärt (Top {int(top_frac*100)}% nach Beitrag):"
        )
        out_lines.append(header)

        if not dec.empty:
            out_lines.append(_t("**Cost-reducing drivers**:", "**Kostensenkende Treiber**:"))
            for _, r in dec.iterrows():
                var = _pretty_var(r["variable"])
                out_lines.append(
                    f"- {var} {_direction_word(r['value_change'])} ({_fmt_signed(r['value_change'])})"
                    # f", which contributed to a reduction in cost of {_fmt_abs(r['contribution'])}."
                )

        if not inc.empty:
            out_lines.append(_t("**Cost-increasing drivers**:", "**Kostentreibende Faktoren**:"))
            for _, r in inc.iterrows():
                var = _pretty_var(r["variable"])
                out_lines.append(
                    f"- {var} {_direction_word(r['value_change'])} ({_fmt_signed(r['value_change'])})"
                    # f", which contributed to an increase in cost of {_fmt_abs(r['contribution'])}."
                )

        if inc.empty and dec.empty:
            out_lines.append(
                _t(
                    "No meaningful drivers were identified (all contributions were near zero).",
                    "Es wurden keine aussagekräftigen Treiber identifiziert (alle Beiträge lagen nahe bei null)."
                )
            )

        out_lines.append("")

    return "\n".join(out_lines).strip()
    




class GermanyTempService:
    def __init__(self, latitude=51.1657, longitude=10.4515, timezone="Europe/Berlin"):
        self.lat = latitude
        self.lon = longitude
        self.tz = timezone
        self.cache = {}   # {date -> pd.Series(hourly temps)}
 
    def _fetch_day(self, day):
        from datetime import timedelta
        import requests

        today = pd.Timestamp.now(tz=self.tz).date()
        use_archive = day < (today - timedelta(days=14))
 
        base_url = (
            "https://archive-api.open-meteo.com/v1/archive"
            if use_archive
            else "https://api.open-meteo.com/v1/forecast"
        )
 
        params = {
            "latitude": self.lat,
            "longitude": self.lon,
            "hourly": "temperature_2m",
            "start_date": day.isoformat(),
            "end_date": day.isoformat(),
            "timezone": self.tz,
        }
 
        r = requests.get(base_url, params=params, timeout=30)
        r.raise_for_status()
        data = r.json()
 
        idx = pd.to_datetime(data["hourly"]["time"])
        temps = pd.Series(data["hourly"]["temperature_2m"], index=idx)
        return temps
 
    def get(self, dt):
        ts = pd.Timestamp(dt)
        if ts.tzinfo is not None:
            ts = ts.tz_convert(self.tz).tz_localize(None)
 
        day = ts.date()
 
        if day not in self.cache:
            self.cache[day] = self._fetch_day(day)
 
        series = self.cache[day]
        pos = series.index.get_indexer([ts], method="nearest")[0]
        return float(series.iloc[pos])
    
def add_germany_temperature_column(
    df: pd.DataFrame,
    datetime_col: str,
    out_col: str = "ambient_temp_C",
    inplace: bool = False,
) -> pd.DataFrame | None:
    """
    Add a Germany ambient temperature column based on timestamps.
 
    If inplace=False (default): returns a modified copy.
    If inplace=True: modifies df in place and returns None.
    """
    service = GermanyTempService()
 
    if not inplace:
        df = df.copy()
 
    ts = pd.to_datetime(df[datetime_col])
 
    # Only query unique timestamps (huge speed-up)
    unique_ts = ts.unique()
    lookup = {t: service.get(t) for t in unique_ts}
 
    df[out_col] = ts.map(lookup)
 
    if not inplace:
        return df
    return None

def _lab_data(local, bucket, fs):
    if local:
        return pd.read_parquet(f"./data/optvsn_df.parquet",engine="fastparquet")
    else:
        return pd.read_parquet(f"s3://{bucket}/turnup/optvsn_df.parquet")


class FeatureCreator(BaseEstimator, TransformerMixin):
    def __init__(self, features_to_create=None, features_to_keep=None, errors="raise", copy=False):
        self.features_to_create = features_to_create
        self.features_to_keep = features_to_keep
        self.errors = errors
        self.copy = copy

    def fit(self, X, y=None):
        # feature_names_in_ = the RAW inputs this transformer consumes:
        #   the kept-as-is columns that are NOT engineered here, plus the raw inputs
        #   required to build the engineered (created) features. Handles None for either
        #   list. Falls back to the fitted columns if nothing is declared.
        keep = list(self.features_to_keep) if self.features_to_keep is not None else []
        create = list(self.features_to_create) if self.features_to_create is not None else []
        raw_kept = [f for f in keep if f not in create]
        input_features = list(dict.fromkeys(raw_kept + self.features_required()))
        if input_features:
            self.feature_names_in_ = np.asarray(input_features, dtype=object)
        elif hasattr(X, "columns"):
            self.feature_names_in_ = np.asarray(X.columns, dtype=object)
        return self

    def transform(self, X):
        if not hasattr(self, "feature_names_in_"):
            self.fit(X)

        X_df = self._to_dataframe(X)

        
        #if self.copy:
        X_df = X_df.copy()

        registry = self._registry()
        requested = (
            list(registry.keys())
            if self.features_to_create is None
            else list(self.features_to_create)
        )

        # Add dependencies in correct order.
        to_make = self._expand_with_deps(requested)

        # Do not recompute engineered columns already present.
        for name in to_make:
            if name in X_df.columns:
                continue

            fn = registry.get(name)
            if fn is None:
                msg = f"Unknown engineered feature '{name}'. Available: {sorted(registry.keys())}"
                if self.errors == "raise":
                    raise ValueError(msg)
                continue

            try:
                fn(X_df) # in-place
            except Exception:
                if self.errors == "raise":
                    raise

        self.created_features_ = [c for c in to_make if c in X_df.columns]

        if self.features_to_keep is None:
            return X_df

        missing = [c for c in self.features_to_keep if c not in X_df.columns]
        if missing and self.errors == "raise":
            raise ValueError(f"Missing required output columns: {missing}")

        keep = [c for c in self.features_to_keep if c in X_df.columns]
        return X_df.loc[:, keep]

    def get_feature_names_out(self, input_features=None):
        if self.features_to_keep is None:
            if getattr(self, "feature_names_in_", None) is not None:
                return np.asarray(self.feature_names_in_, dtype=object)
            return np.asarray([], dtype=object)
        return np.asarray(self.features_to_keep, dtype=object)

    def features_required(self):
        required = []

        for v in self.features_to_create or []:
            required.extend(self._feature_raw_inputs().get(v, []))

        return sorted(set(required))

    def _to_dataframe(self, X):
        if isinstance(X, pd.DataFrame):
            return X

        if getattr(self, "feature_names_in_", None) is None:
            raise ValueError(
                "FeatureCreator received a numpy array without known column names. "
                "Pass a pandas DataFrame into the pipeline or fit with a DataFrame first."
            )

        return pd.DataFrame(X, columns=list(self.feature_names_in_))

    @classmethod
    def _deps(cls):
        return {
            "Fibre__g/m2_": ["Starch_uptake__g/m2_"],
            "Water_flow": ["Water_flow_Predryer", "Water_flow_Afterdryer"],            
        }

    @classmethod
    def _feature_raw_inputs(cls):
        return {
            "delta_basis_weight": [
                "Current_basis_weight",
                "grammage"
            ],
            "Fibre__g/m2_": [
                "Current_basis_weight",
                "Current_reel_moisture_average(reel)",
                "Starch_uptake_by_paper_Top_Roll__g/m2_",
                "Starch_uptake_by_paper_Bottom_Roll__g/m2_",
            ],
            "Starch_uptake__g/m2_": [
                "Starch_uptake_by_paper_Top_Roll__g/m2_",
                "Starch_uptake_by_paper_Bottom_Roll__g/m2_",
                
            ],
            # "Water_flow_Predryer": [
            #     "grammage",
            #     "Speed",
            #     "Current_reel_width",
            #     "Moisture_out_of_PreDryer",
            # ],
            "Water_flow_Predryer": [
                "grammage",                
                #"Speed",
                #"Current_reel_width",
                "Current_reel_moisture_average(reel)",
                "Moisture_out_of_PreDryer",
                "Starch_uptake_by_paper_Top_Roll__g/m2_",
                "Starch_uptake_by_paper_Bottom_Roll__g/m2_",
            ],
            "Water_Predryer": [
                "grammage",                
                "Current_reel_moisture_average(reel)",
                "Moisture_out_of_PreDryer",
                "Starch_uptake_by_paper_Top_Roll__g/m2_",
                "Starch_uptake_by_paper_Bottom_Roll__g/m2_",
            ],
            "Water_flow_Afterdryer": [
                "grammage",
                "Speed",
                "Current_reel_width",
                "Moisture_after_SpeedSizer",
                "Current_reel_moisture_average(reel)",
                "Starch_uptake_by_paper_Top_Roll__g/m2_",
                "Starch_uptake_by_paper_Bottom_Roll__g/m2_",
            ],
            "Water_flow": [
                "grammage",
                "Speed",
                "Current_reel_width",
                "Moisture_out_of_PreDryer",
                "Moisture_after_SpeedSizer",
                "Actual_moisture",
            ],            
            "diluted_starch": [
                "grammage",
                "Speed",
                "Current_reel_width",
                "concentration_starch_working_tank_2",
                "concentration_starch_working_tank_1",
                "Starch_uptake_by_paper_Bottom_Roll__g/m2_",
                "Starch_uptake_by_paper_Top_Roll__g/m2_",
            ],
            "flow_diluted_starch_index": [
                "Flow_starch_main_line_to_working_tank_2~^0",
                "concentration_starch_working_tank_2",
                "Flow_starch_main_line_to_working_tank_1~^0",
                "concentration_starch_working_tank_1",
                "Production_Rate__T/h_",
            ],
            "Water_flow_Afterdryer_input": [
                "grammage",
                "Speed",
                "Current_reel_width",
                "concentration_starch_working_tank_2",
                "concentration_starch_working_tank_1",
                "Starch_uptake_by_paper_Bottom_Roll__g/m2_",
                "Starch_uptake_by_paper_Top_Roll__g/m2_",
            ],
            "Water_flow_Afterdryer_output": [
                "grammage",
                "Speed",
                "Current_reel_width",
                "Starch_uptake_by_paper_Bottom_Roll__g/m2_",
                "Starch_uptake_by_paper_Top_Roll__g/m2_",
                "Current_reel_moisture_average(reel)",
                "Moisture_out_of_PreDryer",
            ],
            "Water_Afterdryer_output": [
                "grammage",
                "Starch_uptake_by_paper_Bottom_Roll__g/m2_",
                "Starch_uptake_by_paper_Top_Roll__g/m2_",
                "Current_reel_moisture_average(reel)",
                "Moisture_out_of_PreDryer",
            ],
            "inv_Production_Rate__T/h_": [
                "grammage",
                "Speed",
                "Current_reel_width",
            ],
            "Production_Rate__T/h_": [
                "Current_basis_weight",
                "Speed",
                "Current_reel_width",
            ],
            "inv_Rod_Pressure_Bottom_Roll": ["Rod_Pressure_Bottom_Roll"],
            "inv_Rod_pressure_Top_Roll": ["Rod_pressure_Top_Roll"],
            "square_Rod_Pressure_Bottom_Roll": ["Rod_Pressure_Bottom_Roll"],
            "square_Rod_pressure_Top_Roll": ["Rod_pressure_Top_Roll"],
            "dewatering": [
                "Dewatering_Shoe_press",
                "Dewatering_Suction_Press_Roll",
                "Dewatering_top_wire_suction_box_zone_2",
                "Total_Dewatering_Press",
                "Dewatering_First_Press_Roll",
                "Uhle_box_1_flow___l/min_",
                "Uhle_box_2_flow___l/min_"
            ],
            "fibre_short/long": [
                "Short_fibre_flow",
                "Short_fibre_B06_consistency",
                "Long_fibre_flow",
                "Long_fibre_consistency_B07",
            ],
            "temperature_starch_working_tank": [
                "Temperature_starch_working_tank_1",
                "Temperature_starch_working_tank_2"
            ],
            "retention": [
                "Consistency_white_water",
                "Headbox_consistency"
            ],
        }

    def _expand_with_deps(self, requested):
        deps = self._deps()
        seen = set()
        order = []

        def visit(f):
            if f in seen:
                return
            seen.add(f)
            for d in deps.get(f, []):
                visit(d)
            order.append(f)

        for f in requested:
            visit(f)

        return order

    @staticmethod
    def _safe_inverse(series, eps=1e-9):
        s = pd.to_numeric(series, errors="coerce")
        s = s.where(s.abs() > eps, np.nan)
        return 1.0 / s

    @staticmethod
    def _add_delta_basis_weight(df):
        df["delta_basis_weight"] = (
            df["Current_basis_weight"] - df["grammage"]
        )

    @staticmethod
    def _add_starch_uptake(df):
        df["Starch_uptake__g/m2_"] = (
            df["Starch_uptake_by_paper_Top_Roll__g/m2_"]
            + df["Starch_uptake_by_paper_Bottom_Roll__g/m2_"]
        )


    @staticmethod
    def _add_fibre(df):
        df["Fibre__g/m2_"] = (
            df["Current_basis_weight"]
            * (1 - df["Current_reel_moisture_average(reel)"] / 100)
            - df["Starch_uptake__g/m2_"]
        )

    @staticmethod
    def _add_temperature_starch_working_tank(df):
        df["temperature_starch_working_tank"] = (
            df["Temperature_starch_working_tank_1"] + df["Temperature_starch_working_tank_2"]
        )/2

    # @staticmethod
    # def _add_water_flow_predryer(df):
    #     df["Water_flow_Predryer"] = (
    #         df["grammage"]
    #         * df["Speed"]
    #         * df["Current_reel_width"]
    #         * (100 - 53 - df["Moisture_out_of_PreDryer"])
    #         * 60
    #         / 1e10
    #     )
    
    @staticmethod
    def _add_water_predryer(df):
        prod = 1 #df["Speed"]*df["grammage"]*df["Current_reel_width"]*60/1e8
        starch_uptake = df["Starch_uptake_by_paper_Top_Roll__g/m2_"] + df["Starch_uptake_by_paper_Bottom_Roll__g/m2_"]
        moist_press = 50

        df["Water_Predryer"] = prod * (1 -  df["Current_reel_moisture_average(reel)"] / 100 - starch_uptake/df["grammage"]) * moist_press/(100-moist_press) * (1 - df["Moisture_out_of_PreDryer"]*(100-moist_press)/moist_press/(100 - df["Moisture_out_of_PreDryer"]))

    @staticmethod
    def _add_water_flow_predryer(df):
        prod = df["Speed"]*df["grammage"]*df["Current_reel_width"]*60/1e8
        starch_uptake = df["Starch_uptake_by_paper_Top_Roll__g/m2_"] + df["Starch_uptake_by_paper_Bottom_Roll__g/m2_"]
        moist_press = 50

        df["Water_flow_Predryer"] = prod * (1 -  df["Current_reel_moisture_average(reel)"] / 100 - starch_uptake/df["grammage"]) * moist_press/(100-moist_press) * (1 - df["Moisture_out_of_PreDryer"]*(100-moist_press)/moist_press/(100 - df["Moisture_out_of_PreDryer"]))

    @staticmethod
    def _add_water_flow_afterdryer(df):
        prod = df["Speed"] * df["grammage"] * df["Current_reel_width"] * 60 / 1e8
        starch_uptake = df["Starch_uptake_by_paper_Top_Roll__g/m2_"] + df["Starch_uptake_by_paper_Bottom_Roll__g/m2_"]
        fibre_fraction = 1 - df["Actual_moisture"] / 100 - starch_uptake / df["grammage"]

        M_in = df["Moisture_after_SpeedSizer"]
        M_out = df["Current_reel_moisture_average(reel)"]

        df["Water_flow_Afterdryer"] = prod * fibre_fraction * (
            M_in / (100 - M_in) - M_out / (100 - M_out)
        )

    @staticmethod
    def _add_water_flow(df):
        df["Water_flow"] = df["Water_flow_Predryer"] + df["Water_flow_Afterdryer"]

    @staticmethod
    def _add_diluted_starch(df):
        prod = 1 #df["Speed"]*df["grammage"]*df["Current_reel_width"]*60/1e8

        df["diluted_starch"] = prod * (
            df["Starch_uptake_by_paper_Top_Roll__g/m2_"] * (1 - df["concentration_starch_working_tank_2"])
            / df["concentration_starch_working_tank_2"]
            + df["Starch_uptake_by_paper_Bottom_Roll__g/m2_"] * (1 - df["concentration_starch_working_tank_1"])
            / df["concentration_starch_working_tank_1"]
        )

    @staticmethod
    def _add_flow_diluted_starch_index(df):
        df["flow_diluted_starch_index"] = (
            (
                df["Flow_starch_main_line_to_working_tank_2~^0"]
                / df["concentration_starch_working_tank_2"]
                + df["Flow_starch_main_line_to_working_tank_1~^0"]
                / df["concentration_starch_working_tank_1"]
            )
            / df["Production_Rate__T/h_"]
        )

    @staticmethod
    def _add_water_flow_afterdryer_input(df):
        prod = df["Speed"]*df["grammage"]*df["Current_reel_width"]*60/1e8

        df["Water_flow_Afterdryer_input"] = prod * (
            df["Starch_uptake_by_paper_Top_Roll__g/m2_"] * (100 - df["concentration_starch_working_tank_2"])
            / df["concentration_starch_working_tank_2"]
            + df["Starch_uptake_by_paper_Bottom_Roll__g/m2_"] * (100 - df["concentration_starch_working_tank_1"])
            / df["concentration_starch_working_tank_1"]
        )

    @staticmethod
    def _add_water_afterdryer_output(df):
        starch_uptake = (
            df["Starch_uptake_by_paper_Top_Roll__g/m2_"]
            + df["Starch_uptake_by_paper_Bottom_Roll__g/m2_"]
        )
        # Dry fibre fraction (same as pre-dryer formula)
        fibre_fraction = 1 - df["Current_reel_moisture_average(reel)"] / 100 - starch_uptake / df["grammage"]

        # Moisture entering the after-dryer = moisture leaving the pre-dryer
        M_in = df["Moisture_out_of_PreDryer"]
        # Moisture leaving the after-dryer = final reel moisture
        M_out = df["Current_reel_moisture_average(reel)"]

        # Water evaporated = dry_mass * [M_in/(100-M_in) - M_out/(100-M_out)]
        # Using fibre_fraction as proxy for dry mass per unit of grammage
        df["Water_Afterdryer_output"] = fibre_fraction * (
            M_in / (100 - M_in) - M_out / (100 - M_out)
        )    

    @staticmethod
    def _add_water_flow_afterdryer_output(df):
        prod = df["Speed"]*df["grammage"]*df["Current_reel_width"]*60/1e8
        starch_uptake = df["Starch_uptake_by_paper_Top_Roll__g/m2_"] + df["Starch_uptake_by_paper_Bottom_Roll__g/m2_"]

        df["Water_flow_Afterdryer_output"] = prod * ((1 -  df["Current_reel_moisture_average(reel)"] / 100 - starch_uptake/df["grammage"]) * df["Moisture_out_of_PreDryer"]/(100-df["Moisture_out_of_PreDryer"]) - df["Current_reel_moisture_average(reel)"] / 100)

    @staticmethod
    def _add_inv_production_rate(df):
        prod = df["Speed"]*df["grammage"]*df["Current_reel_width"]*60/1e8
        df["inv_Production_Rate__T/h_"] = 1/prod

    @staticmethod
    def _add_production_rate(df):
        prod = df["Speed"]*df["Current_basis_weight"]*df["Current_reel_width"]*60/1e8
        df["Production_Rate__T/h_"] = prod

    @staticmethod
    def _add_inv_rod_pressure_bottom_roll(df):
        df["inv_Rod_Pressure_Bottom_Roll"] = FeatureCreator._safe_inverse(
            df["Rod_Pressure_Bottom_Roll"]
        )

    @staticmethod
    def _add_inv_rod_pressure_top_roll(df):
        df["inv_Rod_pressure_Top_Roll"] = FeatureCreator._safe_inverse(
            df["Rod_pressure_Top_Roll"]
        )

    @staticmethod
    def _add_square_rod_pressure_bottom_roll(df):
        df["square_Rod_Pressure_Bottom_Roll"] = pd.to_numeric(
            df["Rod_Pressure_Bottom_Roll"], errors="coerce"
        ) ** 2

    @staticmethod
    def _add_square_rod_pressure_top_roll(df):
        df["square_Rod_pressure_Top_Roll"] = pd.to_numeric(
            df["Rod_pressure_Top_Roll"], errors="coerce"
        ) ** 2

    @staticmethod
    def _add_dewatering(df):
        cols = [
            "Dewatering_Shoe_press",
            "Dewatering_Suction_Press_Roll",
            "Dewatering_top_wire_suction_box_zone_2",
            "Total_Dewatering_Press",
            "Dewatering_First_Press_Roll",
            "Uhle_box_1_flow___l/min_",
            "Uhle_box_2_flow___l/min_"
        ]
        df["dewatering"] = df[cols].sum(axis=1)

    @staticmethod
    def _add_fibre_short_long_ratio(df):        
        df["fibre_short/long"] = df['Short_fibre_flow']*df['Short_fibre_B06_consistency']/(df['Long_fibre_flow']*df['Long_fibre_consistency_B07'])

    @staticmethod
    def _add_retention(df):        
        df["retention"] = 1 - df['Consistency_white_water'] / (10 * df['Headbox_consistency'])

    @classmethod
    def _registry(cls):
        return {
            "Starch_uptake__g/m2_": cls._add_starch_uptake,
            "Fibre__g/m2_": cls._add_fibre,
            "Water_flow_Predryer": cls._add_water_flow_predryer,
            "Water_Predryer": cls._add_water_predryer,
            "Water_flow_Afterdryer": cls._add_water_flow_afterdryer,
            "Water_flow": cls._add_water_flow,            
            "diluted_starch": cls._add_diluted_starch,
            "flow_diluted_starch_index": cls._add_flow_diluted_starch_index,
            "Water_flow_Afterdryer_input": cls._add_water_flow_afterdryer_input,
            "Water_flow_Afterdryer_output": cls._add_water_flow_afterdryer_output,
            "Water_Afterdryer_output": cls._add_water_afterdryer_output,
            "inv_Production_Rate__T/h_": cls._add_inv_production_rate,
            "Production_Rate__T/h_": cls._add_production_rate,
            "inv_Rod_Pressure_Bottom_Roll": cls._add_inv_rod_pressure_bottom_roll,
            "inv_Rod_pressure_Top_Roll": cls._add_inv_rod_pressure_top_roll,
            "square_Rod_Pressure_Bottom_Roll": cls._add_square_rod_pressure_bottom_roll,
            "square_Rod_pressure_Top_Roll": cls._add_square_rod_pressure_top_roll,
            "dewatering": cls._add_dewatering,
            "fibre_short/long": cls._add_fibre_short_long_ratio,
            "delta_basis_weight": cls._add_delta_basis_weight,
            "temperature_starch_working_tank": cls._add_temperature_starch_working_tank,
            "retention": cls._add_retention,
        }
    


class SKColumnSelector(BaseEstimator, TransformerMixin):
    def __init__(self, columns):
        self.columns = columns

    def fit(self, X, y=None):
        self.feature_names_in_ = list(X.columns)
        self.n_features_in_ = X.shape[1]
        self.columns_ = list(self.columns) # fitted attribute
        return self

    def transform(self, X):
        return X[self.columns_]
    
class ColumnSelector(BaseEstimator, TransformerMixin):
    def __init__(self, columns):
        self.columns = columns

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X.loc[:, self.columns]

    def get_feature_names_out(self, input_features=None):
        return np.asarray(self.columns, dtype=object)
    


def calculate_manual_shap(model, X_sample, grade_id=None, X_reference=None, grade_col=None):
    """
    SHAP (using shap library) for NON-linear pipelines, computed per grade to avoid grade-mix bias.
 
    Parameters (kept compatible with your old signature style)
    ----------------------------------------------------------
    model : fitted estimator or pipeline with .predict
    X_sample : pd.DataFrame
        Raw samples to explain (may contain multiple grades)
    grade_id : optional
        If provided, compute SHAP only for that grade (subset of X_sample).
        If None, compute SHAP for each grade found in X_sample and return a dict.
    X_reference : required
        Used as SHAP background data.
        - Recommended: pass your training dataframe (raw space) as X_reference
        - Advanced: pass dict {grade_value: background_df} to control background per grade
    grade_col : required
        Column identifying grade in both X_sample and X_reference (if X_reference is a df)
 
    Returns
    -------
    If grade_id is not None:
        base_values, shap_values, Xe, feature_names
    If grade_id is None:
        dict {grade_value: (base_values, shap_values, Xe, feature_names)}
    """
    import numpy as np
    import pandas as pd
    import shap
 
    if X_reference is None:
        raise ValueError(
            "X_reference is required and must be the training dataframe (raw) "
            "or a dict {grade: background_df}."
        )
    if grade_col is None:
        raise ValueError("grade_col is required (e.g. 'AB_Grade_ID').")
 
    def _is_df(x):
        return isinstance(x, pd.DataFrame)
 
    # -------- background getter --------
    if _is_df(X_reference):
        X_train = X_reference
        if grade_col not in X_train.columns:
            raise KeyError(f"Training df (X_reference) must include '{grade_col}' for per-grade background.")
 
        def get_background(g):
            # robust matching (handles int/float/str mixes)
            return X_train[X_train[grade_col].astype(str) == str(g)]
 
    elif isinstance(X_reference, dict):
 
        def get_background(g):
            bg = X_reference.get(g)
            if bg is None:
                bg = X_reference.get(str(g))
            return bg
 
    else:
        raise TypeError("X_reference must be a pandas DataFrame (training df) or a dict {grade: background_df}.")
 
    # feature columns = all except grade col
    feature_names = [c for c in X_sample.columns if c != grade_col]
 
    # internal sampling knobs
    background_size = 200
    explain_size = 200
    min_bg = 30
 
    def compute_for_grade(g):
        Xg = X_sample[X_sample[grade_col] == g]
        if Xg.empty:
            return None
 
        bg = get_background(g)
        if bg is None or len(bg) < min_bg:
            # fallback: use all training (if df) or current grade slice (if dict missing)
            bg = X_reference if _is_df(X_reference) else Xg
 
        Xb = bg[feature_names].copy()
        Xe = Xg[feature_names].copy()

        for c in feature_names:
            if pd.api.types.is_numeric_dtype(Xb[c]):
                Xb[c] = pd.to_numeric(Xb[c], errors="coerce").fillna(0.0)
                Xe[c] = pd.to_numeric(Xe[c], errors="coerce").fillna(0.0)

        # Wrap model to inject grade_col (pipeline may need it, but SHAP shouldn't attribute to it)
        all_model_cols = list(X_sample.columns)
        original_index = Xe.index  # preserve DatetimeIndex for EWM

        def _predict_for_shap(X_feat):
            if isinstance(X_feat, pd.DataFrame):
                X_full = X_feat.copy()
            else:
                X_full = pd.DataFrame(X_feat, columns=feature_names)
            if grade_col not in X_full.columns:
                X_full[grade_col] = g
            # Restore DatetimeIndex (SHAP may strip it)
            if not isinstance(X_full.index, pd.DatetimeIndex):
                if len(X_full) == len(original_index):
                    X_full.index = original_index
                else:
                    # Background data — use a synthetic datetime index
                    X_full.index = pd.date_range("2025-01-01", periods=len(X_full), freq="h")
            return model.predict(X_full[all_model_cols])

        explainer = shap.Explainer(_predict_for_shap, Xb)
        sv = explainer(Xe)
 
        shap_values = np.asarray(sv.values, dtype=float)
        base_values = sv.base_values  # scalar or (n_samples,)
 
        return base_values, shap_values, Xe, feature_names
 
    # -------- single grade --------
    if grade_id is not None:
        out = compute_for_grade(grade_id)
        if out is None:
            raise ValueError(f"No rows found in X_sample for grade_id={grade_id}")
        return out
 
    # -------- all grades in X_sample --------
    grades = sorted(X_sample[grade_col].dropna().astype(str).unique().tolist())

    base_values_all = []
    shap_values_all = []
    Xe_all = []
    feature_names_ref = None

    for g in grades:
        out = compute_for_grade(g)
        if out is None:
            continue

        base_values_g, shap_values_g, Xe_g, feature_names_g = out

        if feature_names_ref is None:
            feature_names_ref = list(feature_names_g)
        else:
            if list(feature_names_g) != feature_names_ref:
                raise ValueError(
                    f"Inconsistent feature_names across grades. "
                    f"Expected {feature_names_ref}, got {list(feature_names_g)} for grade {g}."
                )

        base_values_all.append(np.asarray(base_values_g))
        shap_values_all.append(np.asarray(shap_values_g))
        Xe_all.append(Xe_g.copy())

    if not Xe_all:
        raise ValueError("No valid rows found in X_sample across any grade")

    base_values = np.concatenate(base_values_all, axis=0)
    shap_values = np.vstack(shap_values_all)
    Xe = pd.concat(Xe_all, axis=0).reset_index(drop=True)
    feature_names = feature_names_ref

    return base_values, shap_values, Xe, feature_names

def plotly_shap_beeswarm(
    shap_values,
    X_feat: pd.DataFrame,
    feature_names=None,
    max_features=15,
):
    """
    Plot SHAP summary beeswarm similar to the historical analysis tab.
 
    Parameters
    ----------
    shap_values : array (n_samples, n_features)
    X_feat : DataFrame with feature values
    feature_names : optional list of feature names
    max_features : maximum rows to display (including "Sum of other features")
    """
    import numpy as np
    import pandas as pd
    import plotly.graph_objects as go

    shap_values = np.asarray(shap_values)
 
    if shap_values.ndim == 1:
        shap_values = shap_values.reshape(-1, 1)
 
    if feature_names is None:
        feature_names = list(X_feat.columns)
 
    X_feat = X_feat[feature_names]
 
    n_samples, n_features = shap_values.shape
 
    # -------- Feature ranking --------
    mean_abs_shap = np.abs(shap_values).mean(axis=0)
 
    max_display = min(max_features, n_features)
 
    # top features (excluding merged row)
    top_idx = np.argsort(mean_abs_shap)[-(max_display - 1):]
 
    other_idx = np.setdiff1d(np.arange(n_features), top_idx)
 
    labels = [f"Sum of {len(other_idx)} other features"] + [feature_names[i] for i in top_idx]
 
    fig = go.Figure()
 
    separation = 1.3
    rng = np.random.default_rng(42)
 
    # -------- SUM OF OTHER FEATURES --------
    if len(other_idx) > 0:
 
        shap_sum = shap_values[:, other_idx].sum(axis=1)
 
        feat_sum = X_feat.iloc[:, other_idx].mean(axis=1).values
 
        jitter = rng.normal(0, 0.2, len(shap_sum))
 
        fig.add_trace(
            go.Scattergl(
                x=shap_sum,
                y=jitter,
                mode="markers",
                customdata=feat_sum,
                marker=dict(
                    size=5,
                    opacity=0.6,
                    color=feat_sum,
                    colorscale="Bluered",
                    showscale=True,
                    colorbar=dict(title="Value", showticklabels=False),
                ),
                hovertemplate="<b>Sum of other features</b><br>"
                              "SHAP: %{x:.3f}<br>"
                              "Value: %{customdata:.3f}<extra></extra>",
                showlegend=False,
            )
        )
 
    # -------- TOP FEATURES --------
    row = 1
 
    for i in top_idx:
 
        shap_val = shap_values[:, i]
        feat_val = X_feat.iloc[:, i]
 
        jitter = rng.normal(row * separation, 0.2, len(shap_val))
 
        fig.add_trace(
            go.Scattergl(
                x=shap_val,
                y=jitter,
                mode="markers",
                customdata=feat_val,
                marker=dict(
                    size=5,
                    opacity=0.6,
                    color=feat_val,
                    colorscale="Bluered",
                    showscale=False,
                ),
                hovertemplate=f"<b>{feature_names[i]}</b><br>"
                              "SHAP: %{x:.3f}<br>"
                              "Value: %{customdata:.3f}<extra></extra>",
                showlegend=False,
            )
        )
 
        row += 1
 
    # -------- Layout --------
 
    tickvals = [k * separation for k in range(row)]
    ticktext = labels
 
    max_abs = float(np.max(np.abs(shap_values)))
    padding = 0.2 * max_abs
 
    fig.update_layout(
        title="SHAP Summary",
        xaxis=dict(
            title="SHAP Value",
            range=[-max_abs - padding, max_abs + padding],
        ),
        yaxis=dict(
            tickvals=tickvals,
            ticktext=ticktext,
            title=""
        ),
        height=600,
        hovermode="closest",
        template="plotly_white",
    )
 
    fig.add_vline(x=0, line_width=1, line_dash="dash")
 
    return fig

def update_turnup_grammage(
    turnup: pd.DataFrame,
    targets=(85, 90, 100, 110, 115, 120),
    tolerance=4.5,
    persist_n=3,
    inplace=True,
    grade_col="AB_Grade_ID",
    basis_weight_col="Current_basis_weight",
    correct_start_batch=False
):
    """
    Update basis weight category, classify grammage consistency,
    and correct AB_Grade_ID / grammage when grammage is deemed wrong.

    Rules
    -----
    1. basis_weight_cat is assigned to the nearest target if Current_basis_weight
       is within tolerance; otherwise grammage is kept.
    2. Isolated basis_weight_cat values are corrected only if:
       - both neighbours are equal,
       - the current value differs from the neighbours,
       - and it also differs from grammage.
    3. grammage_check is classified as:
       - match
       - batch_start_ok
       - grammage_wrong
       - check
    4. For grammage_wrong rows only:
       - AB_Grade_ID is replaced by a grade whose last 3 digits match basis_weight_cat
       - if several candidates exist, prefer one with same first 4 digits
       - if none exists, replace only the last 3 digits of the current AB_Grade_ID
       - grammage is updated to basis_weight_cat

    Parameters
    ----------
    turnup : pd.DataFrame
    targets : iterable of numeric
    tolerance : float
    persist_n : int
        Minimum consecutive mismatch length to classify as grammage_wrong.
    inplace : bool
        If True, modify input dataframe in place and return it.
        If False, work on a copy and return the copy.

    Returns
    -------
    pd.DataFrame
    """
    import numpy as np
    import pandas as pd

    if not inplace:
        turnup = turnup.copy()

    targets = np.array(targets)

    # ---- 1) Initial basis_weight_cat assignment ----
    values = turnup[basis_weight_col].to_numpy()
    grammage_values = turnup["grammage"].to_numpy()

    diffs = np.abs(values[:, None] - targets)
    closest_idx = diffs.argmin(axis=1)
    min_diff = diffs.min(axis=1)    

    turnup[grade_col] = turnup[grade_col].astype("string")
    turnup["basis_weight_cat"] = np.where(
        min_diff <= tolerance,
        targets[closest_idx],
        grammage_values,
    )

    # ---- 2) Correct isolated basis_weight_cat values only if different from grammage ----
    bw = turnup["basis_weight_cat"].to_numpy(copy=True)
    gr = pd.to_numeric(turnup["grammage"], errors="coerce").to_numpy()

    prev_bw = turnup["basis_weight_cat"].shift(1).to_numpy()
    next_bw = turnup["basis_weight_cat"].shift(-1).to_numpy()

    mask_isolated = (
         ~np.isnan(prev_bw) &
        ((bw != prev_bw) | (prev_bw == next_bw)) &
        (bw != prev_bw) &
        (bw != gr)
    )

    bw[mask_isolated] = prev_bw[mask_isolated]
    turnup["basis_weight_cat"] = bw

    # ---- 3) Classify mismatch behaviour ----
    turnup["mismatch"] = turnup["basis_weight_cat"] != turnup["grammage"]
    turnup["new_grammage_batch"] = turnup["grammage"] != turnup["grammage"].shift()
    turnup["mismatch_group"] = turnup["mismatch"].ne(turnup["mismatch"].shift()).cumsum()

    turnup["mismatch_run_length"] = (
        turnup.groupby("mismatch_group")["mismatch"]
        .transform("size")
        .where(turnup["mismatch"], 0)
    )

    turnup["mismatch_run_pos"] = (
        turnup.groupby("mismatch_group").cumcount() + 1
    ).where(turnup["mismatch"], 0)

    def classify_row(row):
        if not row["mismatch"]:
            return "match"
        elif row["new_grammage_batch"] and row["mismatch_run_pos"] == 1:
            return "batch_start_ok"
        elif row["mismatch_run_length"] >= persist_n:
            return "grammage_wrong"
        else:
            return "check"

    turnup["grammage_check"] = turnup.apply(classify_row, axis=1)

    # ---- 4) Prepare available AB_Grade_ID candidates ----
    available_grades = pd.Series(turnup[grade_col].dropna().astype(str).unique())

    grades_by_grammage = {}
    for g in available_grades:
        if len(g) >= 3:
            gramm = g[-3:]
            grades_by_grammage.setdefault(gramm, []).append(g)

    def replace_grade_id(ab_grade_id, target_grammage):
        if pd.isna(ab_grade_id) or pd.isna(target_grammage):
            return ab_grade_id

        old_str = str(ab_grade_id)
        target_str = f"{int(target_grammage):03d}"

        candidates = grades_by_grammage.get(target_str, [])

        same_prefix = [c for c in candidates if c[:4] == old_str[:4]]
        if same_prefix:
            return same_prefix[0]

        if candidates:
            return candidates[0]

        if len(old_str) >= 3:
            return old_str[:-3] + target_str
        return target_str

    # ---- 5) Update AB_Grade_ID and grammage only where grammage is wrong ----
    if correct_start_batch:
        mask_wrong = turnup["grammage_check"].eq("grammage_wrong") | turnup["grammage_check"].eq("batch_start_ok")        
    else:
        mask_wrong = turnup["grammage_check"].eq("grammage_wrong")


    turnup.loc[mask_wrong, grade_col] = turnup.loc[mask_wrong].apply(
        lambda row: replace_grade_id(row[grade_col], row["basis_weight_cat"]),
        axis=1
    )

    turnup.loc[mask_wrong, "grammage"] = turnup.loc[mask_wrong, "basis_weight_cat"]

    return turnup

def ewm_reset(s):
    out = s.ewm(halflife="120min", times=s.index, adjust=True).mean()
    if len(s) >= 2:
        out.iloc[0] = (s.iloc[0] + s.iloc[1]) / 2.0   # softer start
    return out

class ContinuousMarginal:
    import numpy as np

    def __init__(self, bandwidth: float | None = None, eps: float = 1e-6):
        self.bandwidth = bandwidth
        self.eps = eps
        self.x_ = None
        self.cdf_y_ = None
        self.kde_ = None

    def fit(self, x: np.ndarray):
        from sklearn.neighbors import KernelDensity

        x = np.asarray(x, dtype=float)
        x = x[np.isfinite(x)]
        if x.size < 5:
            raise ValueError("Not enough data to fit marginal.")
        xs = np.sort(x)
        uniq, counts = np.unique(xs, return_counts=True)
        cum = np.cumsum(counts)
        mids = (cum - counts/2) / xs.size
        self.x_, self.cdf_y_ = uniq, mids
        if self.bandwidth is None:
            std = np.std(x, ddof=1)
            bw = 1.06 * std * x.size ** (-1/5) if std > 0 else 0.1
        else:
            bw = float(self.bandwidth)
        self.kde_ = KernelDensity(kernel="gaussian", bandwidth=max(bw, 1e-3)).fit(x[:, None])
        return self

    def cdf(self, x: np.ndarray) -> np.ndarray:
        u = np.interp(x, self.x_, self.cdf_y_, left=self.cdf_y_[0], right=self.cdf_y_[-1])
        return np.clip(u, self.eps, 1 - self.eps)

    def inv_cdf(self, u: np.ndarray) -> np.ndarray:
        u = np.clip(u, self.eps, 1 - self.eps)
        return np.interp(u, self.cdf_y_, self.x_, left=self.x_[0], right=self.x_[-1])

    def log_pdf(self, x: np.ndarray) -> np.ndarray:
        return self.kde_.score_samples(np.asarray(x, dtype=float)[:, None])


class GaussianCopulaContinuous:
    import numpy as np
    

    def __init__(self, bandwidth: float | None = None, random_state: int | None = None, eps: float = 1e-6):
        self.bandwidth = bandwidth
        self.random_state = random_state
        self.eps = eps
        self.columns_ = None
        self.marginals_ = None
        self.R_ = None
        self.R_inv_ = None
        self.logdet_R_ = None
        self._rng = np.random.default_rng(random_state)

    def fit(self, X: pd.DataFrame):
        from scipy.stats import norm
        from sklearn.covariance import LedoitWolf

        if not np.all([pd.api.types.is_numeric_dtype(X[c]) for c in X.columns]):
            raise ValueError("All columns must be numeric.")
        df = X.copy()
        self.columns_ = list(df.columns)
        for c in self.columns_:
            df[c] = pd.to_numeric(df[c], errors="coerce").fillna(df[c].median())
        self.marginals_ = {c: ContinuousMarginal(self.bandwidth, self.eps).fit(df[c].to_numpy())
                           for c in self.columns_}
        U = np.column_stack([self.marginals_[c].cdf(df[c].to_numpy()) for c in self.columns_])
        Z = norm.ppf(np.clip(U, self.eps, 1 - self.eps))
        lw = LedoitWolf().fit(Z)
        Sigma = lw.covariance_
        d = np.sqrt(np.diag(Sigma)); d[d == 0] = 1.0
        R = Sigma / np.outer(d, d)
        R = (R + R.T) / 2.0
        self.R_ = R
        self.R_inv_ = np.linalg.inv(R)
        sign, logdet = np.linalg.slogdet(R)
        if sign <= 0:
            raise RuntimeError("Estimated correlation not PD.")
        self.logdet_R_ = logdet
        return self

    def _check(self):
        if self.R_ is None or self.marginals_ is None or self.columns_ is None:
            raise RuntimeError("Model not fitted.")

    def _to_Z(self, X: pd.DataFrame) -> np.ndarray:
        from scipy.stats import norm

        df = X[self.columns_].copy()
        for c in self.columns_:
            df[c] = pd.to_numeric(df[c], errors="coerce").fillna(df[c].median())
        U = np.column_stack([self.marginals_[c].cdf(df[c].to_numpy()) for c in self.columns_])
        return norm.ppf(np.clip(U, self.eps, 1 - self.eps))

    def _log_copula_density(self, Z: np.ndarray) -> np.ndarray:
        q1 = np.einsum("...i,ij,...j->...", Z, self.R_inv_, Z)
        q0 = np.einsum("...i,...i->...", Z, Z)
        return -0.5 * self.logdet_R_ - 0.5 * (q1 - q0)

    def score_samples(self, X: pd.DataFrame) -> np.ndarray:
        self._check()
        Z = self._to_Z(X)
        log_m = 0.0
        for c in self.columns_:
            log_m += self.marginals_[c].log_pdf(np.asarray(X[c], dtype=float))
        return self._log_copula_density(Z) + log_m

    def sample(self, n: int) -> pd.DataFrame:
        from scipy.stats import norm

        self._check()
        L = np.linalg.cholesky(self.R_)
        Z = self._rng.standard_normal(size=(n, len(self.columns_))) @ L.T
        U = norm.cdf(Z)
        data = {c: self.marginals_[c].inv_cdf(U[:, j]) for j, c in enumerate(self.columns_)}
        return pd.DataFrame(data, columns=self.columns_)

    # ---- conditional utilities ----
    def conditional_params(self, target: str, given_df: pd.DataFrame | dict) -> tuple[float, float]:
        self._check()
        if isinstance(given_df, dict):
            given_df = pd.DataFrame([given_df])
        if len(given_df) != 1:
            raise ValueError("given_df must be single-row.")
        cols = self.columns_
        if target not in cols:
            raise KeyError(f"Target '{target}' not in columns.")
        t_idx = cols.index(target)
        given_cols = [c for c in cols if c in given_df.columns and c != target]
        if not given_cols:
            return 0.0, 1.0
        g_idx = [cols.index(c) for c in given_cols]
        tpl = pd.Series({c: given_df.iloc[0][c] if c in given_cols else 0.0 for c in cols}, dtype=float)
        Z_all = self._to_Z(pd.DataFrame([tpl], columns=cols))
        z_g = Z_all[0, g_idx]
        R = self.R_
        R_gg = R[np.ix_(g_idx, g_idx)]
        R_tg = R[t_idx, g_idx]
        R_gg_inv = np.linalg.inv(R_gg)
        mu = float(R_tg @ R_gg_inv @ z_g)
        var = float(1.0 - R_tg @ R_gg_inv @ R_tg.T)
        return mu, max(var, 1e-9)

    def conditional_sample(self, target: str, given_df: pd.DataFrame | dict, n: int = 50_000) -> np.ndarray:
        from scipy.stats import norm
        
        mu, var = self.conditional_params(target, given_df)
        z = np.random.default_rng().normal(loc=mu, scale=np.sqrt(var), size=n)
        u = norm.cdf(z)
        return self.marginals_[target].inv_cdf(u)

    def conditional_summary(self, target: str, given_df: pd.DataFrame | dict, n: int = 100_000,
                            quantiles=(0.05, 0.5, 0.95)) -> dict:
        xs = self.conditional_sample(target, given_df, n=n)
        out = {"mean": float(np.mean(xs)), "std": float(np.std(xs, ddof=1))}
        for q in quantiles:
            out[f"q{int(q*100):02d}"] = float(np.quantile(xs, q))
        return out

def _numeric(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy().apply(pd.to_numeric, errors="coerce")
    return df.fillna(df.median(numeric_only=True))

def model_feature_names(model, fallback_cols) -> list[str]:
    if hasattr(model, "feature_names_in_"):
        return list(model.feature_names_in_)
    if hasattr(model, "best_estimator_") and hasattr(model.best_estimator_, "feature_names_in_"):
        return list(model.best_estimator_.feature_names_in_)
    return list(fallback_cols)

def build_template(df_hist: pd.DataFrame, required_cols: list[str]) -> pd.Series:
    med = _numeric(df_hist).median(numeric_only=True)
    tpl = pd.Series(0.0, index=required_cols, dtype=float)
    common = med.index.intersection(tpl.index)
    tpl.loc[common] = med.loc[common].astype(float)
    return tpl
    
def conditional_bounds_from_joint(
    free_variable,
    df_hist: pd.DataFrame,
    joint: GaussianCopulaContinuous,
    df_fixed: pd.DataFrame | dict,
    q_bounds=(0.01, 0.99),
    grid_step: float = 0.01,
    safety_pad: float = 0.05,
    control_min: float | None = None,
    control_max: float | None = None,
    nonneg_control: bool = True,
    pre_expand: float = 0.0,                       # expand the grid range before quantiles
    post_expand: float = 0.0                       # expand final [lo,hi] after quantiles
) -> tuple[float, float, pd.DataFrame]:
    # normalize df_fixed
    if isinstance(df_fixed, dict):
        df_fixed = pd.DataFrame([df_fixed])
    df_fixed = df_fixed.iloc[[0]]

    # numeric history (for empirical envelope)
    df_num = df_hist.copy().apply(pd.to_numeric, errors="coerce")
    df_num = df_num.fillna(df_num.median(numeric_only=True))

    # wide empirical envelope for starch
    s_hist = pd.to_numeric(df_hist[free_variable], errors="coerce").dropna().to_numpy()
    
    if s_hist.size:
        q_lo_emp, q_hi_emp = np.quantile(s_hist, [0.01, 0.99])
    else:
        q_lo_emp, q_hi_emp = (0.0, 1.0)
   
    span = max(q_hi_emp - q_lo_emp, 1.0)
    lo_emp = q_lo_emp - safety_pad * span
    hi_emp = q_hi_emp + safety_pad * span
    if nonneg_control: lo_emp = max(0.0, lo_emp)
    if control_min is not None: lo_emp = max(lo_emp, float(control_min))
    if control_max is not None: hi_emp = min(hi_emp, float(control_max))
    if hi_emp <= lo_emp:
        hi_emp = lo_emp + max(1.0, grid_step)

    # slice along starch given df_fixed
    cols = joint.columns_
    tpl = df_num.median(numeric_only=True).reindex(cols, fill_value=0.0).astype(float)
    for c in df_fixed.columns.intersection(cols):
        v = pd.to_numeric(df_fixed.iloc[0][c], errors="coerce")
        if pd.notna(v): tpl[c] = float(v)

    # Pre-expand the grid window 
    base_span = hi_emp - lo_emp
    lo_grid = lo_emp - pre_expand * base_span
    hi_grid = hi_emp + pre_expand * base_span
    if nonneg_control: lo_grid = max(0.0, lo_grid)
    if control_min is not None: lo_grid = max(lo_grid, float(control_min))
    if control_max is not None: hi_grid = min(hi_grid, float(control_max))
    if hi_grid <= lo_grid: hi_grid = lo_grid + max(1.0, grid_step)    

    grid = np.arange(lo_emp, hi_emp + 1e-12, grid_step, dtype=float)
    rows = []
    for s in grid:
        r = tpl.copy(); r[free_variable] = float(s)
        rows.append(r)
    slice_df = pd.DataFrame(rows, columns=cols)

    # logpdf from joint (all columns)
    logpdf = np.asarray(joint.score_samples(slice_df), dtype=float)
    # stabilize & normalize to conditional pdf over starch
    logpdf_stab = logpdf - np.max(logpdf)
    unnorm = np.exp(logpdf_stab)
    if not np.isfinite(unnorm).any() or unnorm.sum() == 0:
        unnorm = np.ones_like(unnorm)
    Z = np.trapz(unnorm, grid)
    pdf = unnorm / max(Z, np.finfo(float).tiny)
    cdf = np.cumsum((pdf[:-1] + pdf[1:]) / 2 * np.diff(grid))
    cdf = np.concatenate([[0.0], cdf]); cdf = np.clip(cdf, 0.0, 1.0)

    q_lo, q_hi = q_bounds
    lo = float(np.interp(q_lo, cdf, grid))
    hi = float(np.interp(q_hi, cdf, grid))

    # post-expand the final bounds --------
    span_final = max(hi - lo, grid_step)
    
    lo_ext = lo - post_expand * span_final
    hi_ext = hi + post_expand * span_final
    # clamp to the grid range (so we don't exceed evaluated domain)
    lo_ext = max(lo_grid, lo_ext)
    hi_ext = min(hi_grid, hi_ext)

    profile = pd.DataFrame({free_variable: grid, "logpdf": logpdf, "pdf": pdf, "cdf": cdf})
    return lo_ext, hi_ext, profile

import numpy as np
from scipy.optimize import Bounds

def bounds_to_cobyla_constraints(bounds, n_vars=None):
    """
    Convert SciPy bounds (Bounds or list of (lo,hi)) into COBYLA-style
    inequality constraints g(x) >= 0.
    Returns a list suitable for minimize(..., method="COBYLA", constraints=...).
    """
    # Normalize to arrays lb, ub
    if isinstance(bounds, Bounds):
        lb = np.asarray(bounds.lb, dtype=float)
        ub = np.asarray(bounds.ub, dtype=float)
    else:
        # sequence of (lo, hi)
        pairs = list(bounds)
        lb = np.array([(-np.inf if lo is None else lo) for lo, _ in pairs], dtype=float)
        ub = np.array([( np.inf if hi is None else hi) for _, hi in pairs], dtype=float)

    if n_vars is None:
        n_vars = len(lb)

    cons = []
    for i in range(n_vars):
        lo = lb[i]
        hi = ub[i]
        if np.isfinite(lo):
            # x[i] - lo >= 0
            cons.append({"type": "ineq", "fun": (lambda i=i, lo=lo: lambda x: x[i] - lo)()})
        if np.isfinite(hi):
            # hi - x[i] >= 0
            cons.append({"type": "ineq", "fun": (lambda i=i, hi=hi: lambda x: hi - x[i])()})
    return cons



import numpy as np
import pandas as pd

from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.cross_decomposition import PLSRegression
from sklearn.preprocessing import StandardScaler
from sklearn.utils.validation import check_is_fitted


class GroupwisePLSTransformer(BaseEstimator, TransformerMixin):
    """
    Apply PLS on selected columns, optionally fitting one PLS model per group
    (e.g. per grammage), and pass the remaining columns through.

    If group_col is None, a single global PLS is fitted.

    Parameters
    ----------
    pls_columns : list[str]
        Columns to transform with PLS.

    group_col : str or None, default=None
        Column defining the groups. If None, no grouping is applied.

    n_components : int, default=2
        Number of PLS components.

    score_prefix : str, default="pls"
        Prefix for generated score columns.

    scale : bool, default=True
        Whether to standardize pls_columns before PLS.

    remainder : {"passthrough", "drop"}, default="passthrough"
        Whether to keep non-PLS columns.

    handle_unknown_group : {"error", "global"}, default="global"
        Only relevant when group_col is not None.
        What to do at transform time if a group was not seen in fit:
        - "error": raise an error
        - "global": use a global fallback PLS fitted on all rows

    copy : bool, default=True
        Whether to copy input data.
    """

    def __init__(
        self,
        pls_columns,
        group_col=None,
        n_components=2,
        score_prefix="pls",
        scale=True,
        remainder="passthrough",
        handle_unknown_group="global",
        copy=True,
    ):
        self.pls_columns = pls_columns
        self.group_col = group_col
        self.n_components = n_components
        self.score_prefix = score_prefix
        self.scale = scale
        self.remainder = remainder
        self.handle_unknown_group = handle_unknown_group
        self.copy = copy

    def fit(self, X, y):
        X = self._validate_X(X)

        if y is None:
            raise ValueError("GroupwisePLSTransformer requires y in fit because PLS is supervised.")

        y = self._validate_y(y, X.index)

        required_cols = list(self.pls_columns)
        if self.group_col is not None:
            required_cols.append(self.group_col)

        missing = [c for c in required_cols if c not in X.columns]
        if missing:
            raise ValueError(f"Missing columns in X: {missing}")

        if self.remainder not in ("passthrough", "drop"):
            raise ValueError("remainder must be 'passthrough' or 'drop'")

        if self.handle_unknown_group not in ("error", "global"):
            raise ValueError("handle_unknown_group must be 'error' or 'global'")

        self.input_features_ = X.columns.to_list()
        self.feature_names_in_ = np.asarray(X.columns, dtype=object)
        self.n_features_in_ = X.shape[1]

        if self.remainder == "passthrough":
            self.pass_through_columns_ = [c for c in X.columns if c not in set(self.pls_columns)]
        else:
            self.pass_through_columns_ = []

        max_possible = min(len(self.pls_columns), X.shape[0] - 1)
        if max_possible < 1:
            raise ValueError("Not enough data to fit PLS.")

        self.n_components_ = min(self.n_components, max_possible)
        self.output_pls_columns_ = [
            f"{self.score_prefix}_{i+1}" for i in range(self.n_components_)
        ]

        self.models_ = {}
        self.global_bundle_ = self._fit_single_bundle(
            X[self.pls_columns], y, n_components=self.n_components_
        )

        if self.group_col is None:
            self.use_grouping_ = False
        else:
            self.use_grouping_ = True
            self.groups_ = pd.Index(X[self.group_col].dropna().unique())

            for group_value, idx in X.groupby(self.group_col, observed=True).groups.items():
                
                Xg = X.loc[idx, self.pls_columns]
                yg = y.loc[idx]

                n_comp_group = min(self.n_components, len(Xg) - 1, len(self.pls_columns))
                if n_comp_group < 1:
                    continue

                self.models_[group_value] = self._fit_single_bundle(
                    Xg, yg, n_components=n_comp_group
                )

        return self

    def transform(self, X):
        check_is_fitted(self, ["global_bundle_", "output_pls_columns_", "pass_through_columns_"])
        X = self._validate_X(X)

        required_cols = list(self.pls_columns)
        if self.group_col is not None:
            required_cols.append(self.group_col)

        missing = [c for c in required_cols if c not in X.columns]
        if missing:
            raise ValueError(f"Missing columns in X: {missing}")

        X_work = X.copy() if self.copy else X

        if not self.use_grouping_:
            Z = self._transform_single_bundle(self.global_bundle_, X_work[self.pls_columns])

            scores = pd.DataFrame(
                Z,
                index=X_work.index,
                columns=self.output_pls_columns_[:Z.shape[1]],
            )

            if Z.shape[1] < self.n_components_:
                for j in range(Z.shape[1], self.n_components_):
                    scores[self.output_pls_columns_[j]] = np.nan

            scores = scores[self.output_pls_columns_]

        else:
            scores = pd.DataFrame(
                index=X_work.index,
                columns=self.output_pls_columns_,
                dtype=float,
            )

            for group_value, idx in X_work.groupby(self.group_col, observed=True).groups.items():
                Xg = X_work.loc[idx, self.pls_columns]

                if group_value in self.models_:
                    bundle = self.models_[group_value]
                else:
                    if self.handle_unknown_group == "error":
                        raise ValueError(f"Unknown group in transform: {group_value}")
                    bundle = self.global_bundle_

                Z = self._transform_single_bundle(bundle, Xg)

                out = np.full((len(Xg), self.n_components_), np.nan, dtype=float)
                out[:, :Z.shape[1]] = Z
                scores.loc[idx, self.output_pls_columns_] = out

        parts = [scores]

        if self.remainder == "passthrough":
            parts.append(X_work[self.pass_through_columns_])

        return pd.concat(parts, axis=1)

    def get_feature_names_out(self, input_features=None):
        check_is_fitted(self, ["output_pls_columns_", "pass_through_columns_"])

        if self.remainder == "passthrough":
            return np.asarray(self.output_pls_columns_ + self.pass_through_columns_, dtype=object)

        return np.asarray(self.output_pls_columns_, dtype=object)

    def _fit_single_bundle(self, X_sub, y_sub, n_components):
        X_values = pd.DataFrame(X_sub, columns=self.pls_columns).to_numpy(dtype=float)
        y_values = self._y_to_2d(y_sub)

        scaler = StandardScaler() if self.scale else None
        if scaler is not None:
            X_values = scaler.fit_transform(X_values)

        pls = PLSRegression(n_components=n_components)
        pls.fit(X_values, y_values)

        return {
            "scaler": scaler,
            "pls": pls,
            "n_components": n_components,
        }

    def _transform_single_bundle(self, bundle, X_sub):
        X_values = pd.DataFrame(X_sub, columns=self.pls_columns).to_numpy(dtype=float)

        scaler = bundle["scaler"]
        if scaler is not None:
            X_values = scaler.transform(X_values)

        Z = bundle["pls"].transform(X_values)
        return np.asarray(Z)

    @staticmethod
    def _validate_X(X):
        if not isinstance(X, pd.DataFrame):
            raise TypeError("X must be a pandas DataFrame.")
        return X

    @staticmethod
    def _validate_y(y, index):
        if isinstance(y, pd.Series):
            return y
        if isinstance(y, pd.DataFrame):
            if y.shape[1] != 1:
                raise ValueError("Only a 1D target or single-column DataFrame is supported.")
            return y.iloc[:, 0]
        return pd.Series(y, index=index)

    @staticmethod
    def _y_to_2d(y):
        y_values = np.asarray(y, dtype=float)
        if y_values.ndim == 1:
            y_values = y_values.reshape(-1, 1)
        return y_values



class DivideByFeatureRegressor(BaseEstimator, RegressorMixin):
    """
    Wraps an existing regression model and divides its prediction
    by a feature column.

    Example:
        starch_consumption =
            starch_uptake_prediction / Current_basis_weight
    """

    def __init__(
        self,
        base_model,
        divisor_feature="Current_basis_weight",
        weight=1,
        epsilon=1e-9,
        create = False
    ):
        self.base_model = base_model
        self.divisor_feature = divisor_feature
        self.weight = weight
        self.epsilon = epsilon
        self.create = create

    def fit(self, X, y=None):
        """
        No refit of the internal model.
        Only stores feature names.
        """

        if isinstance(X, pd.DataFrame):
            cols = list(X.columns)
        else:
            cols = list(self.base_model.feature_names_in_)

        # ensure divisor feature exists in feature_names_in_
        if self.create:
            fc = FeatureCreator(features_to_create=[self.divisor_feature], features_to_keep= [self.divisor_feature])
            self.features_required_to_create =  fc.features_required()
            for fet in fc.features_required():
                if fet not in cols:
                    cols.append(fet)    
        else:
            if self.divisor_feature not in cols:
                cols.append(self.divisor_feature)

        self.feature_names_in_ = np.array(cols, dtype=object)

        return self

    def predict(self, X):

        if not isinstance(X, pd.DataFrame):
            X = pd.DataFrame(X, columns=self.feature_names_in_)

        if self.create:
            missing = set(self.features_required_to_create).difference(X.columns)
            if missing:
                raise ValueError(
                    f"Missing divisor features: {missing}"
                )
        else:
            if self.divisor_feature not in X.columns:
                raise ValueError(
                    f"Missing divisor feature: {self.divisor_feature}"
                )

        uptake_pred = np.asarray(
            self.base_model.predict(X),
            dtype=float
        ).reshape(-1)

        if self.create:
            fc = FeatureCreator(
                features_to_create=[self.divisor_feature],
                features_to_keep=[self.divisor_feature],
            )

            divisor = (
                fc.fit_transform(X[fc.features_required()])
                [self.divisor_feature]
                .astype(float)
                .to_numpy()
            )

        else:
            divisor = (
                X[self.divisor_feature]
                .astype(float)
                .to_numpy()
            )

        divisor = np.asarray(divisor, dtype=float).reshape(-1)

        if len(uptake_pred) != len(divisor):
            raise ValueError(
                f"Incompatible prediction and divisor lengths: "
                f"{len(uptake_pred)} and {len(divisor)}"
            )

        prediction = (
            self.weight
            * uptake_pred
            / np.clip(divisor, self.epsilon, None)
        )

        return prediction

        

# =============================================================================
# Deployment objects for the differencing models (shared filter + per-model state)
# Moved here from explore_differencing_experiments.ipynb so cloudpickle stores them
# BY REFERENCE (utility.TurnupFilter, etc.) instead of by value. This makes the
# pickled bundles independent of the Python minor version used to create them:
# the loading interpreter compiles this source itself. Requires `utility` importable
# on both the training and engine sides (same version).
# =============================================================================
import json as _json
import numpy as _np
import pandas as _pd
from pathlib import Path as _Path
from sklearn.pipeline import Pipeline as _SKPipeline

try:
    import cloudpickle as _cloudpickle
except Exception:  # cloudpickle optional at import time; only needed by load_state_and_prod
    _cloudpickle = None


class TurnupFilter:
    """Shared, model-agnostic EWM filter at one common halflife.

    Index: input and output are Wedge_Time-indexed. Reel id (MBS_Current_reel_ID) is a
    COLUMN and is used only as the SELECTION KEY: the engine passes the reel ids of the
    rows it wants filtered. Everything internal is time-based (it must be).

    Reproduces the training EWM exactly (utility.ewm_reset form):
        out = s.ewm(halflife=halflife, times=s.index, adjust=True).mean()
        out.iloc[0] = (s.iloc[0] + s.iloc[1]) / 2.0   # softened start (oldest row of segment)
    per segment; segments reset on grammage change OR time gap > gap_threshold.

    Causality: filtered value at a row depends only on that row and OLDER in-segment rows,
    so the engine can cache old rows and only re-request recent reel ids.
    """

    def __init__(self, halflife, grammage_col="grammage", gap_threshold="12h",
                 time_col="Wedge_Time", id_col="MBS_Current_reel_ID"):
        self.halflife = halflife
        self.grammage_col = grammage_col
        self.gap_threshold = gap_threshold
        self.time_col = time_col
        self.id_col = id_col

    def _ewm_segment(self, s):
        out = s.ewm(halflife=self.halflife, times=s.index, adjust=True).mean()
        if len(s) >= 2:
            out.iloc[0] = (s.iloc[0] + s.iloc[1]) / 2.0
        return out

    def _prep(self, turnup_raw):
        """Return a Wedge_Time-indexed copy, sorted ascending, with id_col as a column."""
        df = turnup_raw.copy()
        if df.index.name == self.time_col:
            df = df.reset_index()
        if self.time_col not in df.columns:
            raise ValueError(f"'{self.time_col}' not found as column or index")
        if self.id_col not in df.columns:
            if df.index.name == self.id_col:
                df = df.reset_index()
            else:
                raise ValueError(f"'{self.id_col}' not found as column or index")
        return df.set_index(_pd.DatetimeIndex(df[self.time_col])).sort_index()

    def segments(self, frame):
        g = frame[self.grammage_col].values
        grade_change = _pd.Series(g).ne(_pd.Series(g).shift())
        time_gap = frame.index.to_series().diff().gt(_pd.Timedelta(self.gap_threshold))
        time_gap.iloc[0] = True
        return (grade_change.values | time_gap.values).cumsum()

    def _filter_columns(self, frame, columns, seg):
        out = frame.copy()
        for col in columns:
            if col in out.columns and _pd.api.types.is_numeric_dtype(out[col]):
                s = _pd.Series(out[col].values, index=out.index)
                out[col] = s.groupby(seg).transform(self._ewm_segment).values
        keep = [c for c in columns if c in out.columns]
        res = out.loc[:, keep].copy()
        res[self.id_col] = out[self.id_col].values   # keep reel id as a column
        return res

    def filter_all(self, turnup_raw, columns):
        """Full-frame filter (source of truth). Wedge_Time-indexed; reel id as a column."""
        df = self._prep(turnup_raw)
        seg = self.segments(df)
        return self._filter_columns(df, columns, seg)

    def filter(self, turnup_raw, columns, reel_ids, lag_days=None):
        """Filter and return the requested reels PLUS the history their state computation
        needs. Wedge_Time-indexed, reel id kept as a column.

        Why history: computing state for a requested reel at time t needs its lag partner
        at t - k (k = lag_days) and that partner's EWM warm-up. So filter() returns not
        only the requested rows but also the rows back to the earliest lag partner, keeping
        whole segments (so EWM is exact). Pass `lag_days` (the model's lag) so we know how
        far back t - k reaches; if None, only the segments of the requested reels are
        returned (state may then be NaN for reels whose partner falls in an older segment).

        Efficient for both small (incremental) and large (cold-start / all) requests: we
        select whole SEGMENTS by time span and filter each once; never loops per reel.
        `reel_ids` may be a list, a pandas Index, or any iterable of reel ids (int64).
        Unknown reel ids are silently skipped.
        """
        df = self._prep(turnup_raw)
        seg = _np.asarray(self.segments(df))
        id_vals = df[self.id_col].values
        times = df.index

        requested = set(_np.asarray(list(reel_ids)).tolist())
        if not requested:
            return _pd.DataFrame(columns=list(columns) + [self.id_col])

        wanted_row = _np.array([rid in requested for rid in id_vals])
        if not wanted_row.any():
            return _pd.DataFrame(columns=list(columns) + [self.id_col])

        # time span we must cover: from the earliest lag partner up to the newest request
        latest_t = times[wanted_row].max()
        earliest_req_t = times[wanted_row].min()
        if lag_days is not None:
            # partner is ~k hours older; go a bit beyond k to be safe for the nearest match
            k = _pd.Timedelta(hours=float(lag_days) * 24.0)
            earliest_needed_t = earliest_req_t - k * 1.5
        else:
            earliest_needed_t = earliest_req_t

        # include EVERY segment that has any row in [earliest_needed_t, latest_t]
        in_span = (times >= earliest_needed_t) & (times <= latest_t)
        span_segs = set(_np.unique(seg[in_span]).tolist())
        # also always include the segments of the requested reels
        span_segs |= set(_np.unique(seg[wanted_row]).tolist())

        seg_mask = _np.array([s in span_segs for s in seg])
        sub = df[seg_mask]
        sub_seg = seg[seg_mask]
        filt = self._filter_columns(sub, columns, sub_seg)
        return filt.sort_index()


class StateBuilder:
    """Per-model state builder. Consumes an ALREADY-EWM-FILTERED, Wedge_Time-indexed frame
    (the filtered feat_list columns + filtered target + reel id column) and appends
    `Y_COLUMN + "_state"` where c(t) = y_ewm(t-k) - beta'X(t-k).

    `reel_ids` (optional) is the SELECTION KEY: if given, state is written only for those
    reels' rows. Their lag partners (older rows, possibly other reels) are still looked up
    from the full frame, so the frame must contain the history. Wedge_Time index unchanged.
    """

    def __init__(self, pre_estimator, estimator, feat_list, selected_features,
                 y_column, lag_days, ewm_halflife, tolerance=0.35,
                 id_col="MBS_Current_reel_ID", max_tolerance=None, fill=None,
                 grammage_col="grammage", gap_threshold="12h"):
        self.pre_estimator = pre_estimator
        self.estimator = estimator
        self.feat_list = list(feat_list)
        self.selected_features = selected_features
        self.y_column = y_column
        self.state_col = y_column + "_state"
        self.lag_days = lag_days
        self.ewm_halflife = ewm_halflife
        self.tolerance = tolerance
        self.id_col = id_col
        # NaN-reduction options (default OFF -> strict behaviour, nothing changes silently)
        self.max_tolerance = max_tolerance
        self.fill = fill
        self.grammage_col = grammage_col
        self.gap_threshold = gap_threshold

    @staticmethod
    def _to_hours(index):
        t = _pd.DatetimeIndex(index).asi8.astype(_np.float64)
        return (t - t[0]) / 3.6e12

    @staticmethod
    def _lag_pairs(t_hours, lag_hours, tolerance=0.35, max_tolerance=None):
        """Nearest strictly-earlier partner to t - lag_hours, accepted within tolerance.
        If max_tolerance > tolerance, rows unresolved at tolerance retry at the wider
        window (tight matches are kept -> identical to strict for those rows)."""
        target = t_hours - lag_hours
        j = _np.searchsorted(t_hours, target)
        j = _np.clip(j, 0, len(t_hours) - 1)
        j_alt = _np.clip(j - 1, 0, len(t_hours) - 1)
        better = _np.abs(t_hours[j_alt] - target) < _np.abs(t_hours[j] - target)
        j = _np.where(better, j_alt, j)
        realised = t_hours - t_hours[j]
        has_earlier = j < _np.arange(len(t_hours))
        ok = has_earlier & (_np.abs(realised - lag_hours) <= tolerance * lag_hours)
        if max_tolerance is not None and max_tolerance > tolerance:
            relaxed = has_earlier & ~ok & (_np.abs(realised - lag_hours) <= max_tolerance * lag_hours)
            ok = ok | relaxed
        later = _np.flatnonzero(ok)
        return later, j[later]

    def _ffill_within_segments(self, ts, state_series):
        """Carry last resolved state forward, never across grade change or >gap_threshold."""
        if self.grammage_col in ts.columns:
            g = ts[self.grammage_col].values
            grade_change = _pd.Series(g).ne(_pd.Series(g).shift())
        else:
            grade_change = _pd.Series([False] * len(ts))
        time_gap = ts.index.to_series().diff().gt(_pd.Timedelta(self.gap_threshold))
        grade_change.iloc[0] = True
        time_gap.iloc[0] = True
        seg = (grade_change.values | time_gap.values).cumsum()
        filled = _pd.Series(state_series.values, index=ts.index)
        return filled.groupby(seg).ffill()

    def append_state(self, filtered_frame, reel_ids=None, inplace=False,
                     max_tolerance="_default", fill="_default"):
        """Append `self.state_col` to a Wedge_Time-indexed, already-filtered frame.

        reel_ids=None -> state for all computable rows (batch / validation).
        reel_ids=[...] -> state only for those reels' rows (partners still from full frame).

        NaN-reduction (default to instance settings, which default OFF):
          max_tolerance : widen partner search only for rows unresolved at `tolerance`.
          fill='ffill'  : carry last resolved state forward within a segment (never across
                          grade change / >gap_threshold).
        Unresolved edge rows get NaN, never raise.
        """
        if max_tolerance == "_default":
            max_tolerance = self.max_tolerance
        if fill == "_default":
            fill = self.fill

        ts = filtered_frame if inplace else filtered_frame.copy()
        ts = ts.sort_index()

        available = [c for c in self.feat_list if c in ts.columns]
        transformed = self.pre_estimator.transform(ts.loc[:, available])
        beta_x = self.estimator.predict(
            transformed[self.selected_features].values.astype(float)).ravel()
        y_ewm = ts[self.y_column].reindex(transformed.index).values.astype(float)

        t_hours = self._to_hours(transformed.index)
        later, earlier = self._lag_pairs(t_hours, self.lag_days * 24.0,
                                         self.tolerance, max_tolerance)
        c = y_ewm[earlier] - beta_x[earlier]
        state = _np.full(len(transformed), _np.nan)
        state[later] = c
        state_series = _pd.Series(state, index=transformed.index).reindex(ts.index)

        if fill == "ffill":
            state_series = self._ffill_within_segments(ts, state_series)

        if reel_ids is not None and self.id_col in ts.columns:
            keep = ts[self.id_col].isin(list(reel_ids)).values
            vals = state_series.values.copy()
            vals[~keep] = _np.nan
            state_series = _pd.Series(vals, index=ts.index)

        ts[self.state_col] = state_series.values
        if inplace:
            filtered_frame[self.state_col] = ts[self.state_col].values
            return filtered_frame
        return ts

    def append_state_from_raw(self, turnup_raw, turnup_filter, reel_ids=None):
        """Validation helper: filter (all) then state, end to end."""
        cols = self.feat_list + [self.y_column]
        filtered = turnup_filter.filter_all(turnup_raw, cols)
        return self.append_state(filtered, reel_ids=reel_ids)


class ProductionModel(RegressorMixin, BaseEstimator):
    """sklearn-compatible estimator: y = (state + beta'X) * scale * multiplier / divisor.

    Consumes a pre-computed `state_col` on the input frame; it does NOT compute state.
    The engine treats this like any other sklearn model:
        model.feature_names_in_   -> the input columns it must supply
        model.predict(X)          -> predictions

    feature_names_in_ = feat_list + [state_col] (+ multiplier + divisor if set), i.e.
    EVERY column predict() reads.
    """

    def __init__(self, pre_estimator, estimator, feat_list, selected_features,
                 state_col, scale=1.0, multiplier=None, divisor=None):
        self.pre_estimator = pre_estimator
        self.estimator = estimator
        self.feat_list = feat_list
        self.selected_features = selected_features
        self.state_col = state_col
        self.scale = scale
        self.multiplier = multiplier
        self.divisor = divisor
        self._set_fitted_attributes()

    @staticmethod
    def _creatable_inputs(col):
        """If `col` is a FeatureCreator-creatable feature, return its raw component
        inputs (e.g. Production_Rate__T/h_ -> [Current_basis_weight, Speed,
        Current_reel_width]); otherwise return None (col is a plain raw column)."""
        if col is None:
            return None
        try:
            registry = FeatureCreator._registry()
            if col not in registry:
                return None
            inputs = FeatureCreator._feature_raw_inputs().get(col, [])
            return list(inputs) if inputs else None
        except Exception:
            return None

    def _set_fitted_attributes(self):
        # Resolve whether multiplier/divisor are creatable features. If so, the engine
        # supplies their raw COMPONENTS (filtered upstream) and we build the filtered
        # value at predict time -- so feature_names_in_ lists the components, NOT the
        # derived column. If not creatable, the derived column stays a required raw input.
        self._mult_inputs = self._creatable_inputs(self.multiplier)
        self._div_inputs = self._creatable_inputs(self.divisor)

        names = list(self.feat_list) + [self.state_col]
        for col, comp in ((self.multiplier, self._mult_inputs),
                          (self.divisor, self._div_inputs)):
            if not col:
                continue
            if comp is not None:
                for c in comp:            # creatable -> require its components
                    if c not in names:
                        names.append(c)
            elif col not in names:        # plain column -> require the column itself
                names.append(col)
        self.feature_names_in_ = _np.asarray(names, dtype=object)
        self.n_features_in_ = len(names)

    def _factor_values(self, df, col, comp_inputs):
        """Return the per-row values of a multiplier/divisor column. If it is a
        creatable feature, build its (filtered, since components are filtered upstream)
        value with a standalone FeatureCreator; else read the raw column directly."""
        if comp_inputs is None:
            return df[col].values.astype(float)
        fc = FeatureCreator(features_to_create=[col], features_to_keep=[col], errors="raise")
        built = fc.fit(df).transform(df)
        return built[col].values.astype(float)

    def fit(self, X=None, y=None):
        """No-op fit: the model is built from a trained artifact."""
        self._set_fitted_attributes()
        return self

    def get_feature_names_out(self, input_features=None):
        return _np.asarray(self.feature_names_in_, dtype=object)

    @property
    def required_cols(self):
        """Backwards-compatible alias for the full input column list."""
        return list(self.feature_names_in_)

    def _beta_x(self, df):
        cols = [c for c in self.feat_list if c in df.columns]
        X = self.pre_estimator.transform(df.loc[:, cols])
        return self.estimator.predict(X[self.selected_features].values).ravel()

    def predict(self, X):
        """Predict from a DataFrame (batch) or a single row (Series) carrying
        feature_names_in_. Returns an array (batch) or a float (single row)."""
        if isinstance(X, _pd.Series):
            df = X.to_frame().T
            df.index = _pd.DatetimeIndex([X.name]) if X.name is not None else df.index
            single = True
        else:
            df = X
            single = False

        missing = [c for c in self.feature_names_in_ if c not in df.columns]
        if missing:
            raise ValueError(f"missing required input columns: {missing}")

        state = df[self.state_col].values.astype(float)
        if _np.isnan(state).any():
            raise ValueError(f"{self.state_col} contains NaN for {int(_np.isnan(state).sum())} row(s)")

        beta_x = self._beta_x(df)
        result = (state + beta_x) * self.scale
        if self.multiplier is not None:
            result = result * self._factor_values(df, self.multiplier, self._mult_inputs)
        if self.divisor is not None:
            result = result / self._factor_values(df, self.divisor, self._div_inputs)

        return float(result[0]) if single else result


def load_state_and_prod(artifact_dir, use_full_model=True,
                        scale=1.0, multiplier=None, divisor=None,
                        max_tolerance=None, fill=None):
    """Build (StateBuilder, ProductionModel) from an artifact directory (training side).

    max_tolerance / fill are passed to the StateBuilder to control NaN reduction (both
    default None -> strict partner matching, no carry-forward)."""
    artifact_dir = _Path(artifact_dir)
    results = _json.load(open(artifact_dir / "results.json"))
    model_file = "model_full.pkl" if use_full_model else "model.pkl"
    with open(artifact_dir / model_file, "rb") as f:
        art = _cloudpickle.load(f)

    y_column = results["parameters"]["y_column"]
    lag_days = results["parameters"]["lag_days"]
    ewm_halflife = results["parameters"].get("ewm_halflife", "120min")
    feature_cols = results["data"]["feature_cols"]
    feat_list = art["feat_list"]
    pre_estimator = art["pre_estimator"]
    selected_features = art.get("selected_features", feature_cols)

    raw_model = art["model"]
    est = getattr(raw_model, "best_estimator_", raw_model)
    if "scaler" in art and art["scaler"] is not None:
        est = _SKPipeline([("scaler", art["scaler"]), ("model", est)])

    builder = StateBuilder(pre_estimator, est, feat_list, selected_features,
                           y_column, lag_days, ewm_halflife,
                           max_tolerance=max_tolerance, fill=fill)
    prod = ProductionModel(pre_estimator, est, feat_list, selected_features,
                           y_column + "_state", scale=scale,
                           multiplier=multiplier, divisor=divisor)
    return builder, prod

from typing import Iterable, TypeVar

import numpy as np
import pandas as pd

T = TypeVar("T")


# =============================================================================
# Collection helpers
# =============================================================================

def unique_in_order(values: Iterable[T]) -> list[T]:
    """Remove duplicates while preserving first-occurrence order."""
    return list(dict.fromkeys(values))


def ordered_difference(values: Iterable[T], excluded: Iterable[T]) -> list[T]:
    """Remove excluded items while preserving order."""
    excluded_set = set(excluded)
    return [v for v in values if v not in excluded_set]


def ordered_intersection(values: Iterable[T], allowed: Iterable[T]) -> list[T]:
    """Keep only allowed items while preserving order."""
    allowed_set = set(allowed)
    return [v for v in values if v in allowed_set]